#!/usr/bin/env python3
"""
🌐 Browser Automation Sidekick - Setup Script
============================================

Quick setup script to get your browser automation system running!
"""

import os
import sys
import subprocess
import platform

def print_banner():
    """Print a cool banner"""
    print("""
╔══════════════════════════════════════════════════════════════════════════════╗
║                                                                              ║
║  🌐 BROWSER AUTOMATION SIDEKICK SETUP 🌐                                    ║
║                                                                              ║
║  Your intelligent browser automation system with LangGraph + Playwright!    ║
║                                                                              ║
╚══════════════════════════════════════════════════════════════════════════════╝
    """)

def check_python_version():
    """Check if Python version is compatible"""
    version = sys.version_info
    if version.major < 3 or (version.major == 3 and version.minor < 9):
        print("❌ Python 3.9 or higher is required!")
        print(f"   Current version: {version.major}.{version.minor}.{version.micro}")
        return False
    
    print(f"✅ Python {version.major}.{version.minor}.{version.micro} detected")
    return True

def install_dependencies():
    """Install required dependencies"""
    print("\n📦 Installing dependencies...")
    
    try:
        # Install from requirements.txt
        subprocess.check_call([sys.executable, "-m", "pip", "install", "-r", "requirements.txt"])
        print("✅ Dependencies installed successfully!")
        return True
    except subprocess.CalledProcessError as e:
        print(f"❌ Failed to install dependencies: {e}")
        return False

def install_playwright():
    """Install Playwright browsers"""
    print("\n🎭 Installing Playwright browsers...")
    
    try:
        subprocess.check_call([sys.executable, "-m", "playwright", "install", "chromium"])
        print("✅ Playwright browsers installed successfully!")
        return True
    except subprocess.CalledProcessError as e:
        print(f"❌ Failed to install Playwright browsers: {e}")
        return False

def create_env_file():
    """Create .env file if it doesn't exist"""
    env_file = ".env"
    if not os.path.exists(env_file):
        print(f"\n🔧 Creating {env_file} file...")
        
        with open(env_file, "w") as f:
            f.write("# Browser Automation Sidekick Configuration\n")
            f.write("# Copy from env_example.txt and add your API keys\n")
            f.write("OPENAI_API_KEY=your_openai_api_key_here\n")
            f.write("SERPER_API_KEY=your_serper_api_key_here\n")
            f.write("\n# Optional: Push Notifications\n")
            f.write("# PUSHOVER_TOKEN=your_pushover_token\n")
            f.write("# PUSHOVER_USER=your_pushover_user\n")
        
        print(f"✅ Created {env_file} - please add your API keys!")
        return False
    else:
        print("✅ .env file already exists")
        return True

def run_demo():
    """Run the demo to test the system"""
    print("\n🎬 Running system demo...")
    
    try:
        subprocess.run([sys.executable, "browser_demo.py"], check=True)
        return True
    except subprocess.CalledProcessError:
        print("❌ Demo failed - check your configuration")
        return False

def main():
    """Main setup function"""
    print_banner()
    
    # Check Python version
    if not check_python_version():
        sys.exit(1)
    
    # Install dependencies
    if not install_dependencies():
        print("\n❌ Setup failed during dependency installation")
        sys.exit(1)
    
    # Install Playwright browsers
    if not install_playwright():
        print("\n⚠️  Playwright browsers installation failed - browser automation may not work")
    
    # Create .env file
    env_ready = create_env_file()
    
    print("\n🎉 Setup completed successfully!")
    print("\n📋 Next steps:")
    print("   1. Add your API keys to the .env file")
    print("   2. Run the demo: python browser_demo.py")
    print("   3. Try the real system: python sidekick.py")
    print("   4. Use the Gradio interface: python app.py")
    
    if not env_ready:
        print("\n🔑 Don't forget to add your API keys to .env!")
        print("   Required: OPENAI_API_KEY, SERPER_API_KEY")
        print("   Optional: PUSHOVER_TOKEN, PUSHOVER_USER")
    
    print("\n🌐 Your Browser Automation Sidekick is ready!")
    print("🌟 Features:")
    print("   • Intelligent browser automation with Playwright")
    print("   • LangGraph workflow management")
    print("   • Web search and research capabilities")
    print("   • Real-time monitoring dashboard")
    print("   • Push notifications and file management")
    print("   • Beautiful demo interface")

if __name__ == "__main__":
    main()
