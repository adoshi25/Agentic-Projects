import gradio as gr
import asyncio
import os
from datetime import datetime
import json
from sidekick_tools import playwright_tools, other_tools
from sidekick import create_sidekick_agent

class RealBrowserDemo:
    def __init__(self):
        self.browser = None
        self.playwright = None
        self.tools = None
        self.agent = None
        self.setup_complete = False
        
    async def setup_browser(self):
        """Setup the real browser automation"""
        try:
            print("🌐 Setting up real browser automation...")
            self.tools, self.browser, self.playwright = await playwright_tools()
            other_tools_list = await other_tools()
            all_tools = self.tools + other_tools_list
            
            # Create the real LangGraph agent
            self.agent = await create_sidekick_agent(all_tools)
            self.setup_complete = True
            print("✅ Real browser automation ready!")
            return "✅ Browser automation system ready!"
        except Exception as e:
            print(f"❌ Setup failed: {e}")
            return f"❌ Setup failed: {e}"
    
    async def real_web_search(self, query):
        """Do a real web search"""
        if not self.setup_complete:
            return "❌ Browser not set up yet. Click 'Setup Browser' first."
        
        try:
            print(f"🔍 Starting real web search for: {query}")
            
            # Use the real agent to search
            result = await self.agent.ainvoke({
                "messages": [{"role": "user", "content": f"Search for '{query}' on Google and get me the top 3 results"}]
            })
            
            # Extract the actual results
            search_results = []
            if result and "messages" in result:
                last_message = result["messages"][-1]
                if hasattr(last_message, 'content'):
                    search_results.append(f"🔍 Search completed: {last_message.content}")
                else:
                    search_results.append(f"🔍 Search completed: {str(last_message)}")
            else:
                search_results.append(f"🔍 Search completed for: {query}")
            
            return "\n".join(search_results)
            
        except Exception as e:
            return f"❌ Search failed: {e}"
    
    async def real_extract_data(self, url):
        """Extract real data from a webpage"""
        if not self.setup_complete:
            return "❌ Browser not set up yet. Click 'Setup Browser' first."
        
        try:
            print(f"📊 Extracting data from: {url}")
            
            # Use the real agent to extract data
            result = await self.agent.ainvoke({
                "messages": [{"role": "user", "content": f"Go to {url} and extract all the text content, headings, and links"}]
            })
            
            # Extract the actual results
            extracted_data = []
            if result and "messages" in result:
                last_message = result["messages"][-1]
                if hasattr(last_message, 'content'):
                    extracted_data.append(f"📊 Data extracted from {url}")
                    extracted_data.append(f"Content: {last_message.content[:500]}...")
                else:
                    extracted_data.append(f"📊 Data extracted: {str(last_message)}")
            else:
                extracted_data.append(f"📊 Data extraction completed for: {url}")
            
            return "\n".join(extracted_data)
            
        except Exception as e:
            return f"❌ Data extraction failed: {e}"
    
    async def real_screenshot(self, url):
        """Take a real screenshot"""
        if not self.setup_complete:
            return "❌ Browser not set up yet. Click 'Setup Browser' first."
        
        try:
            print(f"📸 Taking screenshot of: {url}")
            
            # Use the real agent to take screenshot
            result = await self.agent.ainvoke({
                "messages": [{"role": "user", "content": f"Go to {url} and take a screenshot, then save it"}]
            })
            
            # Extract the actual results
            screenshot_info = []
            if result and "messages" in result:
                last_message = result["messages"][-1]
                if hasattr(last_message, 'content'):
                    screenshot_info.append(f"📸 Screenshot taken of {url}")
                    screenshot_info.append(f"Result: {last_message.content}")
                else:
                    screenshot_info.append(f"📸 Screenshot: {str(last_message)}")
            else:
                screenshot_info.append(f"📸 Screenshot completed for: {url}")
            
            return "\n".join(screenshot_info)
            
        except Exception as e:
            return f"❌ Screenshot failed: {e}"
    
    async def cleanup(self):
        """Clean up browser resources"""
        try:
            if self.browser:
                await self.browser.close()
            if self.playwright:
                await self.playwright.stop()
            print("🧹 Browser cleanup completed")
        except Exception as e:
            print(f"❌ Cleanup failed: {e}")

# Global demo instance
demo_instance = RealBrowserDemo()

def create_real_browser_interface():
    """Create the real browser automation interface"""
    
    custom_css = """
    .gradio-container {
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    }
    .main-header {
        text-align: center;
        color: white;
        padding: 20px;
        background: rgba(255, 255, 255, 0.1);
        border-radius: 10px;
        margin-bottom: 20px;
    }
    .status-ready { color: #28a745; font-weight: bold; }
    .status-not-ready { color: #dc3545; font-weight: bold; }
    .real-action {
        background: rgba(255, 255, 255, 0.9);
        padding: 20px;
        border-radius: 10px;
        margin: 10px;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    }
    """
    
    with gr.Blocks(css=custom_css, title="Real Browser Automation Demo") as demo:
        
        # Header
        gr.HTML("""
        <div class="main-header">
            <h1>🌐 Real Browser Automation Sidekick</h1>
            <p>This demo uses your ACTUAL LangGraph + Playwright system to do real browser automation!</p>
        </div>
        """)
        
        with gr.Row():
            with gr.Column(scale=1):
                # Setup Section
                gr.HTML("<div class='real-action'><h2>🚀 Setup</h2></div>")
                
                setup_btn = gr.Button("🔧 Setup Real Browser", variant="primary")
                setup_status = gr.Textbox(
                    label="Setup Status",
                    value="❌ Browser not set up",
                    interactive=False
                )
                
                # Real Actions Section
                gr.HTML("<div class='real-action'><h2>🎯 Real Browser Actions</h2></div>")
                
                with gr.Row():
                    search_input = gr.Textbox(
                        label="Search Query",
                        placeholder="Enter what you want to search for...",
                        value="latest AI news"
                    )
                    search_btn = gr.Button("🔍 Real Web Search")
                
                with gr.Row():
                    url_input = gr.Textbox(
                        label="Website URL",
                        placeholder="https://example.com",
                        value="https://news.ycombinator.com"
                    )
                    extract_btn = gr.Button("📊 Extract Real Data")
                
                with gr.Row():
                    screenshot_url = gr.Textbox(
                        label="Screenshot URL",
                        placeholder="https://example.com",
                        value="https://github.com"
                    )
                    screenshot_btn = gr.Button("📸 Take Real Screenshot")
                
                cleanup_btn = gr.Button("🧹 Cleanup Browser", variant="stop")
            
            with gr.Column(scale=2):
                # Results Section
                gr.HTML("<div class='real-action'><h2>📋 Real Results</h2></div>")
                
                results_output = gr.Textbox(
                    label="Browser Automation Results",
                    lines=15,
                    interactive=False,
                    value="🎯 Ready to perform real browser automation!\n\nClick 'Setup Real Browser' first, then try the actions above."
                )
        
        # Event Handlers
        def setup_browser_sync():
            """Sync wrapper for async setup"""
            return asyncio.run(demo_instance.setup_browser())
        
        def real_search_sync(query):
            """Sync wrapper for async search"""
            return asyncio.run(demo_instance.real_web_search(query))
        
        def real_extract_sync(url):
            """Sync wrapper for async extract"""
            return asyncio.run(demo_instance.real_extract_data(url))
        
        def real_screenshot_sync(url):
            """Sync wrapper for async screenshot"""
            return asyncio.run(demo_instance.real_screenshot(url))
        
        def cleanup_sync():
            """Sync wrapper for async cleanup"""
            asyncio.run(demo_instance.cleanup())
            return "🧹 Browser cleaned up"
        
        # Connect events
        setup_btn.click(
            fn=setup_browser_sync,
            outputs=[setup_status]
        )
        
        search_btn.click(
            fn=real_search_sync,
            inputs=[search_input],
            outputs=[results_output]
        )
        
        extract_btn.click(
            fn=real_extract_sync,
            inputs=[url_input],
            outputs=[results_output]
        )
        
        screenshot_btn.click(
            fn=real_screenshot_sync,
            inputs=[screenshot_url],
            outputs=[results_output]
        )
        
        cleanup_btn.click(
            fn=cleanup_sync,
            outputs=[results_output]
        )
    
    return demo

def main():
    """Main function to run the real browser demo"""
    print("🌐 Starting REAL Browser Automation Demo...")
    print("📱 This demo uses your actual LangGraph + Playwright system!")
    print("🎮 You'll see REAL browser automation happening!")
    
    demo = create_real_browser_interface()
    
    demo.launch(
        server_name="127.0.0.1",
        server_port=7861,
        share=False,
        show_error=True
    )

if __name__ == "__main__":
    main()
