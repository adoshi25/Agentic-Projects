import gradio as gr
import asyncio
import os
from datetime import datetime
from playwright.async_api import async_playwright

class SimpleBrowserDemo:
    def __init__(self):
        self.browser = None
        self.playwright = None
        self.page = None
        self.setup_complete = False
        
    async def setup_browser(self):
        """Setup the real browser automation"""
        try:
            print("🌐 Setting up browser...")
            self.playwright = await async_playwright().start()
            self.browser = await self.playwright.chromium.launch(headless=False)
            self.page = await self.browser.new_page()
            self.setup_complete = True
            print("✅ Browser ready!")
            return "✅ Browser automation system ready!"
        except Exception as e:
            print(f"❌ Setup failed: {e}")
            return f"❌ Setup failed: {e}"
    
    async def real_web_search(self, query):
        """Do a real web search using Google"""
        if not self.setup_complete:
            return "❌ Browser not set up yet. Click 'Setup Browser' first."
        
        try:
            print(f"🔍 Searching for: {query}")
            
            # Navigate to Google
            await self.page.goto("https://www.google.com")
            await self.page.wait_for_load_state('networkidle')
            
            # Find search box and type query (try multiple selectors)
            search_box = None
            selectors_to_try = [
                'input[name="q"]',
                'textarea[name="q"]',
                'input[aria-label*="Search"]',
                'textarea[aria-label*="Search"]',
                'input[title*="Search"]',
                'textarea[title*="Search"]',
                '[role="combobox"] input',
                '[role="combobox"] textarea'
            ]
            
            for selector in selectors_to_try:
                try:
                    search_box = await self.page.wait_for_selector(selector, timeout=5000)
                    if search_box:
                        break
                except:
                    continue
            
            if not search_box:
                # Fallback: click in the center of the page and type
                await self.page.click('body')
                await self.page.keyboard.type(query)
                await self.page.keyboard.press('Enter')
            else:
                await search_box.fill(query)
                await search_box.press('Enter')
            
            # Wait for results
            await self.page.wait_for_load_state('networkidle')
            
            # Extract search results
            results = []
            try:
                # Try multiple selectors for search results
                result_selectors = [
                    'h3',  # Traditional Google results
                    '[data-ved] h3',  # Google results with data-ved
                    '.g h3',  # Google results in .g containers
                    'a h3',  # Links with h3 titles
                    '[role="link"] h3'  # Links with role attribute
                ]
                
                search_results = []
                for selector in result_selectors:
                    try:
                        elements = await self.page.query_selector_all(selector)
                        if elements:
                            search_results = elements
                            break
                    except:
                        continue
                
                if search_results:
                    for i, result in enumerate(search_results[:5]):
                        try:
                            title = await result.inner_text()
                            # Try to find the parent link
                            parent = await result.query_selector('xpath=..')
                            if parent:
                                link = await parent.get_attribute('href')
                                if link and ('http' in link or link.startswith('/')):
                                    results.append(f"{i+1}. {title}\n   Link: {link}")
                                else:
                                    results.append(f"{i+1}. {title}")
                        except:
                            continue
                
                if not results:
                    # Fallback: get page title and URL
                    title = await self.page.title()
                    url = self.page.url
                    results.append(f"Search completed for '{query}'")
                    results.append(f"Page: {title}")
                    results.append(f"URL: {url}")
                    
            except Exception as e:
                results.append(f"Search completed for '{query}' but couldn't extract detailed results: {e}")
            
            return "\n\n".join(results) if results else f"Search completed for: {query}"
            
        except Exception as e:
            return f"❌ Search failed: {e}"
    
    async def real_extract_data(self, url):
        """Extract real data from a webpage"""
        if not self.setup_complete:
            return "❌ Browser not set up yet. Click 'Setup Browser' first."
        
        try:
            print(f"📊 Extracting data from: {url}")
            
            # Navigate to the URL
            await self.page.goto(url)
            await self.page.wait_for_load_state('networkidle')
            
            # Extract data
            extracted_data = []
            
            # Get page title
            title = await self.page.title()
            extracted_data.append(f"📄 Page Title: {title}")
            
            # Get headings
            try:
                headings = await self.page.query_selector_all('h1, h2, h3')
                heading_texts = []
                for heading in headings:
                    text = await heading.inner_text()
                    if text.strip():
                        heading_texts.append(text.strip())
                
                if heading_texts:
                    extracted_data.append(f"📋 Headings found: {len(heading_texts)}")
                    for i, heading in enumerate(heading_texts[:10]):  # Limit to 10
                        extracted_data.append(f"   {i+1}. {heading}")
                
            except Exception as e:
                extracted_data.append(f"Could not extract headings: {e}")
            
            # Get links
            try:
                links = await self.page.query_selector_all('a[href]')
                link_urls = []
                for link in links:
                    href = await link.get_attribute('href')
                    if href and href.startswith('http'):
                        link_urls.append(href)
                
                if link_urls:
                    extracted_data.append(f"🔗 Links found: {len(link_urls)}")
                    for i, link in enumerate(link_urls[:10]):  # Limit to 10
                        extracted_data.append(f"   {i+1}. {link}")
                
            except Exception as e:
                extracted_data.append(f"Could not extract links: {e}")
            
            # Get some text content
            try:
                body_text = await self.page.inner_text('body')
                # Clean up the text
                clean_text = ' '.join(body_text.split()[:200])  # First 200 words
                extracted_data.append(f"📝 Sample content: {clean_text}...")
                
            except Exception as e:
                extracted_data.append(f"Could not extract text content: {e}")
            
            return "\n\n".join(extracted_data)
            
        except Exception as e:
            return f"❌ Data extraction failed: {e}"
    
    async def real_screenshot(self, url):
        """Take a real screenshot"""
        if not self.setup_complete:
            return "❌ Browser not set up yet. Click 'Setup Browser' first."
        
        try:
            print(f"📸 Taking screenshot of: {url}")
            
            # Navigate to the URL
            await self.page.goto(url)
            await self.page.wait_for_load_state('networkidle')
            
            # Take screenshot
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            screenshot_path = f"screenshot_{timestamp}.png"
            
            await self.page.screenshot(path=screenshot_path, full_page=True)
            
            # Get page info
            title = await self.page.title()
            url_actual = self.page.url
            
            result = f"📸 Screenshot taken successfully!\n"
            result += f"📄 Page: {title}\n"
            result += f"🌐 URL: {url_actual}\n"
            result += f"💾 Saved as: {screenshot_path}\n"
            result += f"📁 Full path: {os.path.abspath(screenshot_path)}"
            
            return result
            
        except Exception as e:
            return f"❌ Screenshot failed: {e}"
    
    async def cleanup(self):
        """Clean up browser resources"""
        try:
            if self.browser:
                await self.browser.close()
            if self.playwright:
                await self.playwright.stop()
            print("🧹 Browser cleanup completed")
        except Exception as e:
            print(f"❌ Cleanup failed: {e}")

# Global demo instance
demo_instance = SimpleBrowserDemo()

def create_simple_browser_interface():
    """Create the simple browser automation interface"""
    
    custom_css = """
    .gradio-container {
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    }
    .main-header {
        text-align: center;
        color: white;
        padding: 20px;
        background: rgba(255, 255, 255, 0.1);
        border-radius: 10px;
        margin-bottom: 20px;
    }
    .status-ready { color: #28a745; font-weight: bold; }
    .status-not-ready { color: #dc3545; font-weight: bold; }
    .real-action {
        background: rgba(255, 255, 255, 0.9);
        padding: 20px;
        border-radius: 10px;
        margin: 10px;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    }
    """
    
    with gr.Blocks(css=custom_css, title="Simple Browser Automation Demo") as demo:
        
        # Header
        gr.HTML("""
        <div class="main-header">
            <h1>🌐 Simple Browser Automation Demo</h1>
            <p>This demo does REAL browser automation with Playwright - no complex agents, just direct results!</p>
        </div>
        """)
        
        with gr.Row():
            with gr.Column(scale=1):
                # Setup Section
                gr.HTML("<div class='real-action'><h2>🚀 Setup</h2></div>")
                
                setup_btn = gr.Button("🔧 Setup Browser", variant="primary")
                setup_status = gr.Textbox(
                    label="Setup Status",
                    value="❌ Browser not set up",
                    interactive=False
                )
                
                # Real Actions Section
                gr.HTML("<div class='real-action'><h2>🎯 Real Browser Actions</h2></div>")
                
                with gr.Row():
                    search_input = gr.Textbox(
                        label="Search Query",
                        placeholder="Enter what you want to search for...",
                        value="latest AI news"
                    )
                    search_btn = gr.Button("🔍 Real Web Search")
                
                with gr.Row():
                    url_input = gr.Textbox(
                        label="Website URL",
                        placeholder="https://example.com",
                        value="https://news.ycombinator.com"
                    )
                    extract_btn = gr.Button("📊 Extract Real Data")
                
                with gr.Row():
                    screenshot_url = gr.Textbox(
                        label="Screenshot URL",
                        placeholder="https://example.com",
                        value="https://github.com"
                    )
                    screenshot_btn = gr.Button("📸 Take Real Screenshot")
                
                cleanup_btn = gr.Button("🧹 Cleanup Browser", variant="stop")
            
            with gr.Column(scale=2):
                # Results Section
                gr.HTML("<div class='real-action'><h2>📋 Real Results</h2></div>")
                
                results_output = gr.Textbox(
                    label="Browser Automation Results",
                    lines=20,
                    interactive=False,
                    value="🎯 Ready to perform real browser automation!\n\nClick 'Setup Browser' first, then try the actions above.\n\nThis demo will show you:\n• Real search results from Google\n• Actual extracted data from websites\n• Real screenshots saved to your computer"
                )
        
        # Event Handlers
        def setup_browser_sync():
            """Sync wrapper for async setup"""
            try:
                # Create a new event loop for this thread
                loop = asyncio.new_event_loop()
                asyncio.set_event_loop(loop)
                result = loop.run_until_complete(demo_instance.setup_browser())
                loop.close()
                return result
            except Exception as e:
                return f"❌ Setup failed: {e}"
        
        def real_search_sync(query):
            """Sync wrapper for async search"""
            try:
                loop = asyncio.new_event_loop()
                asyncio.set_event_loop(loop)
                # Recreate browser in this loop
                demo_instance.browser = None
                demo_instance.playwright = None
                loop.run_until_complete(demo_instance.setup_browser())
                result = loop.run_until_complete(demo_instance.real_web_search(query))
                loop.close()
                return result
            except Exception as e:
                return f"❌ Search failed: {e}"
        
        def real_extract_sync(url):
            """Sync wrapper for async extract"""
            try:
                loop = asyncio.new_event_loop()
                asyncio.set_event_loop(loop)
                # Recreate browser in this loop
                demo_instance.browser = None
                demo_instance.playwright = None
                loop.run_until_complete(demo_instance.setup_browser())
                result = loop.run_until_complete(demo_instance.real_extract_data(url))
                loop.close()
                return result
            except Exception as e:
                return f"❌ Extract failed: {e}"
        
        def real_screenshot_sync(url):
            """Sync wrapper for async screenshot"""
            try:
                loop = asyncio.new_event_loop()
                asyncio.set_event_loop(loop)
                # Recreate browser in this loop
                demo_instance.browser = None
                demo_instance.playwright = None
                loop.run_until_complete(demo_instance.setup_browser())
                result = loop.run_until_complete(demo_instance.real_screenshot(url))
                loop.close()
                return result
            except Exception as e:
                return f"❌ Screenshot failed: {e}"
        
        def cleanup_sync():
            """Sync wrapper for async cleanup"""
            try:
                loop = asyncio.new_event_loop()
                asyncio.set_event_loop(loop)
                loop.run_until_complete(demo_instance.cleanup())
                loop.close()
                return "🧹 Browser cleaned up"
            except Exception as e:
                return f"❌ Cleanup failed: {e}"
        
        # Connect events
        setup_btn.click(
            fn=setup_browser_sync,
            outputs=[setup_status]
        )
        
        search_btn.click(
            fn=real_search_sync,
            inputs=[search_input],
            outputs=[results_output]
        )
        
        extract_btn.click(
            fn=real_extract_sync,
            inputs=[url_input],
            outputs=[results_output]
        )
        
        screenshot_btn.click(
            fn=real_screenshot_sync,
            inputs=[screenshot_url],
            outputs=[results_output]
        )
        
        cleanup_btn.click(
            fn=cleanup_sync,
            outputs=[results_output]
        )
    
    return demo

def main():
    """Main function to run the simple browser demo"""
    print("🌐 Starting Simple Browser Automation Demo...")
    print("📱 This demo does REAL browser automation with Playwright!")
    print("🎮 You'll see REAL results without complex agent evaluation!")
    
    demo = create_simple_browser_interface()
    
    demo.launch(
        server_name="127.0.0.1",
        server_port=7862,
        share=False,
        show_error=True
    )

if __name__ == "__main__":
    main()
