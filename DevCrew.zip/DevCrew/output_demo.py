#!/usr/bin/env python3
"""
🚀 Output Demo - See What Your Agents Actually Build!
====================================================

This demo shows you the REAL output that your agents create!
"""

import gradio as gr
import os
import sys

# Add the engineering team examples to our path
sys.path.append('/Users/mohitdoshi/Desktop/projects/AI Agents (my projects)/3_crew/engineering_team/example_output_new')

def show_agent_outputs():
    """Show what each agent type actually produces"""
    
    # Read the actual files your agents created
    try:
        with open('/Users/mohitdoshi/Desktop/projects/AI Agents (my projects)/3_crew/engineering_team/example_output_new/accounts.py', 'r') as f:
            backend_code = f.read()
    except:
        backend_code = "Backend code not found"
    
    try:
        with open('/Users/mohitdoshi/Desktop/projects/AI Agents (my projects)/3_crew/engineering_team/example_output_new/app.py', 'r') as f:
            frontend_code = f.read()
    except:
        frontend_code = "Frontend code not found"
    
    try:
        with open('/Users/mohitdoshi/Desktop/projects/AI Agents (my projects)/3_crew/engineering_team/example_output_new/test_accounts.py', 'r') as f:
            test_code = f.read()
    except:
        test_code = "Test code not found"
    
    try:
        with open('/Users/mohitdoshi/Desktop/projects/AI Agents (my projects)/3_crew/engineering_team/example_output_new/accounts.py_design.md', 'r') as f:
            design_doc = f.read()
    except:
        design_doc = "Design document not found"
    
    return backend_code, frontend_code, test_code, design_doc

def run_live_demo():
    """Run the actual app that was created"""
    try:
        # Import and run the actual app
        from accounts import Account, get_share_price
        import gradio as gr
        
        # Create a demo account
        demo_account = Account("demo_user", 10000.0)
        
        def get_account_status():
            return f"""
            🏦 Account Status:
            • User ID: {demo_account.user_id}
            • Cash Balance: ${demo_account.cash_balance:.2f}
            • Portfolio Value: ${demo_account.portfolio_value():.2f}
            • Total Value: ${demo_account.cash_balance + demo_account.portfolio_value():.2f}
            """
        
        def buy_shares(symbol, quantity):
            try:
                quantity = int(quantity)
                result = demo_account.buy_shares(symbol, quantity)
                return result, get_account_status()
            except Exception as e:
                return str(e), get_account_status()
        
        def sell_shares(symbol, quantity):
            try:
                quantity = int(quantity)
                result = demo_account.sell_shares(symbol, quantity)
                return result, get_account_status()
            except Exception as e:
                return str(e), get_account_status()
        
        def deposit_cash(amount):
            try:
                amount = float(amount)
                result = demo_account.deposit_cash(amount)
                return result, get_account_status()
            except Exception as e:
                return str(e), get_account_status()
        
        # Create the demo interface
        with gr.Blocks(title="🎯 Live Demo - Trading Account") as demo:
            gr.Markdown("# 🏦 Live Trading Account Demo")
            gr.Markdown("This is the ACTUAL app that your agents built!")
            
            status_display = gr.Textbox(
                value=get_account_status(),
                label="Account Status",
                interactive=False,
                lines=6
            )
            
            with gr.Row():
                with gr.Column():
                    gr.Markdown("### 💰 Buy Shares")
                    buy_symbol = gr.Dropdown(["AAPL", "TSLA", "GOOGL"], label="Stock Symbol")
                    buy_qty = gr.Number(label="Quantity", value=1)
                    buy_btn = gr.Button("Buy Shares")
                    
                with gr.Column():
                    gr.Markdown("### 💸 Sell Shares")
                    sell_symbol = gr.Dropdown(["AAPL", "TSLA", "GOOGL"], label="Stock Symbol")
                    sell_qty = gr.Number(label="Quantity", value=1)
                    sell_btn = gr.Button("Sell Shares")
            
            with gr.Row():
                gr.Markdown("### 💵 Deposit Cash")
                deposit_amt = gr.Number(label="Amount", value=1000)
                deposit_btn = gr.Button("Deposit")
            
            result_display = gr.Textbox(label="Transaction Result", interactive=False)
            
            # Event handlers
            buy_btn.click(
                fn=buy_shares,
                inputs=[buy_symbol, buy_qty],
                outputs=[result_display, status_display]
            )
            
            sell_btn.click(
                fn=sell_shares,
                inputs=[sell_symbol, sell_qty],
                outputs=[result_display, status_display]
            )
            
            deposit_btn.click(
                fn=deposit_cash,
                inputs=[deposit_amt],
                outputs=[result_display, status_display]
            )
        
        return demo
        
    except Exception as e:
        return f"Error running demo: {str(e)}"

def create_output_dashboard():
    """Create dashboard showing agent outputs"""
    
    # Get the actual outputs
    backend_code, frontend_code, test_code, design_doc = show_agent_outputs()
    
    with gr.Blocks(title="🚀 What Your Agents Actually Built!") as demo:
        gr.Markdown("""
        # 🎯 What Your Agents Actually Build!
        
        Below are the REAL outputs that your multi-agent system creates. This is what you get when you run orchestration!
        """)
        
        with gr.Tabs():
            # Design Document Tab
            with gr.Tab("📋 Design Document (Engineering Lead)"):
                gr.Markdown("### 🧠 Engineering Lead Output")
                gr.Markdown("The Engineering Lead creates detailed technical specifications:")
                design_output = gr.Markdown(value=design_doc)
            
            # Backend Code Tab
            with gr.Tab("⚙️ Backend Code (Backend Engineer)"):
                gr.Markdown("### 💻 Backend Engineer Output")
                gr.Markdown("The Backend Engineer creates the core Python module:")
                backend_output = gr.Code(value=backend_code, language="python", lines=20)
            
            # Frontend Code Tab
            with gr.Tab("🎨 Frontend Code (Frontend Engineer)"):
                gr.Markdown("### 🖥️ Frontend Engineer Output")
                gr.Markdown("The Frontend Engineer creates the Gradio web interface:")
                frontend_output = gr.Code(value=frontend_code, language="python", lines=20)
            
            # Test Code Tab
            with gr.Tab("🧪 Test Code (Test Engineer)"):
                gr.Markdown("### ✅ Test Engineer Output")
                gr.Markdown("The Test Engineer creates comprehensive unit tests:")
                test_output = gr.Code(value=test_code, language="python", lines=20)
            
            # Live Demo Tab
            with gr.Tab("🎮 Live Demo"):
                gr.Markdown("### 🚀 Try the Actual App!")
                gr.Markdown("This is the working application your agents built:")
                
                # Show info about live demo
                gr.Markdown("""
                **🚀 Live Demo Available!** 
                
                Click here to try the actual working app: [Open Trading Account App](http://127.0.0.1:7861)
                
                The live demo shows the complete trading account system with:
                - Account creation and management
                - Stock trading (buy/sell AAPL, TSLA, GOOGL)
                - Real-time portfolio tracking
                - Interactive web interface
                """)
        
        # Summary
        with gr.Accordion("📊 What You Get", open=False):
            gr.Markdown("""
            ## 🎉 Complete Software Package
            
            When you run your multi-agent orchestration, you get:
            
            ### 📋 **Design Document** (Engineering Lead)
            - Detailed technical specifications
            - Class and method definitions
            - Architecture overview
            
            ### ⚙️ **Backend Module** (Backend Engineer)
            - Complete Python implementation
            - All business logic
            - Ready to run code
            
            ### 🎨 **Web Interface** (Frontend Engineer)
            - Beautiful Gradio UI
            - Interactive controls
            - User-friendly interface
            
            ### 🧪 **Test Suite** (Test Engineer)
            - Comprehensive unit tests
            - Edge case coverage
            - Quality assurance
            
            ### 🚀 **Working Application**
            - Fully functional system
            - All components integrated
            - Ready for production
            """)
    
    return demo

def main():
    """Main function"""
    print("🚀 Starting Output Demo...")
    print("📱 This shows you what your agents actually build!")
    print("🎮 You'll see real code, real interfaces, and real results!")
    
    demo = create_output_dashboard()
    
    # Also start the live demo on a different port
    print("🎯 Starting live demo on port 7861...")
    try:
        live_demo = run_live_demo()
        live_demo.launch(server_port=7861, share=False, show_error=True)
    except Exception as e:
        print(f"Live demo failed: {e}")
    
    # Start the main dashboard
    demo.launch(
        server_name="127.0.0.1",
        server_port=7862,
        share=False,
        show_error=True
    )

if __name__ == "__main__":
    main()
