#!/usr/bin/env python3
"""
Adaptive Multi-Agent Orchestrator - Main Entry Point
===================================================

This is the main entry point for the Adaptive Multi-Agent Orchestrator system.
It provides both command-line interface and web dashboard access.
"""

import asyncio
import argparse
import logging
import sys
import os
from typing import Optional

# Add the project root to the Python path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from dashboard.app import OrchestratorDashboard
from core.orchestrator import AdaptiveOrchestrator, WorkflowPattern
from core.agent_factory import AgentFactory

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('orchestrator.log'),
        logging.StreamHandler(sys.stdout)
    ]
)

logger = logging.getLogger(__name__)

class OrchestratorCLI:
    """Command-line interface for the orchestrator"""
    
    def __init__(self):
        self.orchestrator = AdaptiveOrchestrator()
        self.agent_factory = AgentFactory()
    
    async def run_task(self, requirements: str, pattern: str = "sequential", 
                      agents: list = None, module_name: str = "module", 
                      class_name: str = "Class") -> dict:
        """Run a task with the orchestrator"""
        try:
            # Initialize orchestrator
            await self.orchestrator.initialize()
            
            # Set workflow pattern
            workflow_pattern = WorkflowPattern(pattern)
            self.orchestrator.switch_workflow_pattern(workflow_pattern)
            
            # Create agents
            if agents is None:
                agents = ["Engineering Lead", "Backend Engineer", "Frontend Engineer", "Test Engineer"]
            
            agent_instances = self.agent_factory.create_agents(agents, len(agents))
            
            if not agent_instances:
                raise ValueError("Failed to create any agents")
            
            logger.info(f"Created {len(agent_instances)} agents for {pattern} workflow")
            
            # Analyze task complexity
            analysis = self.orchestrator.analyze_task_complexity(requirements)
            logger.info(f"Task analysis: {analysis}")
            
            # Create tasks (simplified for CLI)
            from crewai import Task
            
            tasks = [
                Task(
                    description=f"Design the system architecture for: {requirements}",
                    expected_output="Detailed system design and architecture",
                    agent=agent_instances[0] if agent_instances else None
                ),
                Task(
                    description=f"Implement the backend functionality for: {requirements}",
                    expected_output="Complete Python module implementation",
                    agent=agent_instances[1] if len(agent_instances) > 1 else agent_instances[0]
                )
            ]
            
            # Execute workflow
            if pattern == "sequential":
                results = await self.orchestrator.execute_sequential_workflow(tasks, agent_instances)
            elif pattern == "parallel":
                results = await self.orchestrator.execute_parallel_workflow(tasks, agent_instances)
            elif pattern == "hierarchical":
                results = await self.orchestrator.execute_hierarchical_workflow(tasks, agent_instances)
            elif pattern == "hybrid":
                results = await self.orchestrator.execute_hybrid_workflow(tasks, agent_instances)
            else:
                raise ValueError(f"Unknown workflow pattern: {pattern}")
            
            # Get performance metrics
            metrics = self.orchestrator.get_performance_metrics()
            
            return {
                "status": "success",
                "results": results,
                "metrics": metrics,
                "analysis": analysis
            }
            
        except Exception as e:
            logger.error(f"Task execution failed: {e}")
            return {
                "status": "error",
                "error": str(e)
            }
        
        finally:
            await self.orchestrator.cleanup()

def run_dashboard(host: str = "127.0.0.1", port: int = 7860, share: bool = False):
    """Run the web dashboard"""
    print("🚀 Starting Adaptive Multi-Agent Orchestrator Dashboard...")
    print(f"📱 Dashboard will be available at: http://{host}:{port}")
    print("🛑 Press Ctrl+C to stop the dashboard")
    
    try:
        dashboard = OrchestratorDashboard()
        dashboard.launch(share=share, server_name=host, server_port=port)
    except KeyboardInterrupt:
        print("\n👋 Dashboard stopped by user")
    except Exception as e:
        logger.error(f"Dashboard failed to start: {e}")
        sys.exit(1)

async def run_cli_task(requirements: str, pattern: str, agents: list, 
                      module_name: str, class_name: str):
    """Run a task via CLI"""
    cli = OrchestratorCLI()
    
    print(f"🎯 Running task with {pattern} workflow...")
    print(f"📝 Requirements: {requirements}")
    print(f"👥 Agents: {', '.join(agents)}")
    
    result = await cli.run_task(requirements, pattern, agents, module_name, class_name)
    
    if result["status"] == "success":
        print("✅ Task completed successfully!")
        print(f"📊 Performance Metrics:")
        metrics = result["metrics"]
        print(f"   - Total Tasks: {metrics['total_tasks']}")
        print(f"   - Success Rate: {metrics['success_rate']:.1%}")
        print(f"   - Average Duration: {metrics['average_duration']:.1f}s")
        
        print(f"\n🔍 Task Analysis:")
        analysis = result["analysis"]
        print(f"   - Complexity Score: {analysis['complexity_score']}/10")
        print(f"   - Recommended Pattern: {analysis['suggested_pattern'].value}")
        print(f"   - Estimated Duration: {analysis['estimated_duration']//60} minutes")
    else:
        print(f"❌ Task failed: {result['error']}")

def main():
    """Main entry point"""
    parser = argparse.ArgumentParser(
        description="Adaptive Multi-Agent Orchestrator",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Run the web dashboard
  python main.py dashboard
  
  # Run a task via CLI
  python main.py task "Create a task management system" --pattern parallel
  
  # Run with specific agents
  python main.py task "Build a machine learning model" --agents "AI/ML Engineer" "Data Scientist"
        """
    )
    
    subparsers = parser.add_subparsers(dest='command', help='Available commands')
    
    # Dashboard command
    dashboard_parser = subparsers.add_parser('dashboard', help='Run the web dashboard')
    dashboard_parser.add_argument('--host', default='127.0.0.1', help='Dashboard host (default: 127.0.0.1)')
    dashboard_parser.add_argument('--port', type=int, default=7860, help='Dashboard port (default: 7860)')
    dashboard_parser.add_argument('--share', action='store_true', help='Share dashboard publicly')
    
    # Task command
    task_parser = subparsers.add_parser('task', help='Run a task via CLI')
    task_parser.add_argument('requirements', help='Task requirements')
    task_parser.add_argument('--pattern', choices=['sequential', 'parallel', 'hierarchical', 'hybrid'],
                           default='sequential', help='Workflow pattern (default: sequential)')
    task_parser.add_argument('--agents', nargs='+', 
                           choices=['Engineering Lead', 'Backend Engineer', 'Frontend Engineer', 
                                   'Test Engineer', 'AI/ML Engineer', 'Data Scientist', 
                                   'DevOps Engineer', 'Security Engineer', 'Performance Engineer'],
                           help='Agent types to use')
    task_parser.add_argument('--module-name', default='module', help='Module name (default: module)')
    task_parser.add_argument('--class-name', default='Class', help='Class name (default: Class)')
    
    # Analyze command
    analyze_parser = subparsers.add_parser('analyze', help='Analyze task complexity')
    analyze_parser.add_argument('requirements', help='Task requirements to analyze')
    
    args = parser.parse_args()
    
    if not args.command:
        parser.print_help()
        return
    
    try:
        if args.command == 'dashboard':
            run_dashboard(args.host, args.port, args.share)
        
        elif args.command == 'task':
            if args.agents is None:
                args.agents = ["Engineering Lead", "Backend Engineer", "Frontend Engineer", "Test Engineer"]
            
            asyncio.run(run_cli_task(
                args.requirements, 
                args.pattern, 
                args.agents, 
                args.module_name, 
                args.class_name
            ))
        
        elif args.command == 'analyze':
            orchestrator = AdaptiveOrchestrator()
            analysis = orchestrator.analyze_task_complexity(args.requirements)
            
            print("🔍 Task Analysis Results:")
            print(f"   Complexity Score: {analysis['complexity_score']}/10")
            print(f"   Recommended Agents: {', '.join(analysis['recommended_agents'])}")
            print(f"   Suggested Pattern: {analysis['suggested_pattern'].value}")
            print(f"   Estimated Duration: {analysis['estimated_duration']//60} minutes")
            
            if analysis['complexity_score'] >= 8:
                print("   💡 Recommendation: Use hierarchical workflow with multiple specialized agents")
            elif analysis['complexity_score'] >= 5:
                print("   💡 Recommendation: Use hybrid workflow with mixed patterns")
            elif analysis['complexity_score'] >= 3:
                print("   💡 Recommendation: Use parallel workflow for independent tasks")
            else:
                print("   💡 Recommendation: Sequential workflow is sufficient")
    
    except KeyboardInterrupt:
        print("\n👋 Operation cancelled by user")
    except Exception as e:
        logger.error(f"Operation failed: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()
