#!/usr/bin/env python3
"""
🚀 Adaptive Multi-Agent Orchestrator - Demo Script
=================================================

This demo script showcases the amazing capabilities of your new multi-agent system!
"""

import asyncio
import sys
import os

# Add the project root to the Python path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from core.orchestrator import AdaptiveOrchestrator, WorkflowPattern
from core.agent_factory import AgentFactory

async def demo_adaptive_orchestration():
    """
    Demo the adaptive orchestration capabilities
    """
    print("🚀 Adaptive Multi-Agent Orchestrator Demo")
    print("=" * 50)
    
    # Initialize orchestrator
    orchestrator = AdaptiveOrchestrator()
    agent_factory = AgentFactory()
    
    print("✅ Orchestrator initialized!")
    
    # Demo 1: Task Analysis
    print("\n🔍 Demo 1: Intelligent Task Analysis")
    print("-" * 40)
    
    sample_requirements = """
    Create a machine learning-powered task management system with the following features:
    - AI-powered task prioritization
    - Real-time collaboration
    - Advanced analytics dashboard
    - RESTful API with authentication
    - Docker containerization
    - Comprehensive test suite
    """
    
    analysis = orchestrator.analyze_task_complexity(sample_requirements)
    print(f"📊 Complexity Score: {analysis['complexity_score']}/10")
    print(f"🎯 Recommended Agents: {', '.join(analysis['recommended_agents'])}")
    print(f"🔄 Suggested Pattern: {analysis['suggested_pattern'].value}")
    print(f"⏱️ Estimated Duration: {analysis['estimated_duration']//60} minutes")
    
    # Demo 2: Agent Creation
    print("\n👥 Demo 2: Dynamic Agent Creation")
    print("-" * 40)
    
    agent_types = ["Engineering Lead", "Backend Engineer", "AI/ML Engineer", "DevOps Engineer"]
    agents = agent_factory.create_agents(agent_types, 4)
    
    print(f"✅ Created {len(agents)} specialized agents:")
    for agent in agents:
        print(f"   - {agent.role}")
    
    # Demo 3: Workflow Pattern Switching
    print("\n🔄 Demo 3: Dynamic Workflow Switching")
    print("-" * 40)
    
    patterns = [WorkflowPattern.SEQUENTIAL, WorkflowPattern.PARALLEL, 
                WorkflowPattern.HIERARCHICAL, WorkflowPattern.HYBRID]
    
    for pattern in patterns:
        orchestrator.switch_workflow_pattern(pattern)
        print(f"✅ Switched to {pattern.value} workflow pattern")
        
        # Simulate some metrics
        metrics = orchestrator.get_performance_metrics()
        print(f"   📊 Current metrics: {metrics['total_tasks']} tasks, {metrics['success_rate']:.1%} success rate")
    
    # Demo 4: Agent Capabilities
    print("\n🧠 Demo 4: Agent Capabilities Matrix")
    print("-" * 40)
    
    capabilities = agent_factory.get_agent_capabilities()
    for agent_type, caps in capabilities.items():
        print(f"🤖 {agent_type}: {', '.join(caps) if caps else 'Basic capabilities'}")
    
    print("\n🎉 Demo completed successfully!")
    print("💡 Your Adaptive Multi-Agent Orchestrator is ready to revolutionize software development!")

def demo_dashboard_launch():
    """
    Demo launching the dashboard
    """
    print("\n🌐 Launching Interactive Dashboard...")
    print("📱 The dashboard will open in your browser")
    print("🎮 You can interact with the orchestrator in real-time!")
    
    try:
        from dashboard.app import OrchestratorDashboard
        dashboard = OrchestratorDashboard()
        dashboard.launch(server_port=7860)
    except Exception as e:
        print(f"❌ Failed to launch dashboard: {e}")
        print("💡 Make sure you have all dependencies installed: pip install -r requirements.txt")

def main():
    """Main demo function"""
    print("🎬 Starting Adaptive Multi-Agent Orchestrator Demo")
    
    # Check if user wants to run async demo or dashboard
    choice = input("\nChoose demo mode:\n1. Run orchestration demo (async)\n2. Launch dashboard\nEnter choice (1 or 2): ").strip()
    
    if choice == "1":
        try:
            asyncio.run(demo_adaptive_orchestration())
        except Exception as e:
            print(f"❌ Demo failed: {e}")
    elif choice == "2":
        demo_dashboard_launch()
    else:
        print("❌ Invalid choice. Please run again and select 1 or 2.")
    
    print("\n🚀 Thank you for exploring the Adaptive Multi-Agent Orchestrator!")
    print("🌟 This system combines the best of CrewAI and AutoGen with intelligent orchestration!")

if __name__ == "__main__":
    main()
