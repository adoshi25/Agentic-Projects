"""
Agent Factory for Adaptive Multi-Agent Orchestrator
==================================================

This module provides factory methods for creating different types of agents
with specialized configurations for various orchestration patterns.
"""

import yaml
import logging
from typing import List, Dict, Any, Optional
from crewai import Agent

logger = logging.getLogger(__name__)

class AgentFactory:
    """
    Factory class for creating specialized agents for the orchestrator
    """
    
    def __init__(self, config_path: str = "config/agents.yaml"):
        self.config = self._load_agent_config(config_path)
        self.created_agents = {}
    
    def _load_agent_config(self, config_path: str) -> Dict[str, Any]:
        """Load agent configuration from YAML file"""
        try:
            with open(config_path, 'r') as f:
                return yaml.safe_load(f)
        except Exception as e:
            logger.error(f"Failed to load agent config: {e}")
            return {}
    
    def create_agents(self, agent_types: List[str], count: int = 1) -> List[Agent]:
        """
        Create agents of specified types
        
        Args:
            agent_types: List of agent type names
            count: Number of agents to create (total, not per type)
            
        Returns:
            List of Agent instances
        """
        agents = []
        agents_per_type = count // len(agent_types) if agent_types else 1
        
        for agent_type in agent_types:
            for i in range(agents_per_type):
                agent = self.create_agent(agent_type, f"{agent_type}_{i+1}")
                if agent:
                    agents.append(agent)
        
        # Add remaining agents if count doesn't divide evenly
        remaining = count - len(agents)
        if remaining > 0 and agent_types:
            for i in range(remaining):
                agent_type = agent_types[i % len(agent_types)]
                agent = self.create_agent(agent_type, f"{agent_type}_{len(agents)+1}")
                if agent:
                    agents.append(agent)
        
        return agents
    
    def create_agent(self, agent_type: str, agent_id: Optional[str] = None) -> Optional[Agent]:
        """
        Create a single agent of specified type
        
        Args:
            agent_type: Type of agent to create
            agent_id: Unique identifier for the agent
            
        Returns:
            Agent instance or None if creation failed
        """
        try:
            # Map display names to config keys
            type_mapping = {
                "Engineering Lead": "engineering_lead",
                "Backend Engineer": "backend_engineer", 
                "Frontend Engineer": "frontend_engineer",
                "Test Engineer": "test_engineer",
                "AI/ML Engineer": "ai_ml_engineer",
                "Data Scientist": "data_scientist",
                "DevOps Engineer": "devops_engineer",
                "Security Engineer": "security_engineer",
                "Performance Engineer": "performance_engineer",
                "Documentation Engineer": "documentation_engineer"
            }
            
            config_key = type_mapping.get(agent_type, agent_type.lower())
            
            if config_key not in self.config:
                logger.error(f"Unknown agent type: {agent_type}")
                return None
            
            agent_config = self.config[config_key]
            
            # Create agent with configuration
            agent = Agent(
                role=agent_config.get('role', agent_type),
                goal=agent_config.get('goal', f"Complete tasks as a {agent_type}"),
                backstory=agent_config.get('backstory', f"I am a {agent_type}."),
                llm=agent_config.get('llm', 'gpt-4o-mini'),
                verbose=True,
                allow_delegation=False
            )
            
            # Add specialized properties
            if agent_id:
                agent.agent_id = agent_id
                self.created_agents[agent_id] = agent
            
            # Add code execution capabilities if specified
            if agent_config.get('allow_code_execution', False):
                agent.allow_code_execution = True
                agent.code_execution_mode = agent_config.get('code_execution_mode', 'safe')
                agent.max_execution_time = agent_config.get('max_execution_time', 300)
                agent.max_retry_limit = agent_config.get('max_retry_limit', 3)
            
            logger.info(f"Created agent: {agent_type} ({agent_id})")
            return agent
            
        except Exception as e:
            logger.error(f"Failed to create agent {agent_type}: {e}")
            return None
    
    def create_specialized_agent(self, specialization: str, **kwargs) -> Optional[Agent]:
        """
        Create an agent with specific specialization
        
        Args:
            specialization: Agent specialization (architecture, backend, frontend, etc.)
            **kwargs: Additional configuration parameters
            
        Returns:
            Agent instance or None if creation failed
        """
        # Find agents with matching specialization
        specialized_agents = []
        for config_key, config in self.config.items():
            if config.get('specialization') == specialization:
                specialized_agents.append(config_key)
        
        if not specialized_agents:
            logger.warning(f"No agents found with specialization: {specialization}")
            return None
        
        # Use the first matching agent type
        agent_type = specialized_agents[0]
        return self.create_agent(agent_type, **kwargs)
    
    def create_agent_pool(self, pool_config: Dict[str, Any]) -> Dict[str, List[Agent]]:
        """
        Create pools of agents based on configuration
        
        Args:
            pool_config: Configuration for agent pools
            
        Returns:
            Dictionary mapping pool names to lists of agents
        """
        pools = {}
        
        for pool_name, pool_settings in pool_config.items():
            agent_types = pool_settings.get('agents', [])
            min_instances = pool_settings.get('min_instances', 1)
            max_instances = pool_settings.get('max_instances', 3)
            
            # Create agents for this pool
            pool_agents = []
            for agent_type in agent_types:
                for i in range(min_instances):
                    agent = self.create_agent(agent_type, f"{pool_name}_{agent_type}_{i+1}")
                    if agent:
                        pool_agents.append(agent)
            
            pools[pool_name] = pool_agents
            logger.info(f"Created pool '{pool_name}' with {len(pool_agents)} agents")
        
        return pools
    
    def get_agent_by_id(self, agent_id: str) -> Optional[Agent]:
        """Get an agent by its ID"""
        return self.created_agents.get(agent_id)
    
    def get_agents_by_type(self, agent_type: str) -> List[Agent]:
        """Get all agents of a specific type"""
        return [agent for agent in self.created_agents.values() 
                if hasattr(agent, 'role') and agent.role == agent_type]
    
    def get_available_agents(self) -> List[Agent]:
        """Get all created agents"""
        return list(self.created_agents.values())
    
    def get_agent_capabilities(self) -> Dict[str, List[str]]:
        """
        Get capabilities matrix for all agent types
        
        Returns:
            Dictionary mapping agent types to their capabilities
        """
        capabilities = {}
        
        for agent_type, config in self.config.items():
            agent_caps = []
            
            if config.get('allow_code_execution'):
                agent_caps.append('code_execution')
            
            if 'docker' in config.get('code_execution_mode', '').lower():
                agent_caps.append('containerized_execution')
            
            if config.get('specialization'):
                agent_caps.append(f"specialized_{config['specialization']}")
            
            # Infer capabilities from role/goal
            role_lower = config.get('role', '').lower()
            if 'lead' in role_lower or 'manager' in role_lower:
                agent_caps.append('management')
            
            if 'test' in role_lower:
                agent_caps.append('testing')
            
            if 'frontend' in role_lower or 'ui' in role_lower:
                agent_caps.append('frontend_development')
            
            if 'backend' in role_lower or 'api' in role_lower:
                agent_caps.append('backend_development')
            
            if 'ai' in role_lower or 'ml' in role_lower:
                agent_caps.append('ai_ml')
            
            if 'devops' in role_lower or 'deployment' in role_lower:
                agent_caps.append('devops')
            
            if 'security' in role_lower:
                agent_caps.append('security')
            
            if 'performance' in role_lower:
                agent_caps.append('performance_optimization')
            
            capabilities[agent_type] = agent_caps
        
        return capabilities
    
    def create_adaptive_agent(self, requirements: str, **kwargs) -> Optional[Agent]:
        """
        Create an agent optimized for specific requirements
        
        Args:
            requirements: Task requirements to optimize for
            **kwargs: Additional configuration parameters
            
        Returns:
            Agent instance optimized for the requirements
        """
        requirements_lower = requirements.lower()
        
        # Analyze requirements to determine best agent type
        if any(keyword in requirements_lower for keyword in ['machine learning', 'ai', 'neural network']):
            return self.create_specialized_agent('ai_ml', **kwargs)
        elif any(keyword in requirements_lower for keyword in ['api', 'backend', 'database']):
            return self.create_specialized_agent('backend', **kwargs)
        elif any(keyword in requirements_lower for keyword in ['frontend', 'ui', 'interface']):
            return self.create_specialized_agent('frontend', **kwargs)
        elif any(keyword in requirements_lower for keyword in ['test', 'testing', 'quality']):
            return self.create_specialized_agent('testing', **kwargs)
        elif any(keyword in requirements_lower for keyword in ['security', 'secure', 'vulnerability']):
            return self.create_specialized_agent('security', **kwargs)
        elif any(keyword in requirements_lower for keyword in ['performance', 'optimize', 'speed']):
            return self.create_specialized_agent('performance', **kwargs)
        elif any(keyword in requirements_lower for keyword in ['docker', 'deploy', 'infrastructure']):
            return self.create_specialized_agent('devops', **kwargs)
        elif any(keyword in requirements_lower for keyword in ['documentation', 'docs', 'guide']):
            return self.create_specialized_agent('documentation', **kwargs)
        else:
            # Default to engineering lead for complex projects
            return self.create_agent('Engineering Lead', **kwargs)
