"""
Adaptive Multi-Agent Orchestrator
=================================

This module provides the core orchestration engine that can dynamically switch
between different workflow patterns based on task requirements and system state.
"""

import asyncio
import yaml
import logging
from typing import Dict, List, Optional, Any, Union
from enum import Enum
from dataclasses import dataclass
from datetime import datetime
import json

from crewai import Agent, Crew, Process, Task
from autogen_ext.runtimes.grpc import GrpcWorkerAgentRuntimeHost, GrpcWorkerAgentRuntime
from autogen_core import AgentId

logger = logging.getLogger(__name__)

class WorkflowPattern(Enum):
    SEQUENTIAL = "sequential"
    PARALLEL = "parallel"
    HIERARCHICAL = "hierarchical"
    HYBRID = "hybrid"

@dataclass
class TaskMetrics:
    """Metrics for tracking task performance"""
    task_id: str
    start_time: datetime
    end_time: Optional[datetime] = None
    agent_id: Optional[str] = None
    status: str = "pending"
    error_count: int = 0
    retry_count: int = 0
    
    @property
    def duration(self) -> Optional[float]:
        if self.end_time:
            return (self.end_time - self.start_time).total_seconds()
        return None

@dataclass
class AgentState:
    """State information for each agent"""
    agent_id: str
    agent_type: str
    status: str = "idle"  # idle, busy, error
    current_task: Optional[str] = None
    tasks_completed: int = 0
    error_count: int = 0
    last_activity: datetime = None

class AdaptiveOrchestrator:
    """
    Main orchestrator class that manages multi-agent workflows with adaptive patterns
    """
    
    def __init__(self, config_path: str = "config/orchestration.yaml"):
        self.config = self._load_config(config_path)
        self.workflow_pattern = WorkflowPattern.SEQUENTIAL
        self.agents: Dict[str, Agent] = {}
        self.agent_states: Dict[str, AgentState] = {}
        self.task_metrics: Dict[str, TaskMetrics] = {}
        self.runtime_host = None
        self.runtime_worker = None
        
        # Performance tracking
        self.performance_history = []
        self.communication_log = []
        
    def _load_config(self, config_path: str) -> Dict[str, Any]:
        """Load orchestration configuration"""
        try:
            with open(config_path, 'r') as f:
                return yaml.safe_load(f)
        except Exception as e:
            logger.error(f"Failed to load config: {e}")
            return {}
    
    async def initialize(self):
        """Initialize the orchestrator and agent runtime"""
        try:
            # Initialize gRPC runtime for distributed communication
            self.runtime_host = GrpcWorkerAgentRuntimeHost(
                address=f"{self.config['communication']['host']}:{self.config['communication']['port']}"
            )
            self.runtime_host.start()
            
            self.runtime_worker = GrpcWorkerAgentRuntime(
                host_address=f"{self.config['communication']['host']}:{self.config['communication']['port']}"
            )
            await self.runtime_worker.start()
            
            logger.info("Orchestrator initialized successfully")
            
        except Exception as e:
            logger.error(f"Failed to initialize orchestrator: {e}")
            raise
    
    def switch_workflow_pattern(self, pattern: WorkflowPattern):
        """Switch the current workflow pattern"""
        if pattern in [WorkflowPattern(p) for p in self.config['workflow_patterns'].keys()]:
            self.workflow_pattern = pattern
            logger.info(f"Switched to {pattern.value} workflow pattern")
        else:
            raise ValueError(f"Unsupported workflow pattern: {pattern}")
    
    def analyze_task_complexity(self, requirements: str) -> Dict[str, Any]:
        """Analyze task requirements to determine optimal orchestration approach"""
        complexity_score = 0
        recommended_agents = set()
        suggested_pattern = WorkflowPattern.SEQUENTIAL
        
        # Analyze keywords and complexity indicators
        requirements_lower = requirements.lower()
        
        # Check for complexity indicators
        complexity_indicators = [
            ("machine learning", 3),
            ("ai", 2),
            ("data analysis", 2),
            ("api", 1),
            ("database", 1),
            ("security", 2),
            ("performance", 2),
            ("testing", 1),
            ("deployment", 2),
            ("integration", 2)
        ]
        
        for keyword, weight in complexity_indicators:
            if keyword in requirements_lower:
                complexity_score += weight
        
        # Determine recommended agents based on keywords
        routing_rules = self.config.get('task_routing', {}).get('keywords', {})
        for keyword, agents in routing_rules.items():
            if keyword in requirements_lower:
                recommended_agents.update(agents)
        
        # Suggest workflow pattern based on complexity
        if complexity_score >= 8:
            suggested_pattern = WorkflowPattern.HIERARCHICAL
        elif complexity_score >= 5:
            suggested_pattern = WorkflowPattern.HYBRID
        elif len(recommended_agents) > 4:
            suggested_pattern = WorkflowPattern.PARALLEL
        else:
            suggested_pattern = WorkflowPattern.SEQUENTIAL
        
        return {
            "complexity_score": complexity_score,
            "recommended_agents": list(recommended_agents),
            "suggested_pattern": suggested_pattern,
            "estimated_duration": min(complexity_score * 60, 1800)  # seconds
        }
    
    async def execute_sequential_workflow(self, tasks: List[Task], agents: List[Agent]) -> Dict[str, Any]:
        """Execute tasks in sequential order with dependencies"""
        results = {}
        
        for task in tasks:
            task_id = f"task_{len(self.task_metrics)}"
            metrics = TaskMetrics(task_id=task_id, start_time=datetime.now())
            self.task_metrics[task_id] = metrics
            
            try:
                # Find suitable agent for this task
                agent = self._find_suitable_agent(task, agents)
                if not agent:
                    raise ValueError(f"No suitable agent found for task: {task.description}")
                
                # Update agent state
                self._update_agent_state(agent.role, "busy", task_id)
                metrics.agent_id = agent.role
                
                # Execute task
                logger.info(f"Executing task {task_id} with agent {agent.role}")
                result = await self._execute_task_with_agent(task, agent)
                
                results[task_id] = result
                metrics.status = "completed"
                metrics.end_time = datetime.now()
                
                # Update agent state
                self._update_agent_state(agent.role, "idle")
                
            except Exception as e:
                logger.error(f"Task {task_id} failed: {e}")
                metrics.status = "failed"
                metrics.error_count += 1
                metrics.end_time = datetime.now()
                results[task_id] = {"error": str(e)}
        
        return results
    
    async def execute_parallel_workflow(self, tasks: List[Task], agents: List[Agent]) -> Dict[str, Any]:
        """Execute tasks in parallel using asyncio"""
        async def execute_single_task(task, agent):
            task_id = f"task_{len(self.task_metrics)}"
            metrics = TaskMetrics(task_id=task_id, start_time=datetime.now())
            self.task_metrics[task_id] = metrics
            
            try:
                self._update_agent_state(agent.role, "busy", task_id)
                metrics.agent_id = agent.role
                
                logger.info(f"Executing task {task_id} with agent {agent.role}")
                result = await self._execute_task_with_agent(task, agent)
                
                metrics.status = "completed"
                metrics.end_time = datetime.now()
                self._update_agent_state(agent.role, "idle")
                
                return task_id, result
                
            except Exception as e:
                logger.error(f"Task {task_id} failed: {e}")
                metrics.status = "failed"
                metrics.error_count += 1
                metrics.end_time = datetime.now()
                self._update_agent_state(agent.role, "idle")
                
                return task_id, {"error": str(e)}
        
        # Create coroutines for all tasks
        coroutines = []
        for task in tasks:
            agent = self._find_suitable_agent(task, agents)
            if agent:
                coroutines.append(execute_single_task(task, agent))
        
        # Execute all tasks in parallel
        results = {}
        if coroutines:
            task_results = await asyncio.gather(*coroutines, return_exceptions=True)
            for task_id, result in task_results:
                if not isinstance(result, Exception):
                    results[task_id] = result
        
        return results
    
    async def execute_hierarchical_workflow(self, tasks: List[Task], agents: List[Agent]) -> Dict[str, Any]:
        """Execute tasks with hierarchical delegation through a manager agent"""
        # Find or create a manager agent
        manager = self._find_or_create_manager(agents)
        
        # Delegate tasks to manager
        results = {}
        for task in tasks:
            task_id = f"task_{len(self.task_metrics)}"
            metrics = TaskMetrics(task_id=task_id, start_time=datetime.now())
            self.task_metrics[task_id] = metrics
            
            try:
                # Manager decides which agent should handle the task
                delegated_agent = await self._delegate_task_to_manager(task, manager, agents)
                
                if delegated_agent:
                    self._update_agent_state(delegated_agent.role, "busy", task_id)
                    metrics.agent_id = delegated_agent.role
                    
                    result = await self._execute_task_with_agent(task, delegated_agent)
                    results[task_id] = result
                    
                    metrics.status = "completed"
                    metrics.end_time = datetime.now()
                    self._update_agent_state(delegated_agent.role, "idle")
                else:
                    raise ValueError("Manager could not delegate task")
                    
            except Exception as e:
                logger.error(f"Hierarchical task {task_id} failed: {e}")
                metrics.status = "failed"
                metrics.error_count += 1
                metrics.end_time = datetime.now()
                results[task_id] = {"error": str(e)}
        
        return results
    
    async def execute_hybrid_workflow(self, tasks: List[Task], agents: List[Agent]) -> Dict[str, Any]:
        """Execute tasks using intelligent pattern mixing"""
        # Analyze each task to determine optimal execution pattern
        task_groups = {
            "sequential": [],
            "parallel": [],
            "hierarchical": []
        }
        
        for task in tasks:
            analysis = self.analyze_task_complexity(task.description)
            
            if analysis["complexity_score"] >= 6:
                task_groups["hierarchical"].append(task)
            elif len(analysis["recommended_agents"]) <= 2:
                task_groups["sequential"].append(task)
            else:
                task_groups["parallel"].append(task)
        
        # Execute each group with appropriate pattern
        results = {}
        
        # Sequential group
        if task_groups["sequential"]:
            seq_results = await self.execute_sequential_workflow(
                task_groups["sequential"], agents
            )
            results.update(seq_results)
        
        # Parallel group
        if task_groups["parallel"]:
            par_results = await self.execute_parallel_workflow(
                task_groups["parallel"], agents
            )
            results.update(par_results)
        
        # Hierarchical group
        if task_groups["hierarchical"]:
            hier_results = await self.execute_hierarchical_workflow(
                task_groups["hierarchical"], agents
            )
            results.update(hier_results)
        
        return results
    
    def _find_suitable_agent(self, task: Task, agents: List[Agent]) -> Optional[Agent]:
        """Find the most suitable agent for a task"""
        # Simple heuristic - could be enhanced with ML
        task_desc = task.description.lower()
        
        for agent in agents:
            if hasattr(agent, 'role'):
                agent_role = agent.role.lower()
                if any(keyword in agent_role for keyword in task_desc.split()):
                    return agent
        
        # Fallback to first available agent
        return agents[0] if agents else None
    
    def _find_or_create_manager(self, agents: List[Agent]) -> Agent:
        """Find or create a manager agent for hierarchical workflows"""
        # Look for existing manager/lead agent
        for agent in agents:
            if hasattr(agent, 'role') and 'lead' in agent.role.lower():
                return agent
        
        # Create a simple manager agent if none exists
        manager = Agent(
            role="Project Manager",
            goal="Delegate tasks to appropriate team members and coordinate project execution",
            backstory="Experienced project manager with excellent delegation skills",
            verbose=True
        )
        return manager
    
    async def _delegate_task_to_manager(self, task: Task, manager: Agent, agents: List[Agent]) -> Optional[Agent]:
        """Let manager decide which agent should handle the task"""
        # This is a simplified version - in practice, you'd use the manager agent's LLM
        # to analyze the task and select the best agent
        
        analysis = self.analyze_task_complexity(task.description)
        recommended_agents = analysis["recommended_agents"]
        
        # Find agents matching recommendations
        for agent in agents:
            if hasattr(agent, 'role') and agent.role in recommended_agents:
                return agent
        
        # Fallback to first available agent
        return agents[0] if agents else None
    
    async def _execute_task_with_agent(self, task: Task, agent: Agent) -> Any:
        """Execute a task with a specific agent"""
        # This is a simplified execution - in practice, you'd use CrewAI's execution
        # or AutoGen's agent communication
        
        try:
            # Simulate task execution
            await asyncio.sleep(1)  # Simulate processing time
            
            # In real implementation, this would call the agent's execute method
            return {
                "task_id": task.description[:50],
                "agent": agent.role,
                "status": "completed",
                "result": f"Task completed by {agent.role}",
                "timestamp": datetime.now().isoformat()
            }
            
        except Exception as e:
            logger.error(f"Task execution failed: {e}")
            raise
    
    def _update_agent_state(self, agent_id: str, status: str, current_task: Optional[str] = None):
        """Update agent state information"""
        if agent_id not in self.agent_states:
            self.agent_states[agent_id] = AgentState(
                agent_id=agent_id,
                agent_type=agent_id,
                last_activity=datetime.now()
            )
        
        state = self.agent_states[agent_id]
        state.status = status
        state.current_task = current_task
        state.last_activity = datetime.now()
        
        if status == "idle" and current_task is None:
            state.tasks_completed += 1
    
    def get_performance_metrics(self) -> Dict[str, Any]:
        """Get current performance metrics"""
        total_tasks = len(self.task_metrics)
        completed_tasks = sum(1 for m in self.task_metrics.values() if m.status == "completed")
        failed_tasks = sum(1 for m in self.task_metrics.values() if m.status == "failed")
        
        avg_duration = 0
        if completed_tasks > 0:
            durations = [m.duration for m in self.task_metrics.values() if m.duration]
            avg_duration = sum(durations) / len(durations) if durations else 0
        
        return {
            "total_tasks": total_tasks,
            "completed_tasks": completed_tasks,
            "failed_tasks": failed_tasks,
            "success_rate": completed_tasks / total_tasks if total_tasks > 0 else 0,
            "average_duration": avg_duration,
            "active_agents": len([s for s in self.agent_states.values() if s.status == "busy"]),
            "idle_agents": len([s for s in self.agent_states.values() if s.status == "idle"]),
            "current_pattern": self.workflow_pattern.value
        }
    
    async def cleanup(self):
        """Clean up resources"""
        try:
            if self.runtime_worker:
                await self.runtime_worker.stop()
            if self.runtime_host:
                await self.runtime_host.stop()
            logger.info("Orchestrator cleaned up successfully")
        except Exception as e:
            logger.error(f"Error during cleanup: {e}")
