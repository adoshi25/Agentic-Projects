#!/usr/bin/env python3
"""
🚀 Adaptive Multi-Agent Orchestrator - Setup Script
==================================================

Quick setup script to get your orchestrator running!
"""

import os
import sys
import subprocess
import platform

def print_banner():
    """Print a cool banner"""
    print("""
╔══════════════════════════════════════════════════════════════════════════════╗
║                                                                              ║
║  🚀 ADAPTIVE MULTI-AGENT ORCHESTRATOR SETUP 🚀                              ║
║                                                                              ║
║  Your revolutionary multi-agent system with dynamic workflow switching!     ║
║                                                                              ║
╚══════════════════════════════════════════════════════════════════════════════╝
    """)

def check_python_version():
    """Check if Python version is compatible"""
    version = sys.version_info
    if version.major < 3 or (version.major == 3 and version.minor < 10):
        print("❌ Python 3.10 or higher is required!")
        print(f"   Current version: {version.major}.{version.minor}.{version.micro}")
        return False
    
    print(f"✅ Python {version.major}.{version.minor}.{version.micro} detected")
    return True

def install_dependencies():
    """Install required dependencies"""
    print("\n📦 Installing dependencies...")
    
    try:
        # Install from requirements.txt
        subprocess.check_call([sys.executable, "-m", "pip", "install", "-r", "requirements.txt"])
        print("✅ Dependencies installed successfully!")
        return True
    except subprocess.CalledProcessError as e:
        print(f"❌ Failed to install dependencies: {e}")
        return False

def check_docker():
    """Check if Docker is available"""
    try:
        subprocess.run(["docker", "--version"], capture_output=True, check=True)
        print("✅ Docker is available")
        return True
    except (subprocess.CalledProcessError, FileNotFoundError):
        print("⚠️  Docker not found - code execution will be limited")
        print("   Install Docker Desktop for full functionality: https://docs.docker.com/desktop/")
        return False

def create_env_file():
    """Create .env file if it doesn't exist"""
    env_file = ".env"
    if not os.path.exists(env_file):
        print(f"\n🔧 Creating {env_file} file...")
        
        with open(env_file, "w") as f:
            f.write("# Adaptive Multi-Agent Orchestrator Configuration\n")
            f.write("# Add your OpenAI API key here\n")
            f.write("OPENAI_API_KEY=your_openai_api_key_here\n")
            f.write("\n# Optional: Customize other settings\n")
            f.write("# GRPC_HOST=localhost\n")
            f.write("# GRPC_PORT=50051\n")
        
        print(f"✅ Created {env_file} - please add your OpenAI API key!")
        return False
    else:
        print("✅ .env file already exists")
        return True

def run_demo():
    """Run the demo to test the system"""
    print("\n🎬 Running system demo...")
    
    try:
        subprocess.run([sys.executable, "demo.py"], check=True)
        return True
    except subprocess.CalledProcessError:
        print("❌ Demo failed - check your configuration")
        return False

def main():
    """Main setup function"""
    print_banner()
    
    # Check Python version
    if not check_python_version():
        sys.exit(1)
    
    # Check Docker
    docker_available = check_docker()
    
    # Install dependencies
    if not install_dependencies():
        print("\n❌ Setup failed during dependency installation")
        sys.exit(1)
    
    # Create .env file
    env_ready = create_env_file()
    
    print("\n🎉 Setup completed successfully!")
    print("\n📋 Next steps:")
    print("   1. Add your OpenAI API key to the .env file")
    print("   2. Run the demo: python demo.py")
    print("   3. Launch the dashboard: python main.py dashboard")
    print("   4. Try a CLI task: python main.py task 'Create a calculator app'")
    
    if not docker_available:
        print("\n⚠️  Note: Install Docker for full agent capabilities")
    
    if not env_ready:
        print("\n🔑 Don't forget to add your OpenAI API key to .env!")
    
    print("\n🚀 Your Adaptive Multi-Agent Orchestrator is ready!")
    print("🌟 Features:")
    print("   • Dynamic workflow switching (Sequential/Parallel/Hierarchical/Hybrid)")
    print("   • Real-time monitoring dashboard")
    print("   • 9 specialized agent types")
    print("   • Intelligent task analysis")
    print("   • Docker-based code execution")
    print("   • Performance metrics and analytics")

if __name__ == "__main__":
    main()
