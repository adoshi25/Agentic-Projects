"""
Adaptive Multi-Agent Orchestrator Dashboard
==========================================

A beautiful, real-time dashboard for monitoring and controlling the multi-agent system.
Built with Gradio for an intuitive web interface.
"""

import gradio as gr
import plotly.graph_objects as go
import plotly.express as px
import pandas as pd
import json
import asyncio
import threading
import time
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional
import networkx as nx
import numpy as np

from core.orchestrator import AdaptiveOrchestrator, WorkflowPattern
from core.agent_factory import AgentFactory

class OrchestratorDashboard:
    """
    Main dashboard class that provides the web interface for the orchestrator
    """
    
    def __init__(self):
        self.orchestrator = AdaptiveOrchestrator()
        self.agent_factory = AgentFactory()
        self.is_running = False
        self.current_session = None
        self.performance_data = []
        self.communication_log = []
        
        # Initialize dashboard components
        self._setup_dashboard()
    
    def _setup_dashboard(self):
        """Setup the Gradio dashboard interface"""
        
        # Custom CSS for modern styling
        custom_css = """
        .gradio-container {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        }
        .main-header {
            text-align: center;
            color: white;
            padding: 20px;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 10px;
            margin-bottom: 20px;
        }
        .metric-card {
            background: rgba(255, 255, 255, 0.9);
            padding: 15px;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            margin: 10px;
        }
        .status-running { color: #28a745; font-weight: bold; }
        .status-stopped { color: #dc3545; font-weight: bold; }
        .agent-node { 
            fill: #4CAF50; 
            stroke: #2E7D32; 
            stroke-width: 2px; 
        }
        .agent-busy { fill: #FF9800; }
        .agent-idle { fill: #4CAF50; }
        .agent-error { fill: #F44336; }
        """
        
        with gr.Blocks(css=custom_css, title="🚀 Adaptive Multi-Agent Orchestrator") as self.demo:
            
            # Header
            gr.HTML("""
                <div class="main-header">
                    <h1>🚀 Adaptive Multi-Agent Orchestrator</h1>
                    <p>Real-time monitoring and control of your AI agent workforce</p>
                </div>
            """)
            
            with gr.Row():
                # Left Panel - Controls
                with gr.Column(scale=1):
                    gr.Markdown("## 🎛️ Control Panel")
                    
                    # Workflow Pattern Selection
                    workflow_pattern = gr.Dropdown(
                        choices=[
                            ("Sequential Orchestration", "sequential"),
                            ("Parallel Orchestration", "parallel"),
                            ("Hierarchical Orchestration", "hierarchical"),
                            ("Hybrid Orchestration", "hybrid")
                        ],
                        value="sequential",
                        label="🔄 Workflow Pattern",
                        interactive=True
                    )
                    
                    # Agent Configuration
                    with gr.Group():
                        gr.Markdown("### 👥 Agent Configuration")
                        
                        agent_types = gr.CheckboxGroup(
                            choices=[
                                "Engineering Lead", "Backend Engineer", "Frontend Engineer",
                                "Test Engineer", "AI/ML Engineer", "Data Scientist",
                                "DevOps Engineer", "Security Engineer", "Performance Engineer"
                            ],
                            value=["Engineering Lead", "Backend Engineer", "Frontend Engineer", "Test Engineer"],
                            label="Select Agent Types"
                        )
                        
                        agent_count = gr.Slider(
                            minimum=1, maximum=10, value=4, step=1,
                            label="Number of Agents"
                        )
                    
                    # Task Input
                    with gr.Group():
                        gr.Markdown("### 📝 Task Description")
                        
                        requirements = gr.Textbox(
                            label="Requirements",
                            placeholder="Describe what you want to build...",
                            lines=4,
                            value="Create a Python module for a task management system with CRUD operations, API endpoints, and a simple web interface."
                        )
                        
                        module_name = gr.Textbox(
                            label="Module Name",
                            value="task_manager",
                            placeholder="e.g., task_manager"
                        )
                        
                        class_name = gr.Textbox(
                            label="Class Name",
                            value="TaskManager",
                            placeholder="e.g., TaskManager"
                        )
                    
                    # Control Buttons
                    start_button = gr.Button("🚀 Start Orchestration", variant="primary", size="lg")
                    stop_button = gr.Button("⏹️ Stop", variant="secondary")
                    analyze_button = gr.Button("🔍 Analyze Task", variant="secondary")
                
                # Right Panel - Monitoring
                with gr.Column(scale=2):
                    gr.Markdown("## 📊 Real-time Monitoring")
                    
                    # Status Display
                    with gr.Row():
                        status_display = gr.HTML(
                            value='<div class="metric-card"><h3>Status: <span class="status-stopped">Stopped</span></h3></div>',
                            label="System Status"
                        )
                        
                        pattern_display = gr.HTML(
                            value='<div class="metric-card"><h3>Pattern: Sequential</h3></div>',
                            label="Current Pattern"
                        )
                    
                    # Performance Metrics
                    with gr.Row():
                        metrics_display = gr.HTML(
                            value='<div class="metric-card"><h4>Performance Metrics</h4><p>No data available</p></div>',
                            label="Metrics"
                        )
                        
                        agents_display = gr.HTML(
                            value='<div class="metric-card"><h4>Agent Status</h4><p>No agents active</p></div>',
                            label="Agent Status"
                        )
                    
                    # Visualizations
                    with gr.Tabs():
                        with gr.Tab("📈 Performance Chart"):
                            performance_chart = gr.Plot(label="Performance Over Time")
                        
                        with gr.Tab("🕸️ Agent Network"):
                            network_graph = gr.Plot(label="Agent Communication Network")
                        
                        with gr.Tab("📋 Task Timeline"):
                            timeline_chart = gr.Plot(label="Task Execution Timeline")
                        
                        with gr.Tab("💬 Communication Log"):
                            comm_log = gr.Dataframe(
                                headers=["Timestamp", "From", "To", "Message", "Status"],
                                datatype=["str", "str", "str", "str", "str"],
                                label="Agent Communications"
                            )
            
            # Event Handlers
            start_button.click(
                fn=self.start_orchestration,
                inputs=[workflow_pattern, agent_types, agent_count, requirements, module_name, class_name],
                outputs=[status_display, pattern_display, metrics_display, agents_display]
            )
            
            stop_button.click(
                fn=self.stop_orchestration,
                outputs=[status_display, metrics_display, agents_display]
            )
            
            analyze_button.click(
                fn=self.analyze_task,
                inputs=[requirements],
                outputs=[gr.Textbox(label="Analysis Results")]
            )
            
            # Auto-refresh for real-time updates
            self.demo.load(
                fn=self.update_dashboard,
                outputs=[status_display, pattern_display, metrics_display, agents_display, 
                        performance_chart, network_graph, timeline_chart, comm_log],
                every=2  # Update every 2 seconds
            )
    
    def start_orchestration(self, pattern: str, agent_types: List[str], agent_count: int, 
                          requirements: str, module_name: str, class_name: str):
        """Start the orchestration process"""
        try:
            # Initialize orchestrator
            asyncio.create_task(self.orchestrator.initialize())
            
            # Switch to selected workflow pattern
            workflow_pattern = WorkflowPattern(pattern)
            self.orchestrator.switch_workflow_pattern(workflow_pattern)
            
            # Create agents
            agents = self.agent_factory.create_agents(agent_types, agent_count)
            
            # Start orchestration in background
            self.is_running = True
            threading.Thread(
                target=self._run_orchestration,
                args=(requirements, module_name, class_name),
                daemon=True
            ).start()
            
            status_html = '<div class="metric-card"><h3>Status: <span class="status-running">Running</span></h3></div>'
            pattern_html = f'<div class="metric-card"><h3>Pattern: {pattern.title()}</h3></div>'
            
            return status_html, pattern_html, self._get_metrics_html(), self._get_agents_html()
            
        except Exception as e:
            error_html = f'<div class="metric-card"><h3>Status: <span class="status-stopped">Error: {str(e)}</span></h3></div>'
            return error_html, "", "", ""
    
    def stop_orchestration(self):
        """Stop the orchestration process"""
        self.is_running = False
        asyncio.create_task(self.orchestrator.cleanup())
        
        status_html = '<div class="metric-card"><h3>Status: <span class="status-stopped">Stopped</span></h3></div>'
        return status_html, self._get_metrics_html(), self._get_agents_html()
    
    def analyze_task(self, requirements: str):
        """Analyze task complexity and provide recommendations"""
        if not requirements.strip():
            return "Please provide task requirements for analysis."
        
        analysis = self.orchestrator.analyze_task_complexity(requirements)
        
        result = f"""
## 🔍 Task Analysis Results

**Complexity Score:** {analysis['complexity_score']}/10
**Recommended Agents:** {', '.join(analysis['recommended_agents'])}
**Suggested Pattern:** {analysis['suggested_pattern'].value.title()}
**Estimated Duration:** {analysis['estimated_duration']//60} minutes

### 📋 Recommendations:
"""
        
        if analysis['complexity_score'] >= 8:
            result += "- High complexity detected - consider hierarchical workflow\n"
            result += "- Multiple specialized agents recommended\n"
            result += "- Allow for extended execution time\n"
        elif analysis['complexity_score'] >= 5:
            result += "- Medium-high complexity - hybrid workflow optimal\n"
            result += "- Mix of specialized and general agents\n"
        elif analysis['complexity_score'] >= 3:
            result += "- Medium complexity - parallel workflow suitable\n"
            result += "- Multiple agents can work simultaneously\n"
        else:
            result += "- Low complexity - sequential workflow sufficient\n"
            result += "- Simple agent configuration recommended\n"
        
        return result
    
    def _run_orchestration(self, requirements: str, module_name: str, class_name: str):
        """Run orchestration in background thread"""
        # This would contain the actual orchestration logic
        # For now, we'll simulate the process
        time.sleep(1)  # Simulate processing
    
    def update_dashboard(self):
        """Update dashboard components with current data"""
        try:
            # Get current metrics
            metrics = self.orchestrator.get_performance_metrics()
            
            # Update status
            if self.is_running:
                status_html = '<div class="metric-card"><h3>Status: <span class="status-running">Running</span></h3></div>'
            else:
                status_html = '<div class="metric-card"><h3>Status: <span class="status-stopped">Stopped</span></h3></div>'
            
            # Update pattern
            pattern_html = f'<div class="metric-card"><h3>Pattern: {self.orchestrator.workflow_pattern.value.title()}</h3></div>'
            
            # Update metrics
            metrics_html = self._get_metrics_html()
            
            # Update agents
            agents_html = self._get_agents_html()
            
            # Update charts
            performance_chart = self._create_performance_chart()
            network_graph = self._create_network_graph()
            timeline_chart = self._create_timeline_chart()
            
            # Update communication log
            comm_log = self._get_communication_log()
            
            return (status_html, pattern_html, metrics_html, agents_html,
                   performance_chart, network_graph, timeline_chart, comm_log)
            
        except Exception as e:
            error_html = f'<div class="metric-card"><h3>Error: {str(e)}</h3></div>'
            return error_html, "", "", "", None, None, None, None
    
    def _get_metrics_html(self):
        """Generate HTML for performance metrics"""
        metrics = self.orchestrator.get_performance_metrics()
        
        html = f"""
        <div class="metric-card">
            <h4>📊 Performance Metrics</h4>
            <p><strong>Total Tasks:</strong> {metrics['total_tasks']}</p>
            <p><strong>Completed:</strong> {metrics['completed_tasks']}</p>
            <p><strong>Failed:</strong> {metrics['failed_tasks']}</p>
            <p><strong>Success Rate:</strong> {metrics['success_rate']:.1%}</p>
            <p><strong>Avg Duration:</strong> {metrics['average_duration']:.1f}s</p>
        </div>
        """
        return html
    
    def _get_agents_html(self):
        """Generate HTML for agent status"""
        states = self.orchestrator.agent_states
        
        if not states:
            return '<div class="metric-card"><h4>👥 Agent Status</h4><p>No agents active</p></div>'
        
        html = '<div class="metric-card"><h4>👥 Agent Status</h4>'
        for agent_id, state in states.items():
            status_emoji = "🟢" if state.status == "idle" else "🟡" if state.status == "busy" else "🔴"
            html += f'<p>{status_emoji} <strong>{agent_id}:</strong> {state.status}</p>'
        html += '</div>'
        
        return html
    
    def _create_performance_chart(self):
        """Create performance over time chart"""
        if not self.performance_data:
            # Create sample data for demonstration
            dates = pd.date_range(start=datetime.now() - timedelta(hours=1), 
                                end=datetime.now(), freq='5min')
            values = np.random.cumsum(np.random.randn(len(dates))) + 100
            
            fig = go.Figure()
            fig.add_trace(go.Scatter(
                x=dates, y=values,
                mode='lines+markers',
                name='Task Completion Rate',
                line=dict(color='#4CAF50', width=3)
            ))
            
            fig.update_layout(
                title="Performance Over Time",
                xaxis_title="Time",
                yaxis_title="Tasks Completed",
                template="plotly_white",
                height=300
            )
            
            return fig
        
        return None
    
    def _create_network_graph(self):
        """Create agent network visualization"""
        # Create a sample network graph
        G = nx.Graph()
        
        # Add nodes (agents)
        agents = ["Engineering Lead", "Backend Engineer", "Frontend Engineer", "Test Engineer"]
        for agent in agents:
            G.add_node(agent)
        
        # Add edges (communication)
        edges = [
            ("Engineering Lead", "Backend Engineer"),
            ("Engineering Lead", "Frontend Engineer"),
            ("Backend Engineer", "Test Engineer"),
            ("Frontend Engineer", "Test Engineer")
        ]
        G.add_edges_from(edges)
        
        # Create plotly visualization
        pos = nx.spring_layout(G)
        
        edge_x = []
        edge_y = []
        for edge in G.edges():
            x0, y0 = pos[edge[0]]
            x1, y1 = pos[edge[1]]
            edge_x.extend([x0, x1, None])
            edge_y.extend([y0, y1, None])
        
        node_x = []
        node_y = []
        node_text = []
        for node in G.nodes():
            x, y = pos[node]
            node_x.append(x)
            node_y.append(y)
            node_text.append(node)
        
        fig = go.Figure()
        
        # Add edges
        fig.add_trace(go.Scatter(
            x=edge_x, y=edge_y,
            line=dict(width=2, color='#888'),
            hoverinfo='none',
            mode='lines'
        ))
        
        # Add nodes
        fig.add_trace(go.Scatter(
            x=node_x, y=node_y,
            mode='markers+text',
            hoverinfo='text',
            text=node_text,
            textposition="middle center",
            marker=dict(size=50, color='#4CAF50', line=dict(width=2, color='#2E7D32'))
        ))
        
        fig.update_layout(
            title="Agent Communication Network",
            showlegend=False,
            hovermode='closest',
            margin=dict(b=20,l=5,r=5,t=40),
            annotations=[ dict(
                text="Agent collaboration network",
                showarrow=False,
                xref="paper", yref="paper",
                x=0.005, y=-0.002,
                xanchor='left', yanchor='bottom',
                font=dict(color='#666')
            )],
            xaxis=dict(showgrid=False, zeroline=False, showticklabels=False),
            yaxis=dict(showgrid=False, zeroline=False, showticklabels=False),
            height=300
        )
        
        return fig
    
    def _create_timeline_chart(self):
        """Create task execution timeline"""
        # Sample timeline data
        tasks = ["Design", "Backend", "Frontend", "Testing"]
        start_times = [0, 10, 15, 25]
        durations = [10, 15, 10, 5]
        
        fig = go.Figure()
        
        for i, task in enumerate(tasks):
            fig.add_trace(go.Bar(
                name=task,
                x=[start_times[i]],
                y=[1],
                width=durations[i],
                offset=[-0.4 + i * 0.2],
                marker_color=['#FF6B6B', '#4ECDC4', '#45B7D1', '#96CEB4'][i],
                orientation='h'
            ))
        
        fig.update_layout(
            title="Task Execution Timeline",
            xaxis_title="Time (minutes)",
            yaxis_title="Tasks",
            barmode='overlay',
            height=300,
            showlegend=True
        )
        
        return fig
    
    def _get_communication_log(self):
        """Get communication log data"""
        # Sample communication data
        data = [
            ["2024-01-15 10:30:15", "Engineering Lead", "Backend Engineer", "Design specification sent", "Success"],
            ["2024-01-15 10:32:45", "Backend Engineer", "Test Engineer", "API endpoints ready", "Success"],
            ["2024-01-15 10:35:20", "Frontend Engineer", "Engineering Lead", "UI mockup complete", "Success"],
            ["2024-01-15 10:38:10", "Test Engineer", "Backend Engineer", "Test cases generated", "Success"],
        ]
        
        return pd.DataFrame(data, columns=["Timestamp", "From", "To", "Message", "Status"])
    
    def launch(self, share: bool = False, server_name: str = "127.0.0.1", server_port: int = 7860):
        """Launch the dashboard"""
        print("🚀 Launching Adaptive Multi-Agent Orchestrator Dashboard...")
        print(f"📱 Access the dashboard at: http://{server_name}:{server_port}")
        
        self.demo.launch(
            share=share,
            server_name=server_name,
            server_port=server_port,
            show_error=True,
            quiet=False
        )

def main():
    """Main function to run the dashboard"""
    dashboard = OrchestratorDashboard()
    dashboard.launch()

if __name__ == "__main__":
    main()
