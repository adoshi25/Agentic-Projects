"""
Enhanced Database Management for Multi-Agent Trading System
"""
import sqlite3
import json
import redis
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any, Tuple
from dataclasses import dataclass, asdict
from pydantic import BaseModel, Field
import pandas as pd
from config.settings import config

# Redis connection for caching
redis_client = redis.Redis.from_url(config.REDIS_URL, decode_responses=True)

@dataclass
class MarketData:
    """Market data structure"""
    symbol: str
    price: float
    volume: int
    timestamp: datetime
    open: float
    high: float
    low: float
    close: float
    change: float
    change_percent: float

@dataclass
class SentimentData:
    """Sentiment analysis data"""
    symbol: str
    sentiment_score: float  # -1 to 1
    confidence: float  # 0 to 1
    source: str  # twitter, news, reddit, etc.
    timestamp: datetime
    text: str
    mentions: int

@dataclass
class TechnicalIndicator:
    """Technical indicator data"""
    symbol: str
    indicator_name: str
    value: float
    signal: str  # buy, sell, hold
    timestamp: datetime
    metadata: Dict[str, Any]

@dataclass
class RiskMetrics:
    """Risk assessment metrics"""
    portfolio_id: str
    var_95: float  # Value at Risk 95%
    var_99: float  # Value at Risk 99%
    sharpe_ratio: float
    max_drawdown: float
    beta: float
    correlation_matrix: Dict[str, Dict[str, float]]
    concentration_risk: float
    timestamp: datetime

class EnhancedDatabase:
    """Enhanced database management with Redis caching"""
    
    def __init__(self, db_path: str = "enhanced_trading.db"):
        self.db_path = db_path
        self.init_database()
    
    def init_database(self):
        """Initialize database tables"""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            
            # Accounts table (enhanced)
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS accounts (
                    name TEXT PRIMARY KEY,
                    account TEXT,
                    risk_profile TEXT,
                    performance_metrics TEXT,
                    last_updated DATETIME DEFAULT CURRENT_TIMESTAMP
                )
            ''')
            
            # Market data table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS market_data (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    symbol TEXT,
                    price REAL,
                    volume INTEGER,
                    timestamp DATETIME,
                    open REAL,
                    high REAL,
                    low REAL,
                    close REAL,
                    change REAL,
                    change_percent REAL,
                    UNIQUE(symbol, timestamp)
                )
            ''')
            
            # Sentiment data table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS sentiment_data (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    symbol TEXT,
                    sentiment_score REAL,
                    confidence REAL,
                    source TEXT,
                    timestamp DATETIME,
                    text TEXT,
                    mentions INTEGER
                )
            ''')
            
            # Technical indicators table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS technical_indicators (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    symbol TEXT,
                    indicator_name TEXT,
                    value REAL,
                    signal TEXT,
                    timestamp DATETIME,
                    metadata TEXT
                )
            ''')
            
            # Risk metrics table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS risk_metrics (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    portfolio_id TEXT,
                    var_95 REAL,
                    var_99 REAL,
                    sharpe_ratio REAL,
                    max_drawdown REAL,
                    beta REAL,
                    correlation_matrix TEXT,
                    concentration_risk REAL,
                    timestamp DATETIME
                )
            ''')
            
            # ML predictions table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS ml_predictions (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    symbol TEXT,
                    model_name TEXT,
                    prediction REAL,
                    confidence REAL,
                    horizon_days INTEGER,
                    timestamp DATETIME,
                    features TEXT
                )
            ''')
            
            # Alerts table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS alerts (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    agent_name TEXT,
                    alert_type TEXT,
                    message TEXT,
                    severity TEXT,
                    timestamp DATETIME,
                    acknowledged BOOLEAN DEFAULT FALSE
                )
            ''')
            
            # Performance analytics table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS performance_analytics (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    agent_name TEXT,
                    metric_name TEXT,
                    metric_value REAL,
                    timestamp DATETIME,
                    period TEXT
                )
            ''')
            
            # Backtest results table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS backtest_results (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    strategy_name TEXT,
                    start_date DATE,
                    end_date DATE,
                    initial_capital REAL,
                    final_capital REAL,
                    total_return REAL,
                    sharpe_ratio REAL,
                    max_drawdown REAL,
                    win_rate REAL,
                    results_data TEXT,
                    timestamp DATETIME
                )
            ''')
            
            conn.commit()
    
    def cache_set(self, key: str, value: Any, expire: int = 3600):
        """Set value in Redis cache"""
        try:
            redis_client.setex(key, expire, json.dumps(value, default=str))
        except Exception as e:
            print(f"Redis cache error: {e}")
    
    def cache_get(self, key: str) -> Optional[Any]:
        """Get value from Redis cache"""
        try:
            value = redis_client.get(key)
            return json.loads(value) if value else None
        except Exception as e:
            print(f"Redis cache error: {e}")
            return None
    
    def write_market_data(self, market_data: MarketData):
        """Write market data to database"""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute('''
                INSERT OR REPLACE INTO market_data 
                (symbol, price, volume, timestamp, open, high, low, close, change, change_percent)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                market_data.symbol, market_data.price, market_data.volume,
                market_data.timestamp, market_data.open, market_data.high,
                market_data.low, market_data.close, market_data.change,
                market_data.change_percent
            ))
            conn.commit()
        
        # Cache the latest price
        cache_key = f"price:{market_data.symbol}"
        self.cache_set(cache_key, market_data.price, 300)  # 5 minutes
    
    def get_latest_price(self, symbol: str) -> Optional[float]:
        """Get latest price with caching"""
        cache_key = f"price:{symbol}"
        cached_price = self.cache_get(cache_key)
        if cached_price:
            return cached_price
        
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute('''
                SELECT price FROM market_data 
                WHERE symbol = ? 
                ORDER BY timestamp DESC 
                LIMIT 1
            ''', (symbol,))
            row = cursor.fetchone()
            if row:
                price = row[0]
                self.cache_set(cache_key, price, 300)
                return price
        return None
    
    def write_sentiment_data(self, sentiment_data: SentimentData):
        """Write sentiment data to database"""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute('''
                INSERT INTO sentiment_data 
                (symbol, sentiment_score, confidence, source, timestamp, text, mentions)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            ''', (
                sentiment_data.symbol, sentiment_data.sentiment_score,
                sentiment_data.confidence, sentiment_data.source,
                sentiment_data.timestamp, sentiment_data.text,
                sentiment_data.mentions
            ))
            conn.commit()
    
    def get_aggregated_sentiment(self, symbol: str, hours: int = 24) -> Optional[Dict[str, float]]:
        """Get aggregated sentiment for a symbol over specified hours"""
        cutoff_time = datetime.now() - timedelta(hours=hours)
        
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute('''
                SELECT 
                    AVG(sentiment_score) as avg_sentiment,
                    AVG(confidence) as avg_confidence,
                    COUNT(*) as total_mentions,
                    source
                FROM sentiment_data 
                WHERE symbol = ? AND timestamp > ?
                GROUP BY source
            ''', (symbol, cutoff_time))
            
            results = cursor.fetchall()
            if not results:
                return None
            
            sentiment_data = {
                'overall_sentiment': sum(row[0] for row in results) / len(results),
                'overall_confidence': sum(row[1] for row in results) / len(results),
                'total_mentions': sum(row[2] for row in results),
                'sources': {row[3]: {'sentiment': row[0], 'confidence': row[1], 'mentions': row[2]} 
                           for row in results}
            }
            
            return sentiment_data
    
    def write_technical_indicator(self, indicator: TechnicalIndicator):
        """Write technical indicator data"""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute('''
                INSERT INTO technical_indicators 
                (symbol, indicator_name, value, signal, timestamp, metadata)
                VALUES (?, ?, ?, ?, ?, ?)
            ''', (
                indicator.symbol, indicator.indicator_name, indicator.value,
                indicator.signal, indicator.timestamp, json.dumps(indicator.metadata)
            ))
            conn.commit()
    
    def get_technical_signals(self, symbol: str, indicator_name: str = None) -> List[Dict]:
        """Get technical signals for a symbol"""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            
            if indicator_name:
                cursor.execute('''
                    SELECT * FROM technical_indicators 
                    WHERE symbol = ? AND indicator_name = ?
                    ORDER BY timestamp DESC
                    LIMIT 50
                ''', (symbol, indicator_name))
            else:
                cursor.execute('''
                    SELECT * FROM technical_indicators 
                    WHERE symbol = ?
                    ORDER BY timestamp DESC
                    LIMIT 100
                ''', (symbol,))
            
            columns = [description[0] for description in cursor.description]
            results = [dict(zip(columns, row)) for row in cursor.fetchall()]
            
            return results
    
    def write_risk_metrics(self, risk_metrics: RiskMetrics):
        """Write risk metrics to database"""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute('''
                INSERT INTO risk_metrics 
                (portfolio_id, var_95, var_99, sharpe_ratio, max_drawdown, 
                 beta, correlation_matrix, concentration_risk, timestamp)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                risk_metrics.portfolio_id, risk_metrics.var_95, risk_metrics.var_99,
                risk_metrics.sharpe_ratio, risk_metrics.max_drawdown, risk_metrics.beta,
                json.dumps(risk_metrics.correlation_matrix), risk_metrics.concentration_risk,
                risk_metrics.timestamp
            ))
            conn.commit()
    
    def get_latest_risk_metrics(self, portfolio_id: str) -> Optional[Dict]:
        """Get latest risk metrics for a portfolio"""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute('''
                SELECT * FROM risk_metrics 
                WHERE portfolio_id = ?
                ORDER BY timestamp DESC
                LIMIT 1
            ''', (portfolio_id,))
            
            row = cursor.fetchone()
            if row:
                columns = [description[0] for description in cursor.description]
                result = dict(zip(columns, row))
                result['correlation_matrix'] = json.loads(result['correlation_matrix'])
                return result
        return None
    
    def write_ml_prediction(self, symbol: str, model_name: str, prediction: float, 
                          confidence: float, horizon_days: int, features: Dict):
        """Write ML prediction to database"""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute('''
                INSERT INTO ml_predictions 
                (symbol, model_name, prediction, confidence, horizon_days, timestamp, features)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            ''', (
                symbol, model_name, prediction, confidence, horizon_days,
                datetime.now(), json.dumps(features)
            ))
            conn.commit()
    
    def get_ml_predictions(self, symbol: str, model_name: str = None) -> List[Dict]:
        """Get ML predictions for a symbol"""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            
            if model_name:
                cursor.execute('''
                    SELECT * FROM ml_predictions 
                    WHERE symbol = ? AND model_name = ?
                    ORDER BY timestamp DESC
                    LIMIT 20
                ''', (symbol, model_name))
            else:
                cursor.execute('''
                    SELECT * FROM ml_predictions 
                    WHERE symbol = ?
                    ORDER BY timestamp DESC
                    LIMIT 50
                ''', (symbol,))
            
            columns = [description[0] for description in cursor.description]
            results = [dict(zip(columns, row)) for row in cursor.fetchall()]
            
            return results
    
    def write_alert(self, agent_name: str, alert_type: str, message: str, severity: str = "medium"):
        """Write alert to database"""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute('''
                INSERT INTO alerts 
                (agent_name, alert_type, message, severity, timestamp)
                VALUES (?, ?, ?, ?, ?)
            ''', (agent_name, alert_type, message, severity, datetime.now()))
            conn.commit()
    
    def get_unacknowledged_alerts(self) -> List[Dict]:
        """Get unacknowledged alerts"""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute('''
                SELECT * FROM alerts 
                WHERE acknowledged = FALSE
                ORDER BY timestamp DESC
            ''')
            
            columns = [description[0] for description in cursor.description]
            results = [dict(zip(columns, row)) for row in cursor.fetchall()]
            
            return results
    
    def acknowledge_alert(self, alert_id: int):
        """Acknowledge an alert"""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute('''
                UPDATE alerts 
                SET acknowledged = TRUE 
                WHERE id = ?
            ''', (alert_id,))
            conn.commit()
    
    def write_performance_metric(self, agent_name: str, metric_name: str, 
                               metric_value: float, period: str = "daily"):
        """Write performance metric"""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute('''
                INSERT INTO performance_analytics 
                (agent_name, metric_name, metric_value, timestamp, period)
                VALUES (?, ?, ?, ?, ?)
            ''', (agent_name, metric_name, metric_value, datetime.now(), period))
            conn.commit()
    
    def get_performance_metrics(self, agent_name: str, metric_name: str = None, 
                              days: int = 30) -> List[Dict]:
        """Get performance metrics for an agent"""
        cutoff_time = datetime.now() - timedelta(days=days)
        
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            
            if metric_name:
                cursor.execute('''
                    SELECT * FROM performance_analytics 
                    WHERE agent_name = ? AND metric_name = ? AND timestamp > ?
                    ORDER BY timestamp DESC
                ''', (agent_name, metric_name, cutoff_time))
            else:
                cursor.execute('''
                    SELECT * FROM performance_analytics 
                    WHERE agent_name = ? AND timestamp > ?
                    ORDER BY timestamp DESC
                ''', (agent_name, cutoff_time))
            
            columns = [description[0] for description in cursor.description]
            results = [dict(zip(columns, row)) for row in cursor.fetchall()]
            
            return results

# Global database instance
db = EnhancedDatabase()
