"""
Enhanced Account Management for Multi-Agent Trading System
"""
import json
import sqlite3
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any, Tuple
from dataclasses import dataclass, asdict
from pydantic import BaseModel, Field
import pandas as pd
import numpy as np
from config.settings import config
from data.enhanced_database import db, MarketData

class Transaction(BaseModel):
    """Enhanced transaction model"""
    symbol: str
    quantity: int
    price: float
    timestamp: str
    rationale: str
    agent_name: str
    transaction_type: str  # buy, sell, dividend, fee
    fees: float = 0.0
    stop_loss: Optional[float] = None
    take_profit: Optional[float] = None
    
    def total(self) -> float:
        return self.quantity * self.price + self.fees
    
    def __repr__(self):
        return f"{abs(self.quantity)} shares of {self.symbol} at ${self.price:.2f} each (${self.total():.2f} total)"

@dataclass
class Position:
    """Position tracking with risk management"""
    symbol: str
    quantity: int
    avg_cost: float
    current_price: float
    unrealized_pnl: float
    unrealized_pnl_percent: float
    stop_loss: Optional[float] = None
    take_profit: Optional[float] = None
    position_size_percent: float = 0.0
    beta: float = 1.0
    volatility: float = 0.0
    
    def update_price(self, new_price: float):
        """Update position with new price"""
        self.current_price = new_price
        self.unrealized_pnl = (new_price - self.avg_cost) * self.quantity
        self.unrealized_pnl_percent = (new_price - self.avg_cost) / self.avg_cost * 100

@dataclass
class PerformanceMetrics:
    """Performance tracking metrics"""
    total_return: float
    annualized_return: float
    sharpe_ratio: float
    max_drawdown: float
    win_rate: float
    profit_factor: float
    var_95: float
    var_99: float
    beta: float
    alpha: float
    information_ratio: float
    calmar_ratio: float
    sortino_ratio: float
    treynor_ratio: float

class EnhancedAccount(BaseModel):
    """Enhanced account with advanced features"""
    name: str
    balance: float
    strategy: str
    risk_profile: str
    holdings: Dict[str, int] = Field(default_factory=dict)
    transactions: List[Transaction] = Field(default_factory=list)
    portfolio_value_time_series: List[Tuple[str, float]] = Field(default_factory=list)
    performance_metrics: Optional[PerformanceMetrics] = None
    risk_limits: Dict[str, float] = Field(default_factory=dict)
    alerts_enabled: bool = True
    auto_rebalance: bool = False
    created_at: str = Field(default_factory=lambda: datetime.now().isoformat())
    last_updated: str = Field(default_factory=lambda: datetime.now().isoformat())
    
    class Config:
        arbitrary_types_allowed = True
    
    def get_positions(self) -> Dict[str, Position]:
        """Get current positions with enhanced data"""
        positions = {}
        for symbol, quantity in self.holdings.items():
            if quantity > 0:
                current_price = db.get_latest_price(symbol) or 0.0
                
                # Calculate average cost from transactions
                buy_transactions = [t for t in self.transactions 
                                 if t.symbol == symbol and t.quantity > 0]
                if buy_transactions:
                    total_cost = sum(t.total() for t in buy_transactions)
                    total_shares = sum(t.quantity for t in buy_transactions)
                    avg_cost = total_cost / total_shares
                else:
                    avg_cost = current_price
                
                position = Position(
                    symbol=symbol,
                    quantity=quantity,
                    avg_cost=avg_cost,
                    current_price=current_price,
                    unrealized_pnl=(current_price - avg_cost) * quantity,
                    unrealized_pnl_percent=(current_price - avg_cost) / avg_cost * 100 if avg_cost > 0 else 0
                )
                
                # Calculate position size as percentage of portfolio
                portfolio_value = self.calculate_portfolio_value()
                position.position_size_percent = (quantity * current_price) / portfolio_value * 100
                
                positions[symbol] = position
        
        return positions
    
    def calculate_portfolio_value(self) -> float:
        """Calculate total portfolio value"""
        total_value = self.balance
        for symbol, quantity in self.holdings.items():
            current_price = db.get_latest_price(symbol) or 0.0
            total_value += quantity * current_price
        return total_value
    
    def calculate_performance_metrics(self, days: int = 252) -> PerformanceMetrics:
        """Calculate comprehensive performance metrics"""
        if len(self.portfolio_value_time_series) < 2:
            return PerformanceMetrics(
                total_return=0.0, annualized_return=0.0, sharpe_ratio=0.0,
                max_drawdown=0.0, win_rate=0.0, profit_factor=0.0,
                var_95=0.0, var_99=0.0, beta=1.0, alpha=0.0,
                information_ratio=0.0, calmar_ratio=0.0, sortino_ratio=0.0, treynor_ratio=0.0
            )
        
        # Convert to DataFrame for easier calculations
        df = pd.DataFrame(self.portfolio_value_time_series, columns=['timestamp', 'value'])
        df['timestamp'] = pd.to_datetime(df['timestamp'])
        df = df.sort_values('timestamp')
        df['returns'] = df['value'].pct_change().dropna()
        
        # Basic metrics
        total_return = (df['value'].iloc[-1] - df['value'].iloc[0]) / df['value'].iloc[0]
        annualized_return = (1 + total_return) ** (252 / len(df)) - 1
        
        # Risk metrics
        returns = df['returns'].dropna()
        sharpe_ratio = returns.mean() / returns.std() * np.sqrt(252) if returns.std() > 0 else 0
        
        # Maximum drawdown
        cumulative = (1 + returns).cumprod()
        running_max = cumulative.expanding().max()
        drawdown = (cumulative - running_max) / running_max
        max_drawdown = drawdown.min()
        
        # Win rate
        win_rate = (returns > 0).mean()
        
        # Profit factor
        gains = returns[returns > 0].sum()
        losses = abs(returns[returns < 0].sum())
        profit_factor = gains / losses if losses > 0 else float('inf')
        
        # VaR calculations
        var_95 = np.percentile(returns, 5)
        var_99 = np.percentile(returns, 1)
        
        # Beta (simplified - would need market benchmark)
        beta = 1.0  # Placeholder
        
        # Alpha (simplified)
        alpha = annualized_return - 0.02  # Assuming 2% risk-free rate
        
        # Information ratio (simplified)
        information_ratio = alpha / returns.std() if returns.std() > 0 else 0
        
        # Calmar ratio
        calmar_ratio = annualized_return / abs(max_drawdown) if max_drawdown != 0 else 0
        
        # Sortino ratio
        downside_returns = returns[returns < 0]
        downside_std = downside_returns.std() if len(downside_returns) > 0 else 0
        sortino_ratio = returns.mean() / downside_std * np.sqrt(252) if downside_std > 0 else 0
        
        # Treynor ratio (simplified)
        treynor_ratio = (annualized_return - 0.02) / beta if beta > 0 else 0
        
        return PerformanceMetrics(
            total_return=total_return,
            annualized_return=annualized_return,
            sharpe_ratio=sharpe_ratio,
            max_drawdown=max_drawdown,
            win_rate=win_rate,
            profit_factor=profit_factor,
            var_95=var_95,
            var_99=var_99,
            beta=beta,
            alpha=alpha,
            information_ratio=information_ratio,
            calmar_ratio=calmar_ratio,
            sortino_ratio=sortino_ratio,
            treynor_ratio=treynor_ratio
        )
    
    def check_risk_limits(self) -> List[str]:
        """Check if any risk limits are breached"""
        violations = []
        portfolio_value = self.calculate_portfolio_value()
        positions = self.get_positions()
        
        # Check position size limits
        for symbol, position in positions.items():
            if position.position_size_percent > config.MAX_POSITION_SIZE * 100:
                violations.append(f"Position size limit breached for {symbol}: {position.position_size_percent:.1f}% > {config.MAX_POSITION_SIZE * 100:.1f}%")
        
        # Check stop loss levels
        for symbol, position in positions.items():
            if position.stop_loss and position.current_price <= position.stop_loss:
                violations.append(f"Stop loss triggered for {symbol}: ${position.current_price:.2f} <= ${position.stop_loss:.2f}")
        
        # Check take profit levels
        for symbol, position in positions.items():
            if position.take_profit and position.current_price >= position.take_profit:
                violations.append(f"Take profit triggered for {symbol}: ${position.current_price:.2f} >= ${position.take_profit:.2f}")
        
        # Check portfolio concentration
        top_positions = sorted(positions.values(), key=lambda x: x.position_size_percent, reverse=True)[:5]
        top_concentration = sum(p.position_size_percent for p in top_positions)
        if top_concentration > 80:  # 80% in top 5 positions
            violations.append(f"Portfolio concentration too high: {top_concentration:.1f}% in top 5 positions")
        
        return violations
    
    def buy_shares(self, symbol: str, quantity: int, rationale: str, 
                   agent_name: str, stop_loss: Optional[float] = None, 
                   take_profit: Optional[float] = None) -> str:
        """Enhanced buy shares with risk management"""
        current_price = db.get_latest_price(symbol) or 0.0
        if current_price == 0:
            raise ValueError(f"Unable to get price for {symbol}")
        
        buy_price = current_price * (1 + config.SPREAD)
        fees = buy_price * quantity * 0.001  # 0.1% fee
        total_cost = buy_price * quantity + fees
        
        # Check if sufficient funds
        if total_cost > self.balance:
            raise ValueError(f"Insufficient funds. Need ${total_cost:.2f}, have ${self.balance:.2f}")
        
        # Check position size limit
        portfolio_value = self.calculate_portfolio_value()
        position_value = quantity * buy_price
        position_percent = position_value / portfolio_value
        
        if position_percent > config.MAX_POSITION_SIZE:
            raise ValueError(f"Position size limit exceeded. {position_percent:.1%} > {config.MAX_POSITION_SIZE:.1%}")
        
        # Update holdings
        self.holdings[symbol] = self.holdings.get(symbol, 0) + quantity
        
        # Record transaction
        transaction = Transaction(
            symbol=symbol,
            quantity=quantity,
            price=buy_price,
            timestamp=datetime.now().isoformat(),
            rationale=rationale,
            agent_name=agent_name,
            transaction_type="buy",
            fees=fees,
            stop_loss=stop_loss,
            take_profit=take_profit
        )
        self.transactions.append(transaction)
        
        # Update balance
        self.balance -= total_cost
        self.last_updated = datetime.now().isoformat()
        
        # Log the transaction
        db.write_alert(agent_name, "trade", f"Bought {quantity} shares of {symbol} at ${buy_price:.2f}")
        
        return f"Bought {quantity} shares of {symbol} at ${buy_price:.2f} (${total_cost:.2f} total)"
    
    def sell_shares(self, symbol: str, quantity: int, rationale: str, agent_name: str) -> str:
        """Enhanced sell shares"""
        if self.holdings.get(symbol, 0) < quantity:
            raise ValueError(f"Cannot sell {quantity} shares of {symbol}. Only have {self.holdings.get(symbol, 0)} shares")
        
        current_price = db.get_latest_price(symbol) or 0.0
        if current_price == 0:
            raise ValueError(f"Unable to get price for {symbol}")
        
        sell_price = current_price * (1 - config.SPREAD)
        fees = sell_price * quantity * 0.001  # 0.1% fee
        total_proceeds = sell_price * quantity - fees
        
        # Update holdings
        self.holdings[symbol] -= quantity
        if self.holdings[symbol] == 0:
            del self.holdings[symbol]
        
        # Record transaction
        transaction = Transaction(
            symbol=symbol,
            quantity=-quantity,
            price=sell_price,
            timestamp=datetime.now().isoformat(),
            rationale=rationale,
            agent_name=agent_name,
            transaction_type="sell",
            fees=fees
        )
        self.transactions.append(transaction)
        
        # Update balance
        self.balance += total_proceeds
        self.last_updated = datetime.now().isoformat()
        
        # Log the transaction
        db.write_alert(agent_name, "trade", f"Sold {quantity} shares of {symbol} at ${sell_price:.2f}")
        
        return f"Sold {quantity} shares of {symbol} at ${sell_price:.2f} (${total_proceeds:.2f} proceeds)"
    
    def set_stop_loss(self, symbol: str, stop_loss_price: float, agent_name: str):
        """Set stop loss for a position"""
        if symbol not in self.holdings or self.holdings[symbol] <= 0:
            raise ValueError(f"No position in {symbol}")
        
        # Update the most recent buy transaction with stop loss
        for transaction in reversed(self.transactions):
            if transaction.symbol == symbol and transaction.quantity > 0:
                transaction.stop_loss = stop_loss_price
                break
        
        db.write_alert(agent_name, "risk_management", f"Set stop loss for {symbol} at ${stop_loss_price:.2f}")
    
    def set_take_profit(self, symbol: str, take_profit_price: float, agent_name: str):
        """Set take profit for a position"""
        if symbol not in self.holdings or self.holdings[symbol] <= 0:
            raise ValueError(f"No position in {symbol}")
        
        # Update the most recent buy transaction with take profit
        for transaction in reversed(self.transactions):
            if transaction.symbol == symbol and transaction.quantity > 0:
                transaction.take_profit = take_profit_price
                break
        
        db.write_alert(agent_name, "risk_management", f"Set take profit for {symbol} at ${take_profit_price:.2f}")
    
    def get_portfolio_summary(self) -> Dict[str, Any]:
        """Get comprehensive portfolio summary"""
        portfolio_value = self.calculate_portfolio_value()
        positions = self.get_positions()
        performance_metrics = self.calculate_performance_metrics()
        
        # Calculate unrealized P&L
        total_unrealized_pnl = sum(pos.unrealized_pnl for pos in positions.values())
        total_unrealized_pnl_percent = (total_unrealized_pnl / (portfolio_value - total_unrealized_pnl)) * 100 if portfolio_value > total_unrealized_pnl else 0
        
        # Risk violations
        risk_violations = self.check_risk_limits()
        
        return {
            "account_name": self.name,
            "portfolio_value": portfolio_value,
            "cash_balance": self.balance,
            "total_positions": len(positions),
            "total_unrealized_pnl": total_unrealized_pnl,
            "total_unrealized_pnl_percent": total_unrealized_pnl_percent,
            "performance_metrics": asdict(performance_metrics),
            "positions": {symbol: asdict(pos) for symbol, pos in positions.items()},
            "risk_violations": risk_violations,
            "last_updated": self.last_updated
        }
    
    def save(self):
        """Save account to database"""
        account_data = self.model_dump()
        with sqlite3.connect(db.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute('''
                INSERT OR REPLACE INTO accounts 
                (name, account, risk_profile, performance_metrics, last_updated)
                VALUES (?, ?, ?, ?, ?)
            ''', (
                self.name.lower(),
                json.dumps(account_data),
                self.risk_profile,
                json.dumps(asdict(self.performance_metrics)) if self.performance_metrics else None,
                self.last_updated
            ))
            db.conn.commit()
    
    @classmethod
    def load(cls, name: str) -> 'EnhancedAccount':
        """Load account from database"""
        with sqlite3.connect(db.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute('SELECT account FROM accounts WHERE name = ?', (name.lower(),))
            row = cursor.fetchone()
            
            if row:
                account_data = json.loads(row[0])
                return cls(**account_data)
            else:
                # Create new account
                return cls(
                    name=name.lower(),
                    balance=config.INITIAL_BALANCE,
                    strategy="",
                    risk_profile="medium"
                )

# Global account manager
class AccountManager:
    """Manages all trading accounts"""
    
    def __init__(self):
        self.accounts: Dict[str, EnhancedAccount] = {}
    
    def get_account(self, name: str) -> EnhancedAccount:
        """Get or create account"""
        if name not in self.accounts:
            self.accounts[name] = EnhancedAccount.load(name)
        return self.accounts[name]
    
    def save_all_accounts(self):
        """Save all accounts"""
        for account in self.accounts.values():
            account.save()
    
    def get_all_accounts_summary(self) -> Dict[str, Dict]:
        """Get summary of all accounts"""
        summaries = {}
        for name, account in self.accounts.items():
            summaries[name] = account.get_portfolio_summary()
        return summaries

# Global account manager instance
account_manager = AccountManager()
