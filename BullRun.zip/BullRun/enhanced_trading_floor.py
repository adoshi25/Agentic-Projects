"""
Enhanced Trading Floor - Orchestrates All Trading Agents
"""
import asyncio
import json
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any
import signal
import sys
from config.settings import config, AGENT_CONFIGS
from data.enhanced_database import db
from data.enhanced_accounts import account_manager, EnhancedAccount
from agents.base_agent import BaseAgent
from agents.risk_manager import risk_manager
from agents.sentiment_analyzer import sentiment_analyzer
from agents.technical_analyst import technical_analyst
from agents.portfolio_optimizer import portfolio_optimizer

class EnhancedTradingFloor:
    """Enhanced Trading Floor coordinating all agents"""
    
    def __init__(self):
        self.agents: Dict[str, BaseAgent] = {}
        self.trading_agents: Dict[str, BaseAgent] = {}
        self.support_agents: Dict[str, BaseAgent] = {}
        self.is_running = False
        self.start_time = None
        
        # Initialize agents
        self._initialize_agents()
        
        # Setup signal handlers for graceful shutdown
        signal.signal(signal.SIGINT, self._signal_handler)
        signal.signal(signal.SIGTERM, self._signal_handler)
    
    def _initialize_agents(self):
        """Initialize all trading and support agents"""
        # Support agents (run continuously)
        self.support_agents = {
            "risk_manager": risk_manager,
            "sentiment_analyzer": sentiment_analyzer,
            "technical_analyst": technical_analyst,
            "portfolio_optimizer": portfolio_optimizer
        }
        
        # Trading agents (the original 4 agents)
        self.trading_agents = self._create_trading_agents()
        
        # All agents
        self.agents = {**self.support_agents, **self.trading_agents}
        
        db.write_alert(
            "trading_floor",
            "initialization",
            f"Initialized {len(self.agents)} agents: {list(self.agents.keys())}"
        )
    
    def _create_trading_agents(self) -> Dict[str, BaseAgent]:
        """Create the original trading agents with enhanced capabilities"""
        from agents.enhanced_trader import EnhancedTrader
        
        trading_agents = {}
        
        for agent_key, agent_config in AGENT_CONFIGS.items():
            if agent_key in ["warren", "george", "ray", "cathie"]:
                agent = EnhancedTrader(
                    name=agent_config["name"],
                    lastname=agent_config["lastname"],
                    strategy=agent_config["strategy"],
                    risk_tolerance=agent_config["risk_tolerance"],
                    max_position_size=agent_config["max_position_size"],
                    holding_period=agent_config["holding_period"]
                )
                trading_agents[agent_key] = agent
        
        return trading_agents
    
    async def start(self):
        """Start the enhanced trading floor"""
        self.is_running = True
        self.start_time = datetime.now()
        
        db.write_alert(
            "trading_floor",
            "startup",
            "Enhanced Trading Floor starting up...",
            "medium"
        )
        
        try:
            # Start all agents concurrently
            tasks = []
            
            # Start support agents
            for agent_name, agent in self.support_agents.items():
                task = asyncio.create_task(agent.run_with_error_handling())
                tasks.append(task)
                db.write_alert(
                    "trading_floor",
                    "agent_started",
                    f"Started support agent: {agent_name}"
                )
            
            # Start trading agents
            for agent_name, agent in self.trading_agents.items():
                task = asyncio.create_task(agent.run_with_error_handling())
                tasks.append(task)
                db.write_alert(
                    "trading_floor",
                    "agent_started",
                    f"Started trading agent: {agent_name}"
                )
            
            # Start coordination loop
            coordination_task = asyncio.create_task(self._coordination_loop())
            tasks.append(coordination_task)
            
            # Start monitoring loop
            monitoring_task = asyncio.create_task(self._monitoring_loop())
            tasks.append(monitoring_task)
            
            # Wait for all tasks
            await asyncio.gather(*tasks, return_exceptions=True)
            
        except Exception as e:
            db.write_alert(
                "trading_floor",
                "critical_error",
                f"Critical error in trading floor: {str(e)}",
                "critical"
            )
            raise
        finally:
            await self.shutdown()
    
    async def _coordination_loop(self):
        """Main coordination loop for agent communication and decision making"""
        while self.is_running:
            try:
                # Get all accounts
                all_accounts = account_manager.get_all_accounts_summary()
                
                for account_name, account_data in all_accounts.items():
                    # Coordinate multi-agent decision making
                    await self._coordinate_agent_decisions(account_name, account_data)
                
                # Wait before next coordination cycle
                await asyncio.sleep(config.RUN_EVERY_N_MINUTES * 60)
                
            except Exception as e:
                db.write_alert(
                    "trading_floor",
                    "coordination_error",
                    f"Coordination loop error: {str(e)}",
                    "high"
                )
                await asyncio.sleep(60)
    
    async def _coordinate_agent_decisions(self, account_name: str, account_data: Dict[str, Any]):
        """Coordinate decisions from multiple agents for an account"""
        try:
            # Get insights from all support agents
            agent_insights = {}
            
            # Risk assessment
            risk_assessment = await risk_manager.assess_portfolio_risk(
                account_manager.get_account(account_name)
            )
            agent_insights["risk"] = {
                "overall_risk_score": risk_assessment.overall_risk_score,
                "recommendations": risk_assessment.recommendations,
                "alerts": risk_assessment.alerts
            }
            
            # Sentiment analysis for portfolio positions
            positions = account_data.get("positions", {})
            sentiment_insights = {}
            for symbol in positions.keys():
                sentiment_result = await sentiment_analyzer.analyze_sentiment(symbol)
                sentiment_insights[symbol] = {
                    "sentiment": sentiment_result.overall_sentiment,
                    "trend": sentiment_result.trend,
                    "confidence": sentiment_result.confidence
                }
            agent_insights["sentiment"] = sentiment_insights
            
            # Technical analysis
            technical_insights = {}
            for symbol in positions.keys():
                technical_analysis = await technical_analyst.analyze_technical_indicators(symbol)
                patterns = await technical_analyst.recognize_chart_patterns(symbol)
                overall_signal = await technical_analyst._generate_overall_signal(technical_analysis, patterns)
                technical_insights[symbol] = overall_signal
            agent_insights["technical"] = technical_insights
            
            # Portfolio optimization
            optimization_result = await portfolio_optimizer.optimize_portfolio(
                account_manager.get_account(account_name)
            )
            agent_insights["optimization"] = optimization_result
            
            # Send insights to trading agents
            for agent_name, agent in self.trading_agents.items():
                if hasattr(agent, 'receive_insights'):
                    await agent.receive_insights(account_name, agent_insights)
            
            # Log coordination results
            db.write_alert(
                "trading_floor",
                "coordination_complete",
                f"Coordinated insights for {account_name}: Risk={risk_assessment.overall_risk_score:.1f}, "
                f"Sentiment={len(sentiment_insights)} symbols, Technical={len(technical_insights)} signals",
                "low"
            )
            
        except Exception as e:
            db.write_alert(
                "trading_floor",
                "coordination_error",
                f"Error coordinating decisions for {account_name}: {str(e)}",
                "high"
            )
    
    async def _monitoring_loop(self):
        """Monitor system health and performance"""
        while self.is_running:
            try:
                # Check agent health
                await self._check_agent_health()
                
                # Monitor system performance
                await self._monitor_system_performance()
                
                # Check for critical alerts
                await self._check_critical_alerts()
                
                # Wait before next monitoring cycle
                await asyncio.sleep(300)  # 5 minutes
                
            except Exception as e:
                db.write_alert(
                    "trading_floor",
                    "monitoring_error",
                    f"Monitoring loop error: {str(e)}",
                    "high"
                )
                await asyncio.sleep(60)
    
    async def _check_agent_health(self):
        """Check health of all agents"""
        for agent_name, agent in self.agents.items():
            try:
                # Check if agent is active
                if not agent.is_active:
                    db.write_alert(
                        "trading_floor",
                        "agent_inactive",
                        f"Agent {agent_name} is inactive",
                        "medium"
                    )
                
                # Check last run time
                if agent.last_run_time:
                    time_since_last_run = datetime.now() - agent.last_run_time
                    if time_since_last_run > timedelta(hours=1):
                        db.write_alert(
                            "trading_floor",
                            "agent_stale",
                            f"Agent {agent_name} hasn't run in {time_since_last_run}",
                            "medium"
                        )
                
            except Exception as e:
                db.write_alert(
                    "trading_floor",
                    "health_check_error",
                    f"Error checking health of {agent_name}: {str(e)}",
                    "medium"
                )
    
    async def _monitor_system_performance(self):
        """Monitor overall system performance"""
        try:
            # Get all accounts performance
            all_accounts = account_manager.get_all_accounts_summary()
            
            total_portfolio_value = sum(account["portfolio_value"] for account in all_accounts.values())
            total_unrealized_pnl = sum(account["total_unrealized_pnl"] for account in all_accounts.values())
            
            # Log performance metrics
            db.write_performance_metric(
                "trading_floor",
                "total_portfolio_value",
                total_portfolio_value
            )
            
            db.write_performance_metric(
                "trading_floor",
                "total_unrealized_pnl",
                total_unrealized_pnl
            )
            
            # Check for significant performance changes
            if abs(total_unrealized_pnl) > total_portfolio_value * 0.05:  # 5% change
                db.write_alert(
                    "trading_floor",
                    "performance_alert",
                    f"Significant portfolio change: ${total_unrealized_pnl:,.2f} ({total_unrealized_pnl/total_portfolio_value*100:.1f}%)",
                    "medium"
                )
            
        except Exception as e:
            db.write_alert(
                "trading_floor",
                "performance_monitoring_error",
                f"Error monitoring system performance: {str(e)}",
                "medium"
            )
    
    async def _check_critical_alerts(self):
        """Check for critical alerts that need immediate attention"""
        try:
            critical_alerts = db.get_unacknowledged_alerts()
            
            for alert in critical_alerts:
                if alert["severity"] == "critical":
                    db.write_alert(
                        "trading_floor",
                        "critical_alert_escalation",
                        f"CRITICAL ALERT: {alert['message']} from {alert['agent_name']}",
                        "critical"
                    )
                    
                    # Take emergency action if needed
                    if "emergency" in alert["message"].lower():
                        await self._handle_emergency_situation(alert)
        
        except Exception as e:
            db.write_alert(
                "trading_floor",
                "alert_check_error",
                f"Error checking critical alerts: {str(e)}",
                "high"
            )
    
    async def _handle_emergency_situation(self, alert: Dict[str, Any]):
        """Handle emergency situations"""
        try:
            # Stop all trading agents
            for agent_name, agent in self.trading_agents.items():
                agent.is_active = False
            
            # Send emergency stop message to all agents
            for agent_name, agent in self.agents.items():
                agent.send_message(
                    "all",
                    "emergency_stop",
                    {"reason": alert["message"], "timestamp": datetime.now().isoformat()},
                    "critical"
                )
            
            db.write_alert(
                "trading_floor",
                "emergency_action",
                f"Emergency stop activated due to: {alert['message']}",
                "critical"
            )
            
        except Exception as e:
            db.write_alert(
                "trading_floor",
                "emergency_error",
                f"Error handling emergency situation: {str(e)}",
                "critical"
            )
    
    def _signal_handler(self, signum, frame):
        """Handle shutdown signals"""
        db.write_alert(
            "trading_floor",
            "shutdown_signal",
            f"Received signal {signum}, initiating graceful shutdown...",
            "medium"
        )
        self.is_running = False
    
    async def shutdown(self):
        """Graceful shutdown of the trading floor"""
        db.write_alert(
            "trading_floor",
            "shutdown",
            "Initiating graceful shutdown of Enhanced Trading Floor...",
            "medium"
        )
        
        try:
            # Stop all agents
            for agent_name, agent in self.agents.items():
                agent.is_active = False
            
            # Save all accounts
            account_manager.save_all_accounts()
            
            # Log final statistics
            if self.start_time:
                uptime = datetime.now() - self.start_time
                db.write_alert(
                    "trading_floor",
                    "shutdown_complete",
                    f"Trading floor shutdown complete. Uptime: {uptime}",
                    "low"
                )
        
        except Exception as e:
            db.write_alert(
                "trading_floor",
                "shutdown_error",
                f"Error during shutdown: {str(e)}",
                "high"
            )
    
    def get_system_status(self) -> Dict[str, Any]:
        """Get current system status"""
        return {
            "is_running": self.is_running,
            "start_time": self.start_time.isoformat() if self.start_time else None,
            "uptime": str(datetime.now() - self.start_time) if self.start_time else None,
            "agents": {
                "total": len(self.agents),
                "trading": len(self.trading_agents),
                "support": len(self.support_agents),
                "active": sum(1 for agent in self.agents.values() if agent.is_active)
            },
            "accounts": len(account_manager.get_all_accounts_summary()),
            "timestamp": datetime.now().isoformat()
        }
    
    def get_agent_performance(self) -> Dict[str, Any]:
        """Get performance summary for all agents"""
        performance = {}
        
        for agent_name, agent in self.agents.items():
            try:
                performance[agent_name] = agent.get_performance_summary()
            except Exception as e:
                performance[agent_name] = {"error": str(e)}
        
        return performance

# Global trading floor instance
trading_floor = EnhancedTradingFloor()

async def main():
    """Main entry point"""
    print("🚀 Starting Enhanced Multi-Agent Trading System...")
    print(f"📊 Configuration: {len(AGENT_CONFIGS)} agents, {config.RUN_EVERY_N_MINUTES}min intervals")
    print(f"💰 Initial Balance: ${config.INITIAL_BALANCE:,.2f}")
    print(f"🎯 Max Position Size: {config.MAX_POSITION_SIZE:.1%}")
    print(f"⚠️  Max Portfolio Risk: {config.MAX_PORTFOLIO_RISK:.1%}")
    print("-" * 60)
    
    try:
        await trading_floor.start()
    except KeyboardInterrupt:
        print("\n🛑 Shutdown requested by user")
    except Exception as e:
        print(f"❌ Critical error: {e}")
        sys.exit(1)
    finally:
        print("👋 Enhanced Trading System shutdown complete")

if __name__ == "__main__":
    asyncio.run(main())
