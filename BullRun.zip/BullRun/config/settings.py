"""
Enhanced Trading System Configuration
"""
import os
from dotenv import load_dotenv
from typing import List, Dict, Any
from dataclasses import dataclass

load_dotenv()

@dataclass
class TradingConfig:
    """Configuration for the enhanced trading system"""
    
    # API Keys
    OPENAI_API_KEY: str = os.getenv("OPENAI_API_KEY", "")
    POLYGON_API_KEY: str = os.getenv("POLYGON_API_KEY", "")
    TWITTER_API_KEY: str = os.getenv("TWITTER_API_KEY", "")
    TWITTER_API_SECRET: str = os.getenv("TWITTER_API_SECRET", "")
    TWITTER_ACCESS_TOKEN: str = os.getenv("TWITTER_ACCESS_TOKEN", "")
    TWITTER_ACCESS_SECRET: str = os.getenv("TWITTER_ACCESS_SECRET", "")
    SLACK_BOT_TOKEN: str = os.getenv("SLACK_BOT_TOKEN", "")
    TWILIO_ACCOUNT_SID: str = os.getenv("TWILIO_ACCOUNT_SID", "")
    TWILIO_AUTH_TOKEN: str = os.getenv("TWILIO_AUTH_TOKEN", "")
    
    # Trading Parameters
    INITIAL_BALANCE: float = float(os.getenv("INITIAL_BALANCE", "100000.0"))
    MAX_POSITION_SIZE: float = float(os.getenv("MAX_POSITION_SIZE", "0.1"))  # 10% max per position
    STOP_LOSS_PERCENTAGE: float = float(os.getenv("STOP_LOSS_PERCENTAGE", "0.05"))  # 5% stop loss
    TAKE_PROFIT_PERCENTAGE: float = float(os.getenv("TAKE_PROFIT_PERCENTAGE", "0.15"))  # 15% take profit
    SPREAD: float = float(os.getenv("SPREAD", "0.002"))  # 0.2% spread
    
    # Risk Management
    MAX_PORTFOLIO_RISK: float = float(os.getenv("MAX_PORTFOLIO_RISK", "0.02"))  # 2% max portfolio risk
    VAR_CONFIDENCE_LEVEL: float = float(os.getenv("VAR_CONFIDENCE_LEVEL", "0.95"))  # 95% VaR
    MAX_CORRELATION: float = float(os.getenv("MAX_CORRELATION", "0.7"))  # Max correlation between positions
    
    # Agent Configuration
    MAX_TURNS: int = int(os.getenv("MAX_TURNS", "50"))
    RUN_EVERY_N_MINUTES: int = int(os.getenv("RUN_EVERY_N_MINUTES", "15"))
    RUN_EVEN_WHEN_MARKET_IS_CLOSED: bool = os.getenv("RUN_EVEN_WHEN_MARKET_IS_CLOSED", "false").lower() == "true"
    
    # Model Configuration
    USE_MANY_MODELS: bool = os.getenv("USE_MANY_MODELS", "true").lower() == "true"
    PRIMARY_MODEL: str = os.getenv("PRIMARY_MODEL", "gpt-4o")
    BACKUP_MODELS: List[str] = None
    
    def __post_init__(self):
        if self.BACKUP_MODELS is None:
            self.BACKUP_MODELS = [
                "gpt-4o-mini",
                "claude-3-5-sonnet-20241022",
                "gemini-1.5-pro"
            ]
        if self.NEWS_SOURCES is None:
            self.NEWS_SOURCES = [
                "reuters", "bloomberg", "cnbc", "marketwatch", 
                "yahoo_finance", "seeking_alpha", "benzinga"
            ]
        if self.TECHNICAL_INDICATORS is None:
            self.TECHNICAL_INDICATORS = [
                "SMA", "EMA", "RSI", "MACD", "Bollinger_Bands", 
                "Stochastic", "Williams_R", "CCI", "ATR", "ADX"
            ]
    
    # Database Configuration
    DATABASE_URL: str = os.getenv("DATABASE_URL", "sqlite:///enhanced_trading.db")
    REDIS_URL: str = os.getenv("REDIS_URL", "redis://localhost:6379")
    
    # Alert Configuration
    ENABLE_SLACK_ALERTS: bool = os.getenv("ENABLE_SLACK_ALERTS", "true").lower() == "true"
    ENABLE_EMAIL_ALERTS: bool = os.getenv("ENABLE_EMAIL_ALERTS", "false").lower() == "true"
    ENABLE_SMS_ALERTS: bool = os.getenv("ENABLE_SMS_ALERTS", "false").lower() == "true"
    
    # Dashboard Configuration
    DASHBOARD_PORT: int = int(os.getenv("DASHBOARD_PORT", "8501"))
    DASHBOARD_HOST: str = os.getenv("DASHBOARD_HOST", "localhost")
    
    # Backtesting Configuration
    BACKTEST_START_DATE: str = os.getenv("BACKTEST_START_DATE", "2023-01-01")
    BACKTEST_END_DATE: str = os.getenv("BACKTEST_END_DATE", "2024-01-01")
    BACKTEST_INITIAL_CAPITAL: float = float(os.getenv("BACKTEST_INITIAL_CAPITAL", "100000.0"))
    
    # ML Configuration
    ENABLE_ML_PREDICTIONS: bool = os.getenv("ENABLE_ML_PREDICTIONS", "true").lower() == "true"
    ML_RETRAIN_FREQUENCY: int = int(os.getenv("ML_RETRAIN_FREQUENCY", "7"))  # days
    ML_LOOKBACK_DAYS: int = int(os.getenv("ML_LOOKBACK_DAYS", "252"))  # 1 year
    
    # Sentiment Analysis
    SENTIMENT_UPDATE_FREQUENCY: int = int(os.getenv("SENTIMENT_UPDATE_FREQUENCY", "30"))  # minutes
    NEWS_SOURCES: List[str] = None
    
    # Technical Analysis
    TECHNICAL_INDICATORS: List[str] = None
    
    # Portfolio Optimization
    OPTIMIZATION_METHOD: str = os.getenv("OPTIMIZATION_METHOD", "mean_variance")  # mean_variance, black_litterman, risk_parity
    REBALANCE_FREQUENCY: str = os.getenv("REBALANCE_FREQUENCY", "weekly")  # daily, weekly, monthly
    MIN_WEIGHT: float = float(os.getenv("MIN_WEIGHT", "0.01"))  # 1% minimum weight
    MAX_WEIGHT: float = float(os.getenv("MAX_WEIGHT", "0.3"))  # 30% maximum weight

# Global configuration instance
config = TradingConfig()

# Agent configurations
AGENT_CONFIGS = {
    "warren": {
        "name": "Warren",
        "lastname": "Patience", 
        "strategy": "Value investing with long-term focus. Look for undervalued companies with strong fundamentals, low P/E ratios, and consistent dividend payments. Hold positions for years, not days.",
        "risk_tolerance": "low",
        "max_position_size": 0.15,
        "holding_period": "long_term"
    },
    "george": {
        "name": "George",
        "lastname": "Bold",
        "strategy": "Growth investing with high-risk, high-reward approach. Focus on emerging technologies, biotech, and disruptive companies. Use momentum and technical analysis for entry/exit timing.",
        "risk_tolerance": "high", 
        "max_position_size": 0.25,
        "holding_period": "short_term"
    },
    "ray": {
        "name": "Ray",
        "lastname": "Systematic",
        "strategy": "Quantitative systematic trading using algorithms and data-driven decisions. Focus on mean reversion, momentum, and statistical arbitrage strategies.",
        "risk_tolerance": "medium",
        "max_position_size": 0.2,
        "holding_period": "medium_term"
    },
    "cathie": {
        "name": "Cathie", 
        "lastname": "Crypto",
        "strategy": "Innovation and disruption investing. Focus on AI, blockchain, genomics, and other breakthrough technologies. Include crypto ETFs and tech ETFs in portfolio.",
        "risk_tolerance": "high",
        "max_position_size": 0.3,
        "holding_period": "medium_term"
    },
    "risk_manager": {
        "name": "Risk Manager",
        "lastname": "Guardian",
        "strategy": "Portfolio risk assessment and position sizing. Monitor VaR, correlation, and concentration risk. Implement stop-losses and position limits.",
        "risk_tolerance": "conservative",
        "max_position_size": 0.1,
        "holding_period": "any"
    },
    "sentiment_analyzer": {
        "name": "Sentiment Analyzer", 
        "lastname": "Mood",
        "strategy": "Social media and news sentiment analysis. Track market sentiment, fear/greed index, and social media buzz around stocks.",
        "risk_tolerance": "medium",
        "max_position_size": 0.15,
        "holding_period": "short_term"
    },
    "technical_analyst": {
        "name": "Technical Analyst",
        "lastname": "Charts", 
        "strategy": "Technical analysis using chart patterns, indicators, and price action. Focus on support/resistance, trend analysis, and momentum indicators.",
        "risk_tolerance": "medium",
        "max_position_size": 0.2,
        "holding_period": "short_term"
    },
    "portfolio_optimizer": {
        "name": "Portfolio Optimizer",
        "lastname": "Efficient",
        "strategy": "Modern portfolio theory and optimization. Use mean-variance optimization, Black-Litterman model, and risk parity for optimal asset allocation.",
        "risk_tolerance": "medium",
        "max_position_size": 0.2,
        "holding_period": "medium_term"
    }
}
