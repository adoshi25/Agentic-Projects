#!/usr/bin/env python3
"""
Enhanced Trading System Startup Script
"""
import asyncio
import sys
import os
import signal
from datetime import datetime
from pathlib import Path

# Add the current directory to Python path
sys.path.append(str(Path(__file__).parent))

def print_banner():
    """Print startup banner"""
    banner = """
    ╔══════════════════════════════════════════════════════════════╗
    ║                                                              ║
    ║        🚀 ENHANCED MULTI-AGENT TRADING SYSTEM 🚀            ║
    ║                                                              ║
    ║  • 4 Original Trading Agents (Warren, George, Ray, Cathie)  ║
    ║  • 4 Advanced Support Agents (Risk, Sentiment, Technical,   ║
    ║    Portfolio Optimizer)                                      ║
    ║  • Real-time Dashboard & Monitoring                          ║
    ║  • Advanced Risk Management & Analytics                      ║
    ║                                                              ║
    ╚══════════════════════════════════════════════════════════════╝
    """
    print(banner)

def check_requirements():
    """Check if all requirements are met"""
    print("🔍 Checking requirements...")
    
    # Check Python version
    if sys.version_info < (3, 8):
        print("❌ Python 3.8+ is required")
        return False
    
    # Check if required files exist
    required_files = [
        "config/settings.py",
        "data/enhanced_database.py",
        "data/enhanced_accounts.py",
        "agents/base_agent.py",
        "enhanced_trading_floor.py"
    ]
    
    for file_path in required_files:
        if not os.path.exists(file_path):
            print(f"❌ Required file not found: {file_path}")
            return False
    
    # Check if .env file exists
    if not os.path.exists(".env"):
        print("⚠️  .env file not found. Creating template...")
        create_env_template()
    
    print("✅ All requirements met")
    return True

def create_env_template():
    """Create .env template file"""
    env_template = """# Enhanced Trading System Configuration

# API Keys
OPENAI_API_KEY=your_openai_api_key_here
POLYGON_API_KEY=your_polygon_api_key_here
TWITTER_API_KEY=your_twitter_api_key_here
TWITTER_API_SECRET=your_twitter_api_secret_here
TWITTER_ACCESS_TOKEN=your_twitter_access_token_here
TWITTER_ACCESS_SECRET=your_twitter_access_secret_here

# Optional API Keys
SLACK_BOT_TOKEN=your_slack_bot_token_here
TWILIO_ACCOUNT_SID=your_twilio_account_sid_here
TWILIO_AUTH_TOKEN=your_twilio_auth_token_here

# Trading Parameters
INITIAL_BALANCE=100000.0
MAX_POSITION_SIZE=0.1
STOP_LOSS_PERCENTAGE=0.05
TAKE_PROFIT_PERCENTAGE=0.15
SPREAD=0.002

# Risk Management
MAX_PORTFOLIO_RISK=0.02
VAR_CONFIDENCE_LEVEL=0.95
MAX_CORRELATION=0.7

# System Configuration
RUN_EVERY_N_MINUTES=15
RUN_EVEN_WHEN_MARKET_IS_CLOSED=false
USE_MANY_MODELS=true
PRIMARY_MODEL=gpt-4o

# Database
DATABASE_URL=sqlite:///enhanced_trading.db
REDIS_URL=redis://localhost:6379

# Dashboard
DASHBOARD_PORT=8501
DASHBOARD_HOST=localhost

# Alerts
ENABLE_SLACK_ALERTS=false
ENABLE_EMAIL_ALERTS=false
ENABLE_SMS_ALERTS=false

# ML Configuration
ENABLE_ML_PREDICTIONS=true
ML_RETRAIN_FREQUENCY=7
ML_LOOKBACK_DAYS=252

# Sentiment Analysis
SENTIMENT_UPDATE_FREQUENCY=30

# Portfolio Optimization
OPTIMIZATION_METHOD=mean_variance
REBALANCE_FREQUENCY=weekly
MIN_WEIGHT=0.01
MAX_WEIGHT=0.3
"""
    
    with open(".env", "w") as f:
        f.write(env_template)
    
    print("📝 Created .env template. Please edit it with your API keys.")

def initialize_system():
    """Initialize the trading system"""
    print("🔧 Initializing system...")
    
    try:
        # Import and initialize database
        from data.enhanced_database import db
        print("✅ Database initialized")
        
        # Import and initialize account manager
        from data.enhanced_accounts import account_manager
        print("✅ Account manager initialized")
        
        # Create initial accounts for trading agents
        agent_names = ["warren", "george", "ray", "cathie"]
        for name in agent_names:
            account = account_manager.get_account(name)
            print(f"✅ Account created for {name}")
        
        return True
        
    except Exception as e:
        print(f"❌ System initialization failed: {e}")
        return False

async def start_trading_system():
    """Start the trading system"""
    print("🚀 Starting Enhanced Trading System...")
    
    try:
        from enhanced_trading_floor import trading_floor
        
        # Start the system
        await trading_floor.start()
        
    except KeyboardInterrupt:
        print("\n🛑 Shutdown requested by user")
    except Exception as e:
        print(f"❌ Critical error: {e}")
        raise

def signal_handler(signum, frame):
    """Handle shutdown signals"""
    print(f"\n🛑 Received signal {signum}, shutting down...")
    sys.exit(0)

def main():
    """Main startup function"""
    # Setup signal handlers
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)
    
    # Print banner
    print_banner()
    
    # Check requirements
    if not check_requirements():
        print("❌ Requirements check failed. Please fix the issues above.")
        sys.exit(1)
    
    # Initialize system
    if not initialize_system():
        print("❌ System initialization failed.")
        sys.exit(1)
    
    print("\n" + "="*60)
    print("🎯 SYSTEM READY TO START")
    print("="*60)
    print("📊 Dashboard will be available at: http://localhost:8501")
    print("🔄 Trading agents will run every 15 minutes")
    print("⚠️  Press Ctrl+C to stop the system")
    print("="*60 + "\n")
    
    # Start the system
    try:
        asyncio.run(start_trading_system())
    except KeyboardInterrupt:
        print("\n👋 System shutdown complete")
    except Exception as e:
        print(f"\n❌ System crashed: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()
