"""
Enhanced Trader Agent - Original Trading Agents with Enhanced Capabilities
"""
import asyncio
import json
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any
from dataclasses import dataclass
from config.settings import config
from data.enhanced_database import db
from data.enhanced_accounts import account_manager, EnhancedAccount
from agents.base_agent import BaseAgent

@dataclass
class TradingDecision:
    """Trading decision with reasoning"""
    symbol: str
    action: str  # buy, sell, hold
    quantity: int
    confidence: float
    reasoning: str
    risk_score: float
    expected_return: float
    stop_loss: Optional[float] = None
    take_profit: Optional[float] = None

class EnhancedTrader(BaseAgent):
    """Enhanced version of the original trading agents"""
    
    def __init__(self, name: str, lastname: str, strategy: str, 
                 risk_tolerance: str, max_position_size: float, holding_period: str):
        super().__init__(name, lastname, strategy, config.PRIMARY_MODEL)
        
        self.risk_tolerance = risk_tolerance
        self.max_position_size = max_position_size
        self.holding_period = holding_period
        self.account_name = name.lower()
        
        # Trading parameters based on risk tolerance
        self.trading_params = self._get_trading_params()
        
        # Decision history for learning
        self.decision_history: List[TradingDecision] = []
        
        # Multi-agent insights storage
        self.agent_insights: Dict[str, Any] = {}
    
    def _get_trading_params(self) -> Dict[str, Any]:
        """Get trading parameters based on risk tolerance"""
        if self.risk_tolerance == "low":
            return {
                "max_position_size": 0.05,  # 5% max per position
                "stop_loss": 0.03,  # 3% stop loss
                "take_profit": 0.08,  # 8% take profit
                "confidence_threshold": 0.8,  # High confidence required
                "max_positions": 10
            }
        elif self.risk_tolerance == "high":
            return {
                "max_position_size": 0.15,  # 15% max per position
                "stop_loss": 0.08,  # 8% stop loss
                "take_profit": 0.20,  # 20% take profit
                "confidence_threshold": 0.6,  # Lower confidence threshold
                "max_positions": 20
            }
        else:  # medium
            return {
                "max_position_size": 0.10,  # 10% max per position
                "stop_loss": 0.05,  # 5% stop loss
                "take_profit": 0.12,  # 12% take profit
                "confidence_threshold": 0.7,  # Medium confidence threshold
                "max_positions": 15
            }
    
    async def receive_insights(self, account_name: str, insights: Dict[str, Any]):
        """Receive insights from support agents"""
        if account_name == self.account_name:
            self.agent_insights = insights
            
            # Process insights and make trading decisions
            await self._process_insights_and_trade()
    
    async def _process_insights_and_trade(self):
        """Process multi-agent insights and make trading decisions"""
        try:
            account = account_manager.get_account(self.account_name)
            current_positions = account.get_positions()
            
            # Analyze each position
            for symbol, position in current_positions.items():
                decision = await self._analyze_position(symbol, position)
                if decision and decision.action != "hold":
                    await self._execute_decision(decision, account)
            
            # Look for new opportunities
            new_opportunities = await self._find_new_opportunities()
            for opportunity in new_opportunities:
                if opportunity.action == "buy":
                    await self._execute_decision(opportunity, account)
            
            # Log trading activity
            self.log_performance("trades_analyzed", len(current_positions) + len(new_opportunities))
            
        except Exception as e:
            db.write_alert(
                self.name,
                "trading_error",
                f"Error processing insights and trading: {str(e)}",
                "high"
            )
    
    async def _analyze_position(self, symbol: str, position: Any) -> Optional[TradingDecision]:
        """Analyze existing position using multi-agent insights"""
        try:
            # Get insights for this symbol
            risk_insights = self.agent_insights.get("risk", {})
            sentiment_insights = self.agent_insights.get("sentiment", {}).get(symbol, {})
            technical_insights = self.agent_insights.get("technical", {}).get(symbol, {})
            optimization_insights = self.agent_insights.get("optimization", {})
            
            # Calculate decision score
            decision_score = 0.0
            reasoning_parts = []
            
            # Risk assessment
            overall_risk_score = risk_insights.get("overall_risk_score", 50)
            if overall_risk_score > 80:
                decision_score -= 0.3
                reasoning_parts.append("High portfolio risk")
            elif overall_risk_score < 30:
                decision_score += 0.1
                reasoning_parts.append("Low portfolio risk")
            
            # Sentiment analysis
            sentiment = sentiment_insights.get("sentiment", 0)
            sentiment_confidence = sentiment_insights.get("confidence", 0)
            if sentiment_confidence > 0.7:
                if sentiment > 0.3:
                    decision_score += 0.2
                    reasoning_parts.append("Positive sentiment")
                elif sentiment < -0.3:
                    decision_score -= 0.2
                    reasoning_parts.append("Negative sentiment")
            
            # Technical analysis
            technical_signal = technical_insights.get("signal", "hold")
            technical_confidence = technical_insights.get("confidence", 0)
            if technical_confidence > 0.7:
                if technical_signal == "buy":
                    decision_score += 0.2
                    reasoning_parts.append("Bullish technical signal")
                elif technical_signal == "sell":
                    decision_score -= 0.2
                    reasoning_parts.append("Bearish technical signal")
            
            # Portfolio optimization
            recommendations = optimization_insights.get("recommendations", [])
            for rec in recommendations:
                if rec["symbol"] == symbol:
                    if rec["recommended_action"] == "buy":
                        decision_score += 0.3
                        reasoning_parts.append("Optimization recommends buying")
                    elif rec["recommended_action"] == "sell":
                        decision_score -= 0.3
                        reasoning_parts.append("Optimization recommends selling")
                    break
            
            # Position-specific analysis
            unrealized_pnl_percent = position.unrealized_pnl_percent
            
            # Check stop loss
            if unrealized_pnl_percent < -self.trading_params["stop_loss"] * 100:
                decision_score -= 0.5
                reasoning_parts.append("Stop loss triggered")
            
            # Check take profit
            if unrealized_pnl_percent > self.trading_params["take_profit"] * 100:
                decision_score += 0.3
                reasoning_parts.append("Take profit target reached")
            
            # Make decision
            if decision_score < -0.5:
                action = "sell"
                quantity = position.quantity
                confidence = min(abs(decision_score), 1.0)
            elif decision_score > 0.5:
                action = "buy"
                quantity = await self._calculate_position_size(symbol, "buy")
                confidence = min(decision_score, 1.0)
            else:
                action = "hold"
                quantity = 0
                confidence = 0.5
            
            if action != "hold":
                return TradingDecision(
                    symbol=symbol,
                    action=action,
                    quantity=quantity,
                    confidence=confidence,
                    reasoning="; ".join(reasoning_parts),
                    risk_score=overall_risk_score,
                    expected_return=unrealized_pnl_percent / 100,
                    stop_loss=position.current_price * (1 - self.trading_params["stop_loss"]) if action == "buy" else None,
                    take_profit=position.current_price * (1 + self.trading_params["take_profit"]) if action == "buy" else None
                )
            
            return None
            
        except Exception as e:
            db.write_alert(
                self.name,
                "analysis_error",
                f"Error analyzing position {symbol}: {str(e)}",
                "medium"
            )
            return None
    
    async def _find_new_opportunities(self) -> List[TradingDecision]:
        """Find new trading opportunities"""
        opportunities = []
        
        try:
            # Get optimization recommendations for new positions
            optimization_insights = self.agent_insights.get("optimization", {})
            recommendations = optimization_insights.get("recommendations", [])
            
            account = account_manager.get_account(self.account_name)
            current_positions = account.get_positions()
            current_symbols = set(current_positions.keys())
            
            for rec in recommendations:
                symbol = rec["symbol"]
                if symbol not in current_symbols and rec["recommended_action"] == "buy":
                    # Check if we have insights for this symbol
                    sentiment_insights = self.agent_insights.get("sentiment", {}).get(symbol, {})
                    technical_insights = self.agent_insights.get("technical", {}).get(symbol, {})
                    
                    # Calculate opportunity score
                    opportunity_score = 0.0
                    reasoning_parts = []
                    
                    # Optimization recommendation
                    opportunity_score += 0.4
                    reasoning_parts.append("Portfolio optimization recommends")
                    
                    # Sentiment analysis
                    sentiment = sentiment_insights.get("sentiment", 0)
                    sentiment_confidence = sentiment_insights.get("confidence", 0)
                    if sentiment_confidence > 0.6:
                        if sentiment > 0.2:
                            opportunity_score += 0.3
                            reasoning_parts.append("Positive sentiment")
                        elif sentiment < -0.2:
                            opportunity_score -= 0.2
                            reasoning_parts.append("Negative sentiment")
                    
                    # Technical analysis
                    technical_signal = technical_insights.get("signal", "hold")
                    technical_confidence = technical_insights.get("confidence", 0)
                    if technical_confidence > 0.6:
                        if technical_signal == "buy":
                            opportunity_score += 0.3
                            reasoning_parts.append("Bullish technical signal")
                        elif technical_signal == "sell":
                            opportunity_score -= 0.2
                            reasoning_parts.append("Bearish technical signal")
                    
                    # Check if opportunity meets our criteria
                    if opportunity_score > 0.6:
                        quantity = await self._calculate_position_size(symbol, "buy")
                        if quantity > 0:
                            opportunities.append(TradingDecision(
                                symbol=symbol,
                                action="buy",
                                quantity=quantity,
                                confidence=min(opportunity_score, 1.0),
                                reasoning="; ".join(reasoning_parts),
                                risk_score=50,  # Default risk score
                                expected_return=0.1,  # Default expected return
                                stop_loss=None,  # Will be set when executing
                                take_profit=None  # Will be set when executing
                            ))
            
        except Exception as e:
            db.write_alert(
                self.name,
                "opportunity_error",
                f"Error finding new opportunities: {str(e)}",
                "medium"
            )
        
        return opportunities
    
    async def _calculate_position_size(self, symbol: str, action: str) -> int:
        """Calculate appropriate position size"""
        try:
            account = account_manager.get_account(self.account_name)
            portfolio_value = account.calculate_portfolio_value()
            current_price = db.get_latest_price(symbol) or 0.0
            
            if current_price == 0:
                return 0
            
            # Calculate maximum position value
            max_position_value = portfolio_value * self.trading_params["max_position_size"]
            
            # Calculate quantity
            max_quantity = int(max_position_value / current_price)
            
            # Apply confidence scaling
            confidence = self.agent_insights.get("confidence", 0.5)
            scaled_quantity = int(max_quantity * confidence)
            
            # Ensure minimum quantity
            min_quantity = 1 if action == "buy" else 0
            
            return max(min_quantity, scaled_quantity)
            
        except Exception as e:
            db.write_alert(
                self.name,
                "position_size_error",
                f"Error calculating position size for {symbol}: {str(e)}",
                "medium"
            )
            return 0
    
    async def _execute_decision(self, decision: TradingDecision, account: EnhancedAccount):
        """Execute a trading decision"""
        try:
            # Check confidence threshold
            if decision.confidence < self.trading_params["confidence_threshold"]:
                return
            
            # Execute the trade
            if decision.action == "buy":
                result = await self.execute_trade(
                    account_name=self.account_name,
                    symbol=decision.symbol,
                    quantity=decision.quantity,
                    action="buy",
                    rationale=decision.reasoning,
                    stop_loss=decision.stop_loss,
                    take_profit=decision.take_profit
                )
            elif decision.action == "sell":
                result = await self.execute_trade(
                    account_name=self.account_name,
                    symbol=decision.symbol,
                    quantity=decision.quantity,
                    action="sell",
                    rationale=decision.reasoning
                )
            
            # Store decision in history
            self.decision_history.append(decision)
            
            # Log the decision
            db.write_alert(
                self.name,
                "trade_executed",
                f"{decision.action.upper()} {decision.quantity} {decision.symbol} - {decision.reasoning} (confidence: {decision.confidence:.2f})",
                "medium"
            )
            
            # Log performance
            self.log_performance("trades_executed", 1)
            self.log_performance("decision_confidence", decision.confidence)
            
        except Exception as e:
            db.write_alert(
                self.name,
                "execution_error",
                f"Error executing decision for {decision.symbol}: {str(e)}",
                "high"
            )
    
    async def process_market_data(self, market_data: Dict[str, Any]) -> Dict[str, Any]:
        """Process market data (called by base class)"""
        # This method is implemented by the base class
        # We can override it for specific market data processing
        return {"status": "processed", "agent": self.name}
    
    async def make_trading_decision(self, account_name: str) -> Dict[str, Any]:
        """Make trading decision (called by base class)"""
        if account_name != self.account_name:
            return {"error": "Account name mismatch"}
        
        # Get current account status
        account = account_manager.get_account(self.account_name)
        positions = account.get_positions()
        
        # Analyze current positions
        decisions = []
        for symbol, position in positions.items():
            decision = await self._analyze_position(symbol, position)
            if decision:
                decisions.append(decision)
        
        # Find new opportunities
        opportunities = await self._find_new_opportunities()
        decisions.extend(opportunities)
        
        return {
            "agent": self.name,
            "account": self.account_name,
            "decisions": [asdict(d) for d in decisions],
            "timestamp": datetime.now().isoformat()
        }
    
    async def run(self):
        """Main execution loop for enhanced trader"""
        while self.is_active:
            try:
                # Wait for insights from support agents
                # The coordination loop will call receive_insights
                await asyncio.sleep(60)  # Check every minute
                
            except Exception as e:
                db.write_alert(
                    self.name,
                    "execution_error",
                    f"Enhanced trader execution error: {str(e)}",
                    "high"
                )
                await asyncio.sleep(60)
    
    def get_trading_summary(self) -> Dict[str, Any]:
        """Get trading summary for this agent"""
        return {
            "agent_name": self.name,
            "account": self.account_name,
            "risk_tolerance": self.risk_tolerance,
            "trading_params": self.trading_params,
            "decisions_made": len(self.decision_history),
            "recent_decisions": [asdict(d) for d in self.decision_history[-5:]],
            "performance": self.get_performance_summary(),
            "timestamp": datetime.now().isoformat()
        }
