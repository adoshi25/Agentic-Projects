"""
Technical Analyst Agent - Chart Patterns and Technical Indicators
"""
import asyncio
import json
import numpy as np
import pandas as pd
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any, Tuple
from dataclasses import dataclass
# import talib  # Commented out for demo - requires system installation
from config.settings import config, AGENT_CONFIGS
from data.enhanced_database import db, TechnicalIndicator
from agents.base_agent import BaseAgent

@dataclass
class TechnicalSignal:
    """Technical analysis signal"""
    symbol: str
    signal_type: str  # buy, sell, hold
    strength: float  # 0-1
    indicator: str
    value: float
    timestamp: datetime
    confidence: float
    reasoning: str

@dataclass
class ChartPattern:
    """Chart pattern recognition result"""
    symbol: str
    pattern_name: str
    pattern_type: str  # bullish, bearish, neutral
    confidence: float
    target_price: Optional[float]
    stop_loss: Optional[float]
    timestamp: datetime

class TechnicalAnalystAgent(BaseAgent):
    """Technical Analyst Agent for chart patterns and technical indicators"""
    
    def __init__(self):
        super().__init__(
            name=AGENT_CONFIGS["technical_analyst"]["name"],
            lastname=AGENT_CONFIGS["technical_analyst"]["lastname"],
            strategy=AGENT_CONFIGS["technical_analyst"]["strategy"],
            model_name=config.PRIMARY_MODEL
        )
        
        # Technical indicators configuration
        self.indicators = {
            "SMA": {"periods": [10, 20, 50, 200]},
            "EMA": {"periods": [12, 26, 50]},
            "RSI": {"period": 14, "overbought": 70, "oversold": 30},
            "MACD": {"fast": 12, "slow": 26, "signal": 9},
            "Bollinger_Bands": {"period": 20, "std": 2},
            "Stochastic": {"k_period": 14, "d_period": 3},
            "Williams_R": {"period": 14},
            "CCI": {"period": 20},
            "ATR": {"period": 14},
            "ADX": {"period": 14}
        }
        
        # Chart patterns to recognize
        self.patterns = [
            "head_and_shoulders", "double_top", "double_bottom",
            "triangle", "flag", "pennant", "cup_and_handle",
            "ascending_triangle", "descending_triangle"
        ]
    
    async def analyze_technical_indicators(self, symbol: str, lookback_days: int = 50) -> Dict[str, Any]:
        """Analyze all technical indicators for a symbol"""
        # Get historical price data (simplified - would use real data)
        price_data = await self._get_historical_data(symbol, lookback_days)
        
        if price_data is None or len(price_data) < 50:
            return {"error": f"Insufficient data for {symbol}"}
        
        # Convert to numpy arrays for TA-Lib
        high = np.array([float(h) for h in price_data['high']])
        low = np.array([float(l) for l in price_data['low']])
        close = np.array([float(c) for c in price_data['close']])
        volume = np.array([float(v) for v in price_data['volume']])
        
        indicators = {}
        signals = []
        
        # Moving Averages (simplified implementations)
        indicators["SMA_20"] = self._simple_moving_average(close, 20)
        indicators["SMA_50"] = self._simple_moving_average(close, 50)
        indicators["EMA_12"] = self._exponential_moving_average(close, 12)
        indicators["EMA_26"] = self._exponential_moving_average(close, 26)
        
        # RSI
        indicators["RSI"] = self._calculate_rsi(close, 14)
        
        # MACD
        macd, macd_signal, macd_hist = self._calculate_macd(close, 12, 26, 9)
        indicators["MACD"] = macd
        indicators["MACD_Signal"] = macd_signal
        indicators["MACD_Histogram"] = macd_hist
        
        # Bollinger Bands
        bb_upper, bb_middle, bb_lower = self._calculate_bollinger_bands(close, 20, 2)
        indicators["BB_Upper"] = bb_upper
        indicators["BB_Middle"] = bb_middle
        indicators["BB_Lower"] = bb_lower
        
        # Stochastic
        stoch_k, stoch_d = self._calculate_stochastic(high, low, close, 14, 3, 3)
        indicators["Stochastic_K"] = stoch_k
        indicators["Stochastic_D"] = stoch_d
        
        # Williams %R
        indicators["Williams_R"] = self._calculate_williams_r(high, low, close, 14)
        
        # CCI
        indicators["CCI"] = self._calculate_cci(high, low, close, 20)
        
        # ATR
        indicators["ATR"] = self._calculate_atr(high, low, close, 14)
        
        # ADX
        indicators["ADX"] = self._calculate_adx(high, low, close, 14)
        
        # Generate signals
        signals.extend(await self._generate_moving_average_signals(indicators, close))
        signals.extend(await self._generate_rsi_signals(indicators))
        signals.extend(await self._generate_macd_signals(indicators))
        signals.extend(await self._generate_bollinger_signals(indicators, close))
        signals.extend(await self._generate_stochastic_signals(indicators))
        signals.extend(await self._generate_williams_signals(indicators))
        signals.extend(await self._generate_cci_signals(indicators))
        signals.extend(await self._generate_adx_signals(indicators))
        
        # Store indicators in database
        await self._store_indicators(symbol, indicators)
        
        return {
            "symbol": symbol,
            "indicators": {k: float(v[-1]) if not np.isnan(v[-1]) else None for k, v in indicators.items()},
            "signals": [asdict(signal) for signal in signals],
            "timestamp": datetime.now().isoformat()
        }
    
    async def _get_historical_data(self, symbol: str, days: int) -> Optional[Dict[str, List]]:
        """Get historical price data (simplified implementation)"""
        # This would typically fetch real historical data
        # For now, we'll simulate price data
        
        np.random.seed(hash(symbol) % 2**32)  # Consistent random data for same symbol
        
        # Generate realistic price data
        base_price = 100.0
        returns = np.random.normal(0.001, 0.02, days)  # 0.1% daily return, 2% volatility
        prices = [base_price]
        
        for ret in returns[1:]:
            prices.append(prices[-1] * (1 + ret))
        
        # Generate OHLC data
        data = {
            "open": [],
            "high": [],
            "low": [],
            "close": prices,
            "volume": np.random.randint(1000000, 10000000, days).tolist()
        }
        
        for i, close in enumerate(prices):
            # Generate realistic OHLC
            volatility = abs(np.random.normal(0, 0.01))
            high = close * (1 + volatility)
            low = close * (1 - volatility)
            open_price = close * (1 + np.random.normal(0, 0.005))
            
            data["open"].append(open_price)
            data["high"].append(high)
            data["low"].append(low)
        
        return data
    
    async def _generate_moving_average_signals(self, indicators: Dict, close: np.ndarray) -> List[TechnicalSignal]:
        """Generate moving average signals"""
        signals = []
        
        sma_20 = indicators["SMA_20"]
        sma_50 = indicators["SMA_50"]
        ema_12 = indicators["EMA_12"]
        ema_26 = indicators["EMA_26"]
        
        if len(sma_20) > 1 and len(sma_50) > 1:
            # SMA crossover
            if sma_20[-1] > sma_50[-1] and sma_20[-2] <= sma_50[-2]:
                signals.append(TechnicalSignal(
                    symbol="",  # Will be set by caller
                    signal_type="buy",
                    strength=0.7,
                    indicator="SMA_Crossover",
                    value=sma_20[-1] - sma_50[-1],
                    timestamp=datetime.now(),
                    confidence=0.8,
                    reasoning="SMA 20 crossed above SMA 50 - bullish signal"
                ))
            elif sma_20[-1] < sma_50[-1] and sma_20[-2] >= sma_50[-2]:
                signals.append(TechnicalSignal(
                    symbol="",
                    signal_type="sell",
                    strength=0.7,
                    indicator="SMA_Crossover",
                    value=sma_20[-1] - sma_50[-1],
                    timestamp=datetime.now(),
                    confidence=0.8,
                    reasoning="SMA 20 crossed below SMA 50 - bearish signal"
                ))
        
        if len(ema_12) > 1 and len(ema_26) > 1:
            # EMA crossover
            if ema_12[-1] > ema_26[-1] and ema_12[-2] <= ema_26[-2]:
                signals.append(TechnicalSignal(
                    symbol="",
                    signal_type="buy",
                    strength=0.8,
                    indicator="EMA_Crossover",
                    value=ema_12[-1] - ema_26[-1],
                    timestamp=datetime.now(),
                    confidence=0.9,
                    reasoning="EMA 12 crossed above EMA 26 - strong bullish signal"
                ))
            elif ema_12[-1] < ema_26[-1] and ema_12[-2] >= ema_26[-2]:
                signals.append(TechnicalSignal(
                    symbol="",
                    signal_type="sell",
                    strength=0.8,
                    indicator="EMA_Crossover",
                    value=ema_12[-1] - ema_26[-1],
                    timestamp=datetime.now(),
                    confidence=0.9,
                    reasoning="EMA 12 crossed below EMA 26 - strong bearish signal"
                ))
        
        return signals
    
    async def _generate_rsi_signals(self, indicators: Dict) -> List[TechnicalSignal]:
        """Generate RSI signals"""
        signals = []
        rsi = indicators["RSI"]
        
        if len(rsi) > 0 and not np.isnan(rsi[-1]):
            rsi_value = rsi[-1]
            
            if rsi_value < 30:  # Oversold
                signals.append(TechnicalSignal(
                    symbol="",
                    signal_type="buy",
                    strength=0.8,
                    indicator="RSI",
                    value=rsi_value,
                    timestamp=datetime.now(),
                    confidence=0.7,
                    reasoning=f"RSI oversold at {rsi_value:.1f} - potential bounce"
                ))
            elif rsi_value > 70:  # Overbought
                signals.append(TechnicalSignal(
                    symbol="",
                    signal_type="sell",
                    strength=0.8,
                    indicator="RSI",
                    value=rsi_value,
                    timestamp=datetime.now(),
                    confidence=0.7,
                    reasoning=f"RSI overbought at {rsi_value:.1f} - potential pullback"
                ))
        
        return signals
    
    async def _generate_macd_signals(self, indicators: Dict) -> List[TechnicalSignal]:
        """Generate MACD signals"""
        signals = []
        macd = indicators["MACD"]
        macd_signal = indicators["MACD_Signal"]
        macd_hist = indicators["MACD_Histogram"]
        
        if len(macd) > 1 and len(macd_signal) > 1:
            # MACD crossover
            if macd[-1] > macd_signal[-1] and macd[-2] <= macd_signal[-2]:
                signals.append(TechnicalSignal(
                    symbol="",
                    signal_type="buy",
                    strength=0.8,
                    indicator="MACD",
                    value=macd[-1] - macd_signal[-1],
                    timestamp=datetime.now(),
                    confidence=0.8,
                    reasoning="MACD crossed above signal line - bullish momentum"
                ))
            elif macd[-1] < macd_signal[-1] and macd[-2] >= macd_signal[-2]:
                signals.append(TechnicalSignal(
                    symbol="",
                    signal_type="sell",
                    strength=0.8,
                    indicator="MACD",
                    value=macd[-1] - macd_signal[-1],
                    timestamp=datetime.now(),
                    confidence=0.8,
                    reasoning="MACD crossed below signal line - bearish momentum"
                ))
        
        return signals
    
    async def _generate_bollinger_signals(self, indicators: Dict, close: np.ndarray) -> List[TechnicalSignal]:
        """Generate Bollinger Bands signals"""
        signals = []
        bb_upper = indicators["BB_Upper"]
        bb_lower = indicators["BB_Lower"]
        
        if len(bb_upper) > 0 and len(bb_lower) > 0 and len(close) > 0:
            current_price = close[-1]
            upper_band = bb_upper[-1]
            lower_band = bb_lower[-1]
            
            if not np.isnan(upper_band) and not np.isnan(lower_band):
                if current_price <= lower_band:
                    signals.append(TechnicalSignal(
                        symbol="",
                        signal_type="buy",
                        strength=0.7,
                        indicator="Bollinger_Bands",
                        value=current_price - lower_band,
                        timestamp=datetime.now(),
                        confidence=0.6,
                        reasoning="Price at lower Bollinger Band - potential bounce"
                    ))
                elif current_price >= upper_band:
                    signals.append(TechnicalSignal(
                        symbol="",
                        signal_type="sell",
                        strength=0.7,
                        indicator="Bollinger_Bands",
                        value=current_price - upper_band,
                        timestamp=datetime.now(),
                        confidence=0.6,
                        reasoning="Price at upper Bollinger Band - potential pullback"
                    ))
        
        return signals
    
    async def _generate_stochastic_signals(self, indicators: Dict) -> List[TechnicalSignal]:
        """Generate Stochastic signals"""
        signals = []
        stoch_k = indicators["Stochastic_K"]
        stoch_d = indicators["Stochastic_D"]
        
        if len(stoch_k) > 0 and len(stoch_d) > 0:
            k_value = stoch_k[-1]
            d_value = stoch_d[-1]
            
            if not np.isnan(k_value) and not np.isnan(d_value):
                if k_value < 20 and d_value < 20:  # Oversold
                    signals.append(TechnicalSignal(
                        symbol="",
                        signal_type="buy",
                        strength=0.6,
                        indicator="Stochastic",
                        value=k_value,
                        timestamp=datetime.now(),
                        confidence=0.6,
                        reasoning="Stochastic oversold - potential reversal"
                    ))
                elif k_value > 80 and d_value > 80:  # Overbought
                    signals.append(TechnicalSignal(
                        symbol="",
                        signal_type="sell",
                        strength=0.6,
                        indicator="Stochastic",
                        value=k_value,
                        timestamp=datetime.now(),
                        confidence=0.6,
                        reasoning="Stochastic overbought - potential reversal"
                    ))
        
        return signals
    
    async def _generate_williams_signals(self, indicators: Dict) -> List[TechnicalSignal]:
        """Generate Williams %R signals"""
        signals = []
        williams_r = indicators["Williams_R"]
        
        if len(williams_r) > 0 and not np.isnan(williams_r[-1]):
            wr_value = williams_r[-1]
            
            if wr_value < -80:  # Oversold
                signals.append(TechnicalSignal(
                    symbol="",
                    signal_type="buy",
                    strength=0.6,
                    indicator="Williams_R",
                    value=wr_value,
                    timestamp=datetime.now(),
                    confidence=0.6,
                    reasoning="Williams %R oversold - potential bounce"
                ))
            elif wr_value > -20:  # Overbought
                signals.append(TechnicalSignal(
                    symbol="",
                    signal_type="sell",
                    strength=0.6,
                    indicator="Williams_R",
                    value=wr_value,
                    timestamp=datetime.now(),
                    confidence=0.6,
                    reasoning="Williams %R overbought - potential pullback"
                ))
        
        return signals
    
    async def _generate_cci_signals(self, indicators: Dict) -> List[TechnicalSignal]:
        """Generate CCI signals"""
        signals = []
        cci = indicators["CCI"]
        
        if len(cci) > 0 and not np.isnan(cci[-1]):
            cci_value = cci[-1]
            
            if cci_value < -100:  # Oversold
                signals.append(TechnicalSignal(
                    symbol="",
                    signal_type="buy",
                    strength=0.6,
                    indicator="CCI",
                    value=cci_value,
                    timestamp=datetime.now(),
                    confidence=0.6,
                    reasoning="CCI oversold - potential reversal"
                ))
            elif cci_value > 100:  # Overbought
                signals.append(TechnicalSignal(
                    symbol="",
                    signal_type="sell",
                    strength=0.6,
                    indicator="CCI",
                    value=cci_value,
                    timestamp=datetime.now(),
                    confidence=0.6,
                    reasoning="CCI overbought - potential reversal"
                ))
        
        return signals
    
    async def _generate_adx_signals(self, indicators: Dict) -> List[TechnicalSignal]:
        """Generate ADX signals"""
        signals = []
        adx = indicators["ADX"]
        
        if len(adx) > 0 and not np.isnan(adx[-1]):
            adx_value = adx[-1]
            
            if adx_value > 25:  # Strong trend
                signals.append(TechnicalSignal(
                    symbol="",
                    signal_type="hold",
                    strength=0.8,
                    indicator="ADX",
                    value=adx_value,
                    timestamp=datetime.now(),
                    confidence=0.7,
                    reasoning=f"Strong trend detected (ADX: {adx_value:.1f}) - trend following recommended"
                ))
            elif adx_value < 20:  # Weak trend
                signals.append(TechnicalSignal(
                    symbol="",
                    signal_type="hold",
                    strength=0.6,
                    indicator="ADX",
                    value=adx_value,
                    timestamp=datetime.now(),
                    confidence=0.6,
                    reasoning=f"Weak trend (ADX: {adx_value:.1f}) - range trading recommended"
                ))
        
        return signals
    
    async def _store_indicators(self, symbol: str, indicators: Dict):
        """Store technical indicators in database"""
        for indicator_name, values in indicators.items():
            if len(values) > 0 and not np.isnan(values[-1]):
                indicator = TechnicalIndicator(
                    symbol=symbol,
                    indicator_name=indicator_name,
                    value=float(values[-1]),
                    signal="neutral",  # Would be determined by signal analysis
                    timestamp=datetime.now(),
                    metadata={"lookback_period": len(values)}
                )
                db.write_technical_indicator(indicator)
    
    async def recognize_chart_patterns(self, symbol: str, lookback_days: int = 100) -> List[ChartPattern]:
        """Recognize chart patterns"""
        price_data = await self._get_historical_data(symbol, lookback_days)
        
        if price_data is None:
            return []
        
        patterns = []
        
        # Convert to numpy arrays
        high = np.array([float(h) for h in price_data['high']])
        low = np.array([float(l) for l in price_data['low']])
        close = np.array([float(c) for c in price_data['close']])
        
        # Head and Shoulders pattern
        hs_pattern = await self._detect_head_and_shoulders(high, low, close)
        if hs_pattern:
            patterns.append(hs_pattern)
        
        # Double Top/Bottom patterns
        dt_pattern = await self._detect_double_top(high, low, close)
        if dt_pattern:
            patterns.append(dt_pattern)
        
        db_pattern = await self._detect_double_bottom(high, low, close)
        if db_pattern:
            patterns.append(db_pattern)
        
        # Triangle patterns
        triangle_pattern = await self._detect_triangle(high, low, close)
        if triangle_pattern:
            patterns.append(triangle_pattern)
        
        return patterns
    
    async def _detect_head_and_shoulders(self, high: np.ndarray, low: np.ndarray, close: np.ndarray) -> Optional[ChartPattern]:
        """Detect Head and Shoulders pattern"""
        # Simplified implementation
        if len(high) < 20:
            return None
        
        # Look for three peaks with middle peak higher
        peaks = []
        for i in range(2, len(high) - 2):
            if high[i] > high[i-1] and high[i] > high[i+1] and high[i] > high[i-2] and high[i] > high[i+2]:
                peaks.append((i, high[i]))
        
        if len(peaks) >= 3:
            # Check if middle peak is highest (head)
            middle_peak = peaks[len(peaks)//2]
            if middle_peak[1] > peaks[0][1] and middle_peak[1] > peaks[-1][1]:
                return ChartPattern(
                    symbol="",
                    pattern_name="Head and Shoulders",
                    pattern_type="bearish",
                    confidence=0.7,
                    target_price=None,
                    stop_loss=None,
                    timestamp=datetime.now()
                )
        
        return None
    
    async def _detect_double_top(self, high: np.ndarray, low: np.ndarray, close: np.ndarray) -> Optional[ChartPattern]:
        """Detect Double Top pattern"""
        # Simplified implementation
        if len(high) < 20:
            return None
        
        # Look for two similar peaks
        peaks = []
        for i in range(2, len(high) - 2):
            if high[i] > high[i-1] and high[i] > high[i+1]:
                peaks.append((i, high[i]))
        
        if len(peaks) >= 2:
            # Check if two peaks are similar in height
            peak1, peak2 = peaks[-2], peaks[-1]
            if abs(peak1[1] - peak2[1]) / peak1[1] < 0.02:  # Within 2%
                return ChartPattern(
                    symbol="",
                    pattern_name="Double Top",
                    pattern_type="bearish",
                    confidence=0.6,
                    target_price=None,
                    stop_loss=None,
                    timestamp=datetime.now()
                )
        
        return None
    
    async def _detect_double_bottom(self, high: np.ndarray, low: np.ndarray, close: np.ndarray) -> Optional[ChartPattern]:
        """Detect Double Bottom pattern"""
        # Simplified implementation
        if len(low) < 20:
            return None
        
        # Look for two similar troughs
        troughs = []
        for i in range(2, len(low) - 2):
            if low[i] < low[i-1] and low[i] < low[i+1]:
                troughs.append((i, low[i]))
        
        if len(troughs) >= 2:
            # Check if two troughs are similar in depth
            trough1, trough2 = troughs[-2], troughs[-1]
            if abs(trough1[1] - trough2[1]) / trough1[1] < 0.02:  # Within 2%
                return ChartPattern(
                    symbol="",
                    pattern_name="Double Bottom",
                    pattern_type="bullish",
                    confidence=0.6,
                    target_price=None,
                    stop_loss=None,
                    timestamp=datetime.now()
                )
        
        return None
    
    async def _detect_triangle(self, high: np.ndarray, low: np.ndarray, close: np.ndarray) -> Optional[ChartPattern]:
        """Detect Triangle pattern"""
        # Simplified implementation
        if len(high) < 20:
            return None
        
        # Look for converging trend lines
        recent_highs = high[-10:]
        recent_lows = low[-10:]
        
        # Check if highs are decreasing and lows are increasing
        if len(recent_highs) >= 5 and len(recent_lows) >= 5:
            high_trend = np.polyfit(range(len(recent_highs)), recent_highs, 1)[0]
            low_trend = np.polyfit(range(len(recent_lows)), recent_lows, 1)[0]
            
            if high_trend < 0 and low_trend > 0:  # Converging
                return ChartPattern(
                    symbol="",
                    pattern_name="Triangle",
                    pattern_type="neutral",
                    confidence=0.5,
                    target_price=None,
                    stop_loss=None,
                    timestamp=datetime.now()
                )
        
        return None
    
    async def process_market_data(self, market_data: Dict[str, Any]) -> Dict[str, Any]:
        """Process market data and generate technical signals"""
        symbol = market_data.get("symbol")
        if not symbol:
            return {"error": "No symbol provided"}
        
        # Analyze technical indicators
        technical_analysis = await self.analyze_technical_indicators(symbol)
        
        # Recognize chart patterns
        patterns = await self.recognize_chart_patterns(symbol)
        
        # Generate overall signal
        overall_signal = await self._generate_overall_signal(technical_analysis, patterns)
        
        return {
            "symbol": symbol,
            "technical_analysis": technical_analysis,
            "patterns": [asdict(pattern) for pattern in patterns],
            "overall_signal": overall_signal,
            "timestamp": datetime.now().isoformat()
        }
    
    async def _generate_overall_signal(self, technical_analysis: Dict, patterns: List[ChartPattern]) -> Dict[str, Any]:
        """Generate overall trading signal based on technical analysis"""
        signals = technical_analysis.get("signals", [])
        
        if not signals:
            return {
                "signal": "hold",
                "strength": 0.0,
                "confidence": 0.0,
                "reasoning": "No clear technical signals"
            }
        
        # Count buy/sell signals
        buy_signals = [s for s in signals if s["signal_type"] == "buy"]
        sell_signals = [s for s in signals if s["signal_type"] == "sell"]
        
        # Calculate weighted signal strength
        buy_strength = sum(s["strength"] * s["confidence"] for s in buy_signals)
        sell_strength = sum(s["strength"] * s["confidence"] for s in sell_signals)
        
        # Consider chart patterns
        pattern_bias = 0
        for pattern in patterns:
            if pattern.pattern_type == "bullish":
                pattern_bias += 0.2 * pattern.confidence
            elif pattern.pattern_type == "bearish":
                pattern_bias -= 0.2 * pattern.confidence
        
        # Determine overall signal
        net_signal = buy_strength - sell_strength + pattern_bias
        
        if net_signal > 0.5:
            signal = "buy"
            strength = min(net_signal, 1.0)
        elif net_signal < -0.5:
            signal = "sell"
            strength = min(abs(net_signal), 1.0)
        else:
            signal = "hold"
            strength = 0.0
        
        confidence = (len(buy_signals) + len(sell_signals)) / 10  # Normalize confidence
        confidence = min(confidence, 1.0)
        
        return {
            "signal": signal,
            "strength": strength,
            "confidence": confidence,
            "reasoning": f"Based on {len(signals)} technical signals and {len(patterns)} chart patterns"
        }
    
    async def make_trading_decision(self, account_name: str) -> Dict[str, Any]:
        """Make trading decisions based on technical analysis"""
        account = account_manager.get_account(account_name)
        positions = account.get_positions()
        
        technical_insights = {}
        
        for symbol in positions.keys():
            technical_analysis = await self.analyze_technical_indicators(symbol)
            patterns = await self.recognize_chart_patterns(symbol)
            overall_signal = await self._generate_overall_signal(technical_analysis, patterns)
            
            technical_insights[symbol] = {
                "signal": overall_signal["signal"],
                "strength": overall_signal["strength"],
                "confidence": overall_signal["confidence"],
                "patterns": [asdict(p) for p in patterns],
                "recommendation": self._generate_technical_recommendation(overall_signal, patterns)
            }
        
        return {
            "agent": self.name,
            "account": account_name,
            "technical_insights": technical_insights,
            "timestamp": datetime.now().isoformat()
        }
    
    def _generate_technical_recommendation(self, overall_signal: Dict, patterns: List[ChartPattern]) -> str:
        """Generate trading recommendation based on technical analysis"""
        signal = overall_signal["signal"]
        strength = overall_signal["strength"]
        confidence = overall_signal["confidence"]
        
        if signal == "buy" and strength > 0.7 and confidence > 0.7:
            return "Strong bullish technical signal - consider buying"
        elif signal == "sell" and strength > 0.7 and confidence > 0.7:
            return "Strong bearish technical signal - consider selling"
        elif signal == "buy":
            return "Bullish technical bias - monitor for entry"
        elif signal == "sell":
            return "Bearish technical bias - consider risk management"
        else:
            return "Neutral technical outlook - no clear signal"
    
    async def run(self):
        """Main execution loop for technical analyst"""
        while True:
            try:
                # Get all accounts and their positions
                all_accounts = account_manager.get_all_accounts_summary()
                
                symbols_to_analyze = set()
                for account_data in all_accounts.values():
                    positions = account_data.get("positions", {})
                    symbols_to_analyze.update(positions.keys())
                
                # Analyze technical indicators for all symbols
                for symbol in symbols_to_analyze:
                    technical_analysis = await self.analyze_technical_indicators(symbol)
                    patterns = await self.recognize_chart_patterns(symbol)
                    
                    # Log performance
                    self.log_performance("technical_analysis", 1)
                    
                    # Check for strong signals
                    overall_signal = await self._generate_overall_signal(technical_analysis, patterns)
                    if overall_signal["strength"] > 0.8 and overall_signal["confidence"] > 0.7:
                        db.write_alert(
                            self.name,
                            "strong_signal",
                            f"Strong {overall_signal['signal']} signal for {symbol} (strength: {overall_signal['strength']:.2f})",
                            "medium"
                        )
                
                # Wait before next analysis
                await asyncio.sleep(config.RUN_EVERY_N_MINUTES * 60)
                
            except Exception as e:
                db.write_alert(self.name, "execution_error", f"Technical analyst error: {str(e)}", "high")
                await asyncio.sleep(60)  # Wait 1 minute before retrying
    
    def _simple_moving_average(self, prices: np.ndarray, period: int) -> np.ndarray:
        """Calculate Simple Moving Average"""
        if len(prices) < period:
            return np.full(len(prices), np.nan)
        
        sma = np.full(len(prices), np.nan)
        for i in range(period - 1, len(prices)):
            sma[i] = np.mean(prices[i - period + 1:i + 1])
        
        return sma
    
    def _exponential_moving_average(self, prices: np.ndarray, period: int) -> np.ndarray:
        """Calculate Exponential Moving Average"""
        if len(prices) < period:
            return np.full(len(prices), np.nan)
        
        ema = np.full(len(prices), np.nan)
        multiplier = 2 / (period + 1)
        
        # Initialize with SMA
        ema[period - 1] = np.mean(prices[:period])
        
        for i in range(period, len(prices)):
            ema[i] = (prices[i] * multiplier) + (ema[i - 1] * (1 - multiplier))
        
        return ema
    
    def _calculate_rsi(self, prices: np.ndarray, period: int = 14) -> np.ndarray:
        """Calculate Relative Strength Index"""
        if len(prices) < period + 1:
            return np.full(len(prices), np.nan)
        
        deltas = np.diff(prices)
        gains = np.where(deltas > 0, deltas, 0)
        losses = np.where(deltas < 0, -deltas, 0)
        
        rsi = np.full(len(prices), np.nan)
        
        for i in range(period, len(prices)):
            avg_gain = np.mean(gains[i - period:i])
            avg_loss = np.mean(losses[i - period:i])
            
            if avg_loss == 0:
                rsi[i] = 100
            else:
                rs = avg_gain / avg_loss
                rsi[i] = 100 - (100 / (1 + rs))
        
        return rsi
    
    def _calculate_macd(self, prices: np.ndarray, fast: int = 12, slow: int = 26, signal: int = 9) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
        """Calculate MACD"""
        ema_fast = self._exponential_moving_average(prices, fast)
        ema_slow = self._exponential_moving_average(prices, slow)
        
        macd = ema_fast - ema_slow
        macd_signal = self._exponential_moving_average(macd, signal)
        macd_histogram = macd - macd_signal
        
        return macd, macd_signal, macd_histogram
    
    def _calculate_bollinger_bands(self, prices: np.ndarray, period: int = 20, std_dev: float = 2) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
        """Calculate Bollinger Bands"""
        sma = self._simple_moving_average(prices, period)
        
        bb_upper = np.full(len(prices), np.nan)
        bb_lower = np.full(len(prices), np.nan)
        
        for i in range(period - 1, len(prices)):
            std = np.std(prices[i - period + 1:i + 1])
            bb_upper[i] = sma[i] + (std_dev * std)
            bb_lower[i] = sma[i] - (std_dev * std)
        
        return bb_upper, sma, bb_lower
    
    def _calculate_stochastic(self, high: np.ndarray, low: np.ndarray, close: np.ndarray, 
                            k_period: int = 14, d_period: int = 3) -> Tuple[np.ndarray, np.ndarray]:
        """Calculate Stochastic Oscillator"""
        if len(close) < k_period:
            return np.full(len(close), np.nan), np.full(len(close), np.nan)
        
        k_percent = np.full(len(close), np.nan)
        
        for i in range(k_period - 1, len(close)):
            highest_high = np.max(high[i - k_period + 1:i + 1])
            lowest_low = np.min(low[i - k_period + 1:i + 1])
            
            if highest_high != lowest_low:
                k_percent[i] = ((close[i] - lowest_low) / (highest_high - lowest_low)) * 100
            else:
                k_percent[i] = 50
        
        d_percent = self._simple_moving_average(k_percent, d_period)
        
        return k_percent, d_percent
    
    def _calculate_williams_r(self, high: np.ndarray, low: np.ndarray, close: np.ndarray, period: int = 14) -> np.ndarray:
        """Calculate Williams %R"""
        if len(close) < period:
            return np.full(len(close), np.nan)
        
        williams_r = np.full(len(close), np.nan)
        
        for i in range(period - 1, len(close)):
            highest_high = np.max(high[i - period + 1:i + 1])
            lowest_low = np.min(low[i - period + 1:i + 1])
            
            if highest_high != lowest_low:
                williams_r[i] = ((highest_high - close[i]) / (highest_high - lowest_low)) * -100
            else:
                williams_r[i] = -50
        
        return williams_r
    
    def _calculate_cci(self, high: np.ndarray, low: np.ndarray, close: np.ndarray, period: int = 20) -> np.ndarray:
        """Calculate Commodity Channel Index"""
        if len(close) < period:
            return np.full(len(close), np.nan)
        
        cci = np.full(len(close), np.nan)
        
        for i in range(period - 1, len(close)):
            typical_price = (high[i - period + 1:i + 1] + low[i - period + 1:i + 1] + close[i - period + 1:i + 1]) / 3
            sma_tp = np.mean(typical_price)
            mean_deviation = np.mean(np.abs(typical_price - sma_tp))
            
            if mean_deviation != 0:
                cci[i] = (typical_price[-1] - sma_tp) / (0.015 * mean_deviation)
            else:
                cci[i] = 0
        
        return cci
    
    def _calculate_atr(self, high: np.ndarray, low: np.ndarray, close: np.ndarray, period: int = 14) -> np.ndarray:
        """Calculate Average True Range"""
        if len(close) < period + 1:
            return np.full(len(close), np.nan)
        
        true_range = np.full(len(close), np.nan)
        
        for i in range(1, len(close)):
            tr1 = high[i] - low[i]
            tr2 = abs(high[i] - close[i - 1])
            tr3 = abs(low[i] - close[i - 1])
            true_range[i] = max(tr1, tr2, tr3)
        
        atr = self._simple_moving_average(true_range, period)
        return atr
    
    def _calculate_adx(self, high: np.ndarray, low: np.ndarray, close: np.ndarray, period: int = 14) -> np.ndarray:
        """Calculate Average Directional Index (simplified)"""
        if len(close) < period + 1:
            return np.full(len(close), np.nan)
        
        # Simplified ADX calculation
        adx = np.full(len(close), np.nan)
        
        for i in range(period, len(close)):
            # Calculate directional movement
            plus_dm = 0
            minus_dm = 0
            
            for j in range(i - period + 1, i + 1):
                if j > 0:
                    high_diff = high[j] - high[j - 1]
                    low_diff = low[j - 1] - low[j]
                    
                    if high_diff > low_diff and high_diff > 0:
                        plus_dm += high_diff
                    elif low_diff > high_diff and low_diff > 0:
                        minus_dm += low_diff
            
            # Simplified ADX calculation
            adx[i] = min(100, max(0, (plus_dm - minus_dm) / (plus_dm + minus_dm + 1e-10) * 100))
        
        return adx

# Global technical analyst instance
technical_analyst = TechnicalAnalystAgent()
