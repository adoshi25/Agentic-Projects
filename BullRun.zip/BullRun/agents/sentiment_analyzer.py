"""
Sentiment Analyzer Agent - Social Media and News Sentiment Analysis
"""
import asyncio
import json
import re
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any, Tuple
import requests
from bs4 import BeautifulSoup
import tweepy
from textblob import TextBlob
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer
from dataclasses import dataclass
from config.settings import config, AGENT_CONFIGS
from data.enhanced_database import db, SentimentData
from agents.base_agent import BaseAgent

@dataclass
class SentimentResult:
    """Sentiment analysis result"""
    symbol: str
    overall_sentiment: float  # -1 to 1
    confidence: float  # 0 to 1
    sources: Dict[str, Dict[str, Any]]
    trend: str  # bullish, bearish, neutral
    momentum: float  # -1 to 1
    volume: int  # total mentions
    timestamp: datetime

class SentimentAnalyzerAgent(BaseAgent):
    """Sentiment Analyzer Agent for social media and news analysis"""
    
    def __init__(self):
        super().__init__(
            name=AGENT_CONFIGS["sentiment_analyzer"]["name"],
            lastname=AGENT_CONFIGS["sentiment_analyzer"]["lastname"],
            strategy=AGENT_CONFIGS["sentiment_analyzer"]["strategy"],
            model_name=config.PRIMARY_MODEL
        )
        
        # Initialize sentiment analyzers
        self.vader_analyzer = SentimentIntensityAnalyzer()
        
        # Twitter API setup (if available)
        self.twitter_client = None
        if config.TWITTER_API_KEY:
            try:
                auth = tweepy.OAuthHandler(config.TWITTER_API_KEY, config.TWITTER_API_SECRET)
                auth.set_access_token(config.TWITTER_ACCESS_TOKEN, config.TWITTER_ACCESS_SECRET)
                self.twitter_client = tweepy.API(auth, wait_on_rate_limit=True)
            except Exception as e:
                db.write_alert(self.name, "setup_error", f"Twitter API setup failed: {str(e)}")
        
        # News sources configuration
        self.news_sources = {
            "reuters": "https://www.reuters.com/business/finance/",
            "bloomberg": "https://www.bloomberg.com/markets",
            "cnbc": "https://www.cnbc.com/markets/",
            "marketwatch": "https://www.marketwatch.com/",
            "yahoo_finance": "https://finance.yahoo.com/news/",
            "seeking_alpha": "https://seekingalpha.com/news"
        }
        
        # Sentiment keywords for different market conditions
        self.bullish_keywords = [
            "bullish", "buy", "strong", "growth", "positive", "outperform", 
            "upgrade", "beat", "exceed", "rally", "surge", "gain", "profit"
        ]
        
        self.bearish_keywords = [
            "bearish", "sell", "weak", "decline", "negative", "underperform",
            "downgrade", "miss", "disappoint", "crash", "plunge", "loss", "fall"
        ]
    
    async def analyze_sentiment(self, symbol: str, hours: int = 24) -> SentimentResult:
        """Comprehensive sentiment analysis for a symbol"""
        sources = {}
        
        # Analyze Twitter sentiment
        twitter_sentiment = await self._analyze_twitter_sentiment(symbol, hours)
        if twitter_sentiment:
            sources["twitter"] = twitter_sentiment
        
        # Analyze news sentiment
        news_sentiment = await self._analyze_news_sentiment(symbol, hours)
        if news_sentiment:
            sources["news"] = news_sentiment
        
        # Analyze Reddit sentiment (simplified)
        reddit_sentiment = await self._analyze_reddit_sentiment(symbol, hours)
        if reddit_sentiment:
            sources["reddit"] = reddit_sentiment
        
        # Calculate overall sentiment
        if not sources:
            return SentimentResult(
                symbol=symbol,
                overall_sentiment=0.0,
                confidence=0.0,
                sources={},
                trend="neutral",
                momentum=0.0,
                volume=0,
                timestamp=datetime.now()
            )
        
        # Weighted average sentiment
        total_weight = 0
        weighted_sentiment = 0
        total_volume = 0
        
        for source, data in sources.items():
            weight = data.get("weight", 1.0)
            sentiment = data.get("sentiment", 0.0)
            volume = data.get("volume", 0)
            
            weighted_sentiment += sentiment * weight
            total_weight += weight
            total_volume += volume
        
        overall_sentiment = weighted_sentiment / total_weight if total_weight > 0 else 0.0
        
        # Calculate confidence based on volume and consistency
        confidence = min(total_volume / 100, 1.0)  # Normalize to 0-1
        
        # Determine trend
        if overall_sentiment > 0.2:
            trend = "bullish"
        elif overall_sentiment < -0.2:
            trend = "bearish"
        else:
            trend = "neutral"
        
        # Calculate momentum (change in sentiment over time)
        momentum = await self._calculate_sentiment_momentum(symbol, hours)
        
        result = SentimentResult(
            symbol=symbol,
            overall_sentiment=overall_sentiment,
            confidence=confidence,
            sources=sources,
            trend=trend,
            momentum=momentum,
            volume=total_volume,
            timestamp=datetime.now()
        )
        
        # Store sentiment data
        await self._store_sentiment_data(result)
        
        return result
    
    async def _analyze_twitter_sentiment(self, symbol: str, hours: int) -> Optional[Dict[str, Any]]:
        """Analyze Twitter sentiment for a symbol"""
        if not self.twitter_client:
            return None
        
        try:
            # Search for tweets mentioning the symbol
            query = f"${symbol} OR {symbol} -filter:retweets"
            tweets = tweepy.Cursor(
                self.twitter_client.search_tweets,
                q=query,
                lang="en",
                result_type="recent",
                tweet_mode="extended"
            ).items(100)
            
            sentiments = []
            volumes = []
            
            for tweet in tweets:
                # Check if tweet is within time window
                tweet_time = tweet.created_at
                if datetime.now() - tweet_time > timedelta(hours=hours):
                    continue
                
                text = tweet.full_text
                
                # Analyze sentiment using multiple methods
                vader_scores = self.vader_analyzer.polarity_scores(text)
                textblob_sentiment = TextBlob(text).sentiment.polarity
                
                # Combine sentiment scores
                combined_sentiment = (vader_scores['compound'] + textblob_sentiment) / 2
                
                sentiments.append(combined_sentiment)
                volumes.append(tweet.favorite_count + tweet.retweet_count)
            
            if not sentiments:
                return None
            
            # Calculate weighted average sentiment
            total_volume = sum(volumes)
            if total_volume > 0:
                weighted_sentiment = sum(s * v for s, v in zip(sentiments, volumes)) / total_volume
            else:
                weighted_sentiment = sum(sentiments) / len(sentiments)
            
            return {
                "sentiment": weighted_sentiment,
                "confidence": min(len(sentiments) / 50, 1.0),
                "volume": len(sentiments),
                "weight": 1.5,  # Higher weight for social media
                "samples": len(sentiments)
            }
            
        except Exception as e:
            db.write_alert(self.name, "twitter_error", f"Twitter analysis error for {symbol}: {str(e)}")
            return None
    
    async def _analyze_news_sentiment(self, symbol: str, hours: int) -> Optional[Dict[str, Any]]:
        """Analyze news sentiment for a symbol"""
        sentiments = []
        total_articles = 0
        
        for source_name, source_url in self.news_sources.items():
            try:
                # This is a simplified implementation
                # In practice, you'd use proper news APIs or web scraping
                articles = await self._scrape_news_articles(source_url, symbol, hours)
                
                for article in articles:
                    sentiment = self._analyze_text_sentiment(article["text"])
                    sentiments.append(sentiment)
                    total_articles += 1
                    
                    # Store individual sentiment data
                    sentiment_data = SentimentData(
                        symbol=symbol,
                        sentiment_score=sentiment,
                        confidence=0.8,  # News articles generally have higher confidence
                        source=source_name,
                        timestamp=datetime.now(),
                        text=article["text"][:500],  # Truncate for storage
                        mentions=1
                    )
                    db.write_sentiment_data(sentiment_data)
                
            except Exception as e:
                db.write_alert(self.name, "news_error", f"News analysis error for {source_name}: {str(e)}")
                continue
        
        if not sentiments:
            return None
        
        avg_sentiment = sum(sentiments) / len(sentiments)
        
        return {
            "sentiment": avg_sentiment,
            "confidence": min(total_articles / 20, 1.0),
            "volume": total_articles,
            "weight": 2.0,  # Higher weight for news
            "sources": list(self.news_sources.keys())
        }
    
    async def _analyze_reddit_sentiment(self, symbol: str, hours: int) -> Optional[Dict[str, Any]]:
        """Analyze Reddit sentiment for a symbol (simplified)"""
        # This is a placeholder implementation
        # In practice, you'd use the Reddit API or web scraping
        
        # Simulate Reddit sentiment analysis
        sentiments = []
        for _ in range(10):  # Simulate 10 Reddit posts
            # Generate random sentiment for demonstration
            sentiment = (hash(f"{symbol}_{datetime.now()}") % 200 - 100) / 100
            sentiments.append(sentiment)
        
        if not sentiments:
            return None
        
        avg_sentiment = sum(sentiments) / len(sentiments)
        
        return {
            "sentiment": avg_sentiment,
            "confidence": 0.6,  # Lower confidence for social media
            "volume": len(sentiments),
            "weight": 1.0,
            "source": "reddit"
        }
    
    async def _scrape_news_articles(self, source_url: str, symbol: str, hours: int) -> List[Dict[str, str]]:
        """Scrape news articles (simplified implementation)"""
        # This is a placeholder implementation
        # In practice, you'd implement proper web scraping or use news APIs
        
        articles = []
        
        try:
            # Simulate news article scraping
            response = requests.get(source_url, timeout=10)
            if response.status_code == 200:
                soup = BeautifulSoup(response.content, 'html.parser')
                
                # This would need to be customized for each news source
                # For now, we'll simulate some articles
                for i in range(3):  # Simulate 3 articles
                    articles.append({
                        "title": f"Article about {symbol} - {i+1}",
                        "text": f"This is a simulated article about {symbol} with some market commentary.",
                        "url": f"{source_url}/article-{i+1}",
                        "timestamp": datetime.now() - timedelta(hours=i)
                    })
        
        except Exception as e:
            db.write_alert(self.name, "scraping_error", f"News scraping error: {str(e)}")
        
        return articles
    
    def _analyze_text_sentiment(self, text: str) -> float:
        """Analyze sentiment of text using multiple methods"""
        # Clean text
        text = re.sub(r'[^\w\s]', '', text.lower())
        
        # VADER sentiment
        vader_scores = self.vader_analyzer.polarity_scores(text)
        
        # TextBlob sentiment
        textblob_sentiment = TextBlob(text).sentiment.polarity
        
        # Keyword-based sentiment
        keyword_sentiment = self._analyze_keyword_sentiment(text)
        
        # Combine all methods
        combined_sentiment = (
            vader_scores['compound'] * 0.4 +
            textblob_sentiment * 0.3 +
            keyword_sentiment * 0.3
        )
        
        return combined_sentiment
    
    def _analyze_keyword_sentiment(self, text: str) -> float:
        """Analyze sentiment based on keywords"""
        bullish_count = sum(1 for keyword in self.bullish_keywords if keyword in text)
        bearish_count = sum(1 for keyword in self.bearish_keywords if keyword in text)
        
        total_keywords = bullish_count + bearish_count
        if total_keywords == 0:
            return 0.0
        
        return (bullish_count - bearish_count) / total_keywords
    
    async def _calculate_sentiment_momentum(self, symbol: str, hours: int) -> float:
        """Calculate sentiment momentum (change over time)"""
        # Get historical sentiment data
        cutoff_time = datetime.now() - timedelta(hours=hours*2)
        
        # This would query the database for historical sentiment
        # For now, we'll simulate momentum calculation
        return (hash(f"{symbol}_momentum_{datetime.now()}") % 200 - 100) / 100
    
    async def _store_sentiment_data(self, result: SentimentResult):
        """Store sentiment analysis results"""
        # Store aggregated sentiment data
        sentiment_data = SentimentData(
            symbol=result.symbol,
            sentiment_score=result.overall_sentiment,
            confidence=result.confidence,
            source="aggregated",
            timestamp=result.timestamp,
            text=f"Overall sentiment: {result.trend}",
            mentions=result.volume
        )
        db.write_sentiment_data(sentiment_data)
    
    async def get_sentiment_trend(self, symbol: str, days: int = 7) -> Dict[str, Any]:
        """Get sentiment trend over time"""
        # This would query historical sentiment data
        # For now, we'll simulate trend data
        
        trend_data = []
        for i in range(days):
            date = datetime.now() - timedelta(days=i)
            sentiment = (hash(f"{symbol}_{date.date()}") % 200 - 100) / 100
            trend_data.append({
                "date": date.date().isoformat(),
                "sentiment": sentiment,
                "volume": hash(f"{symbol}_vol_{date.date()}") % 100
            })
        
        return {
            "symbol": symbol,
            "trend_data": trend_data,
            "trend_direction": "improving" if trend_data[0]["sentiment"] > trend_data[-1]["sentiment"] else "declining",
            "average_sentiment": sum(d["sentiment"] for d in trend_data) / len(trend_data)
        }
    
    async def detect_sentiment_anomalies(self, symbol: str) -> List[Dict[str, Any]]:
        """Detect unusual sentiment patterns"""
        anomalies = []
        
        # Get recent sentiment data
        recent_sentiment = await self.analyze_sentiment(symbol, hours=24)
        
        # Check for extreme sentiment
        if abs(recent_sentiment.overall_sentiment) > 0.8:
            anomalies.append({
                "type": "extreme_sentiment",
                "severity": "high",
                "message": f"Extreme sentiment detected: {recent_sentiment.overall_sentiment:.2f}",
                "recommendation": "Monitor closely for potential market impact"
            })
        
        # Check for high volume
        if recent_sentiment.volume > 1000:
            anomalies.append({
                "type": "high_volume",
                "severity": "medium",
                "message": f"High sentiment volume: {recent_sentiment.volume} mentions",
                "recommendation": "Increased attention may indicate significant news"
            })
        
        # Check for momentum shift
        if abs(recent_sentiment.momentum) > 0.5:
            anomalies.append({
                "type": "momentum_shift",
                "severity": "medium",
                "message": f"Sentiment momentum shift: {recent_sentiment.momentum:.2f}",
                "recommendation": "Sentiment trend is changing rapidly"
            })
        
        return anomalies
    
    async def process_market_data(self, market_data: Dict[str, Any]) -> Dict[str, Any]:
        """Process market data and analyze sentiment impact"""
        symbol = market_data.get("symbol")
        if not symbol:
            return {"error": "No symbol provided"}
        
        # Analyze sentiment
        sentiment_result = await self.analyze_sentiment(symbol)
        
        # Detect anomalies
        anomalies = await self.detect_sentiment_anomalies(symbol)
        
        return {
            "symbol": symbol,
            "sentiment": sentiment_result.overall_sentiment,
            "trend": sentiment_result.trend,
            "confidence": sentiment_result.confidence,
            "volume": sentiment_result.volume,
            "anomalies": anomalies,
            "timestamp": sentiment_result.timestamp.isoformat()
        }
    
    async def make_trading_decision(self, account_name: str) -> Dict[str, Any]:
        """Make trading decisions based on sentiment analysis"""
        # This would typically be called by other agents or the main system
        # For now, we'll provide sentiment insights
        
        account = account_manager.get_account(account_name)
        positions = account.get_positions()
        
        sentiment_insights = {}
        
        for symbol in positions.keys():
            sentiment_result = await self.analyze_sentiment(symbol)
            sentiment_insights[symbol] = {
                "sentiment": sentiment_result.overall_sentiment,
                "trend": sentiment_result.trend,
                "confidence": sentiment_result.confidence,
                "recommendation": self._generate_sentiment_recommendation(sentiment_result)
            }
        
        return {
            "agent": self.name,
            "account": account_name,
            "sentiment_insights": sentiment_insights,
            "timestamp": datetime.now().isoformat()
        }
    
    def _generate_sentiment_recommendation(self, sentiment_result: SentimentResult) -> str:
        """Generate trading recommendation based on sentiment"""
        if sentiment_result.trend == "bullish" and sentiment_result.confidence > 0.7:
            return "Strong positive sentiment - consider buying"
        elif sentiment_result.trend == "bearish" and sentiment_result.confidence > 0.7:
            return "Strong negative sentiment - consider selling"
        elif sentiment_result.trend == "bullish":
            return "Positive sentiment - monitor for opportunities"
        elif sentiment_result.trend == "bearish":
            return "Negative sentiment - consider risk management"
        else:
            return "Neutral sentiment - no clear signal"
    
    async def run(self):
        """Main execution loop for sentiment analyzer"""
        while True:
            try:
                # Get all accounts and their positions
                all_accounts = account_manager.get_all_accounts_summary()
                
                symbols_to_analyze = set()
                for account_data in all_accounts.values():
                    positions = account_data.get("positions", {})
                    symbols_to_analyze.update(positions.keys())
                
                # Analyze sentiment for all symbols
                for symbol in symbols_to_analyze:
                    sentiment_result = await self.analyze_sentiment(symbol)
                    
                    # Log performance
                    self.log_performance("sentiment_analysis", 1)
                    self.log_performance("sentiment_score", sentiment_result.overall_sentiment)
                    
                    # Check for anomalies and send alerts
                    anomalies = await self.detect_sentiment_anomalies(symbol)
                    for anomaly in anomalies:
                        if anomaly["severity"] in ["high", "critical"]:
                            db.write_alert(
                                self.name,
                                "sentiment_anomaly",
                                f"{anomaly['type']}: {anomaly['message']}",
                                anomaly["severity"]
                            )
                
                # Wait before next analysis
                await asyncio.sleep(config.SENTIMENT_UPDATE_FREQUENCY * 60)
                
            except Exception as e:
                db.write_alert(self.name, "execution_error", f"Sentiment analyzer error: {str(e)}", "high")
                await asyncio.sleep(60)  # Wait 1 minute before retrying

# Global sentiment analyzer instance
sentiment_analyzer = SentimentAnalyzerAgent()
