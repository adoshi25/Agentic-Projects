"""
Portfolio Optimizer Agent - Modern Portfolio Theory and Optimization
"""
import asyncio
import json
import numpy as np
import pandas as pd
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any, Tuple
from dataclasses import dataclass
from scipy.optimize import minimize
from config.settings import config, AGENT_CONFIGS
from data.enhanced_database import db
from data.enhanced_accounts import account_manager, EnhancedAccount, Position
from agents.base_agent import BaseAgent

@dataclass
class OptimizationResult:
    """Portfolio optimization result"""
    symbol: str
    current_weight: float
    optimal_weight: float
    recommended_action: str  # buy, sell, hold
    quantity_change: int
    expected_return: float
    risk_contribution: float
    sharpe_contribution: float
    timestamp: datetime

@dataclass
class PortfolioMetrics:
    """Portfolio performance metrics"""
    expected_return: float
    volatility: float
    sharpe_ratio: float
    max_drawdown: float
    var_95: float
    diversification_ratio: float
    concentration_risk: float
    correlation_risk: float

class PortfolioOptimizerAgent(BaseAgent):
    """Portfolio Optimizer Agent using Modern Portfolio Theory"""
    
    def __init__(self):
        super().__init__(
            name=AGENT_CONFIGS["portfolio_optimizer"]["name"],
            lastname=AGENT_CONFIGS["portfolio_optimizer"]["lastname"],
            strategy=AGENT_CONFIGS["portfolio_optimizer"]["strategy"],
            model_name=config.PRIMARY_MODEL
        )
        
        # Optimization parameters
        self.risk_free_rate = 0.02  # 2% annual risk-free rate
        self.rebalance_threshold = 0.05  # 5% threshold for rebalancing
        self.max_position_weight = config.MAX_WEIGHT
        self.min_position_weight = config.MIN_WEIGHT
        
        # Optimization methods
        self.optimization_methods = {
            "mean_variance": self._mean_variance_optimization,
            "black_litterman": self._black_litterman_optimization,
            "risk_parity": self._risk_parity_optimization,
            "max_sharpe": self._max_sharpe_optimization
        }
    
    async def optimize_portfolio(self, account: EnhancedAccount, method: str = "mean_variance") -> Dict[str, Any]:
        """Optimize portfolio using specified method"""
        positions = account.get_positions()
        portfolio_value = account.calculate_portfolio_value()
        
        if not positions:
            return {"error": "No positions to optimize"}
        
        # Get historical returns and covariance matrix
        returns_data, covariance_matrix = await self._get_returns_data(list(positions.keys()))
        
        if returns_data is None or covariance_matrix is None:
            return {"error": "Insufficient historical data for optimization"}
        
        # Get current weights
        current_weights = {}
        for symbol, position in positions.items():
            current_weights[symbol] = (position.quantity * position.current_price) / portfolio_value
        
        # Run optimization
        if method in self.optimization_methods:
            optimal_weights = await self.optimization_methods[method](
                returns_data, covariance_matrix, current_weights
            )
        else:
            return {"error": f"Unknown optimization method: {method}"}
        
        # Generate recommendations
        recommendations = await self._generate_recommendations(
            account, current_weights, optimal_weights, returns_data, covariance_matrix
        )
        
        # Calculate portfolio metrics
        portfolio_metrics = await self._calculate_portfolio_metrics(
            optimal_weights, returns_data, covariance_matrix
        )
        
        return {
            "account": account.name,
            "method": method,
            "current_weights": current_weights,
            "optimal_weights": optimal_weights,
            "recommendations": [asdict(rec) for rec in recommendations],
            "portfolio_metrics": asdict(portfolio_metrics),
            "rebalance_needed": self._needs_rebalancing(current_weights, optimal_weights),
            "timestamp": datetime.now().isoformat()
        }
    
    async def _get_returns_data(self, symbols: List[str], lookback_days: int = 252) -> Tuple[Optional[np.ndarray], Optional[np.ndarray]]:
        """Get historical returns and covariance matrix"""
        # This would typically fetch real historical data
        # For now, we'll simulate realistic returns data
        
        np.random.seed(42)  # For reproducible results
        
        # Generate realistic returns data
        n_assets = len(symbols)
        n_days = lookback_days
        
        # Generate correlation matrix
        correlation_matrix = np.random.uniform(0.3, 0.8, (n_assets, n_assets))
        correlation_matrix = (correlation_matrix + correlation_matrix.T) / 2
        np.fill_diagonal(correlation_matrix, 1.0)
        
        # Generate volatilities (annualized)
        volatilities = np.random.uniform(0.15, 0.35, n_assets)
        
        # Generate expected returns (annualized)
        expected_returns = np.random.uniform(0.05, 0.15, n_assets)
        
        # Generate covariance matrix
        covariance_matrix = np.outer(volatilities, volatilities) * correlation_matrix
        
        # Generate daily returns
        returns = np.random.multivariate_normal(
            expected_returns / 252,  # Daily expected returns
            covariance_matrix / 252,  # Daily covariance matrix
            n_days
        )
        
        return returns, covariance_matrix
    
    async def _mean_variance_optimization(self, returns: np.ndarray, covariance: np.ndarray, 
                                        current_weights: Dict[str, float]) -> Dict[str, float]:
        """Mean-variance optimization (Markowitz)"""
        n_assets = len(current_weights)
        symbols = list(current_weights.keys())
        
        # Calculate expected returns and covariance matrix
        expected_returns = np.mean(returns, axis=0)
        
        # Objective function: minimize portfolio variance
        def objective(weights):
            return np.dot(weights, np.dot(covariance, weights))
        
        # Constraints
        constraints = [
            {'type': 'eq', 'fun': lambda w: np.sum(w) - 1.0}  # Weights sum to 1
        ]
        
        # Bounds
        bounds = [(self.min_position_weight, self.max_position_weight) for _ in range(n_assets)]
        
        # Initial guess
        x0 = np.array([current_weights[symbol] for symbol in symbols])
        
        # Optimize
        result = minimize(objective, x0, method='SLSQP', bounds=bounds, constraints=constraints)
        
        if result.success:
            optimal_weights = dict(zip(symbols, result.x))
        else:
            # Fallback to equal weights
            optimal_weights = {symbol: 1.0 / n_assets for symbol in symbols}
        
        return optimal_weights
    
    async def _black_litterman_optimization(self, returns: np.ndarray, covariance: np.ndarray,
                                          current_weights: Dict[str, float]) -> Dict[str, float]:
        """Black-Litterman optimization"""
        # Simplified Black-Litterman implementation
        # In practice, this would use market cap weights and views
        
        n_assets = len(current_weights)
        symbols = list(current_weights.keys())
        
        # Market cap weights (simplified - would use actual market caps)
        market_weights = {symbol: 1.0 / n_assets for symbol in symbols}
        
        # Risk aversion parameter
        risk_aversion = 3.0
        
        # Calculate implied returns
        implied_returns = risk_aversion * np.dot(covariance, np.array([market_weights[symbol] for symbol in symbols]))
        
        # Views (simplified - would be based on analyst opinions)
        views = np.zeros(n_assets)
        view_uncertainty = np.eye(n_assets) * 0.1
        
        # Black-Litterman formula
        tau = 0.05  # Scaling factor
        P = np.eye(n_assets)  # Picking matrix
        Q = views  # View vector
        
        # Calculate posterior parameters
        M1 = np.linalg.inv(tau * covariance)
        M2 = np.dot(P.T, np.linalg.inv(view_uncertainty))
        M3 = np.dot(M2, P)
        M4 = np.dot(M2, Q)
        
        posterior_covariance = np.linalg.inv(M1 + M3)
        posterior_returns = np.dot(posterior_covariance, np.dot(M1, implied_returns) + M4)
        
        # Optimize with posterior parameters
        def objective(weights):
            portfolio_return = np.dot(weights, posterior_returns)
            portfolio_variance = np.dot(weights, np.dot(posterior_covariance, weights))
            return -portfolio_return + 0.5 * risk_aversion * portfolio_variance
        
        constraints = [{'type': 'eq', 'fun': lambda w: np.sum(w) - 1.0}]
        bounds = [(self.min_position_weight, self.max_position_weight) for _ in range(n_assets)]
        x0 = np.array([current_weights[symbol] for symbol in symbols])
        
        result = minimize(objective, x0, method='SLSQP', bounds=bounds, constraints=constraints)
        
        if result.success:
            optimal_weights = dict(zip(symbols, result.x))
        else:
            optimal_weights = {symbol: 1.0 / n_assets for symbol in symbols}
        
        return optimal_weights
    
    async def _risk_parity_optimization(self, returns: np.ndarray, covariance: np.ndarray,
                                      current_weights: Dict[str, float]) -> Dict[str, float]:
        """Risk parity optimization"""
        n_assets = len(current_weights)
        symbols = list(current_weights.keys())
        
        # Risk parity: each asset contributes equally to portfolio risk
        def objective(weights):
            portfolio_variance = np.dot(weights, np.dot(covariance, weights))
            risk_contributions = weights * np.dot(covariance, weights) / portfolio_variance
            return np.sum((risk_contributions - 1.0 / n_assets) ** 2)
        
        constraints = [{'type': 'eq', 'fun': lambda w: np.sum(w) - 1.0}]
        bounds = [(self.min_position_weight, self.max_position_weight) for _ in range(n_assets)]
        x0 = np.array([current_weights[symbol] for symbol in symbols])
        
        result = minimize(objective, x0, method='SLSQP', bounds=bounds, constraints=constraints)
        
        if result.success:
            optimal_weights = dict(zip(symbols, result.x))
        else:
            optimal_weights = {symbol: 1.0 / n_assets for symbol in symbols}
        
        return optimal_weights
    
    async def _max_sharpe_optimization(self, returns: np.ndarray, covariance: np.ndarray,
                                     current_weights: Dict[str, float]) -> Dict[str, float]:
        """Maximum Sharpe ratio optimization"""
        n_assets = len(current_weights)
        symbols = list(current_weights.keys())
        
        expected_returns = np.mean(returns, axis=0)
        
        # Objective: maximize Sharpe ratio
        def objective(weights):
            portfolio_return = np.dot(weights, expected_returns)
            portfolio_variance = np.dot(weights, np.dot(covariance, weights))
            if portfolio_variance <= 0:
                return -np.inf
            sharpe_ratio = (portfolio_return - self.risk_free_rate) / np.sqrt(portfolio_variance)
            return -sharpe_ratio  # Minimize negative Sharpe ratio
        
        constraints = [{'type': 'eq', 'fun': lambda w: np.sum(w) - 1.0}]
        bounds = [(self.min_position_weight, self.max_position_weight) for _ in range(n_assets)]
        x0 = np.array([current_weights[symbol] for symbol in symbols])
        
        result = minimize(objective, x0, method='SLSQP', bounds=bounds, constraints=constraints)
        
        if result.success:
            optimal_weights = dict(zip(symbols, result.x))
        else:
            optimal_weights = {symbol: 1.0 / n_assets for symbol in symbols}
        
        return optimal_weights
    
    async def _generate_recommendations(self, account: EnhancedAccount, current_weights: Dict[str, float],
                                      optimal_weights: Dict[str, float], returns: np.ndarray,
                                      covariance: np.ndarray) -> List[OptimizationResult]:
        """Generate trading recommendations based on optimization results"""
        recommendations = []
        portfolio_value = account.calculate_portfolio_value()
        
        # Get all symbols (current + optimal)
        all_symbols = set(current_weights.keys()) | set(optimal_weights.keys())
        
        for symbol in all_symbols:
            current_weight = current_weights.get(symbol, 0.0)
            optimal_weight = optimal_weights.get(symbol, 0.0)
            weight_diff = optimal_weight - current_weight
            
            # Calculate quantity change
            current_price = db.get_latest_price(symbol) or 0.0
            if current_price > 0:
                quantity_change = int((weight_diff * portfolio_value) / current_price)
            else:
                quantity_change = 0
            
            # Determine action
            if weight_diff > self.rebalance_threshold:
                action = "buy"
            elif weight_diff < -self.rebalance_threshold:
                action = "sell"
            else:
                action = "hold"
            
            # Calculate expected return and risk contribution
            if symbol in optimal_weights:
                symbol_index = list(optimal_weights.keys()).index(symbol)
                expected_return = np.mean(returns[:, symbol_index]) * 252  # Annualized
                risk_contribution = optimal_weight * np.dot(covariance[symbol_index], 
                                                          np.array([optimal_weights[s] for s in optimal_weights.keys()]))
            else:
                expected_return = 0.0
                risk_contribution = 0.0
            
            # Calculate Sharpe contribution
            portfolio_return = sum(optimal_weights[s] * np.mean(returns[:, list(optimal_weights.keys()).index(s)]) 
                                 for s in optimal_weights.keys()) * 252
            portfolio_variance = np.dot(np.array([optimal_weights[s] for s in optimal_weights.keys()]),
                                      np.dot(covariance, np.array([optimal_weights[s] for s in optimal_weights.keys()])))
            sharpe_ratio = (portfolio_return - self.risk_free_rate) / np.sqrt(portfolio_variance)
            sharpe_contribution = optimal_weight * sharpe_ratio
            
            recommendations.append(OptimizationResult(
                symbol=symbol,
                current_weight=current_weight,
                optimal_weight=optimal_weight,
                recommended_action=action,
                quantity_change=quantity_change,
                expected_return=expected_return,
                risk_contribution=risk_contribution,
                sharpe_contribution=sharpe_contribution,
                timestamp=datetime.now()
            ))
        
        return recommendations
    
    async def _calculate_portfolio_metrics(self, weights: Dict[str, float], returns: np.ndarray,
                                         covariance: np.ndarray) -> PortfolioMetrics:
        """Calculate portfolio performance metrics"""
        symbols = list(weights.keys())
        weight_vector = np.array([weights[symbol] for symbol in symbols])
        
        # Expected return
        expected_returns = np.mean(returns, axis=0)
        portfolio_return = np.dot(weight_vector, expected_returns) * 252  # Annualized
        
        # Volatility
        portfolio_variance = np.dot(weight_vector, np.dot(covariance, weight_vector))
        portfolio_volatility = np.sqrt(portfolio_variance)
        
        # Sharpe ratio
        sharpe_ratio = (portfolio_return - self.risk_free_rate) / portfolio_volatility
        
        # VaR (simplified)
        portfolio_returns = np.dot(returns, weight_vector)
        var_95 = np.percentile(portfolio_returns, 5)
        
        # Max drawdown (simplified)
        cumulative_returns = np.cumprod(1 + portfolio_returns)
        running_max = np.maximum.accumulate(cumulative_returns)
        drawdowns = (cumulative_returns - running_max) / running_max
        max_drawdown = np.min(drawdowns)
        
        # Diversification ratio
        individual_volatilities = np.sqrt(np.diag(covariance))
        weighted_volatility = np.dot(weight_vector, individual_volatilities)
        diversification_ratio = weighted_volatility / portfolio_volatility
        
        # Concentration risk (Herfindahl index)
        concentration_risk = np.sum(weight_vector ** 2)
        
        # Correlation risk (average correlation)
        correlation_matrix = np.corrcoef(returns.T)
        correlation_risk = np.mean(correlation_matrix[np.triu_indices_from(correlation_matrix, k=1)])
        
        return PortfolioMetrics(
            expected_return=portfolio_return,
            volatility=portfolio_volatility,
            sharpe_ratio=sharpe_ratio,
            max_drawdown=max_drawdown,
            var_95=var_95,
            diversification_ratio=diversification_ratio,
            concentration_risk=concentration_risk,
            correlation_risk=correlation_risk
        )
    
    def _needs_rebalancing(self, current_weights: Dict[str, float], optimal_weights: Dict[str, float]) -> bool:
        """Check if portfolio needs rebalancing"""
        for symbol in current_weights:
            if symbol in optimal_weights:
                weight_diff = abs(current_weights[symbol] - optimal_weights[symbol])
                if weight_diff > self.rebalance_threshold:
                    return True
        return False
    
    async def process_market_data(self, market_data: Dict[str, Any]) -> Dict[str, Any]:
        """Process market data and optimize portfolio"""
        account_name = market_data.get("account_name")
        if not account_name:
            return {"error": "No account name provided"}
        
        account = account_manager.get_account(account_name)
        optimization_result = await self.optimize_portfolio(account)
        
        return optimization_result
    
    async def make_trading_decision(self, account_name: str) -> Dict[str, Any]:
        """Make trading decisions based on portfolio optimization"""
        account = account_manager.get_account(account_name)
        
        # Run optimization
        optimization_result = await self.optimize_portfolio(account, method=config.OPTIMIZATION_METHOD)
        
        # Generate actionable recommendations
        actionable_recommendations = []
        for rec in optimization_result.get("recommendations", []):
            if rec["recommended_action"] != "hold" and abs(rec["quantity_change"]) > 0:
                actionable_recommendations.append(rec)
        
        return {
            "agent": self.name,
            "account": account_name,
            "optimization_result": optimization_result,
            "actionable_recommendations": actionable_recommendations,
            "timestamp": datetime.now().isoformat()
        }
    
    async def run(self):
        """Main execution loop for portfolio optimizer"""
        while True:
            try:
                # Get all accounts
                all_accounts = account_manager.get_all_accounts_summary()
                
                for account_name in all_accounts.keys():
                    # Run portfolio optimization
                    optimization_result = await self.optimize_portfolio(
                        account_manager.get_account(account_name),
                        method=config.OPTIMIZATION_METHOD
                    )
                    
                    # Log performance metrics
                    if "portfolio_metrics" in optimization_result:
                        metrics = optimization_result["portfolio_metrics"]
                        self.log_performance("expected_return", metrics["expected_return"])
                        self.log_performance("sharpe_ratio", metrics["sharpe_ratio"])
                        self.log_performance("volatility", metrics["volatility"])
                    
                    # Check if rebalancing is needed
                    if optimization_result.get("rebalance_needed", False):
                        db.write_alert(
                            self.name,
                            "rebalancing_needed",
                            f"Portfolio rebalancing recommended for {account_name}",
                            "medium"
                        )
                    
                    # Check for significant optimization opportunities
                    recommendations = optimization_result.get("recommendations", [])
                    significant_changes = [r for r in recommendations 
                                         if abs(r["quantity_change"]) > 100 and r["recommended_action"] != "hold"]
                    
                    if significant_changes:
                        db.write_alert(
                            self.name,
                            "optimization_opportunity",
                            f"Significant optimization opportunities found for {account_name}: {len(significant_changes)} recommendations",
                            "medium"
                        )
                
                # Wait before next optimization
                await asyncio.sleep(config.RUN_EVERY_N_MINUTES * 60)
                
            except Exception as e:
                db.write_alert(self.name, "execution_error", f"Portfolio optimizer error: {str(e)}", "high")
                await asyncio.sleep(60)  # Wait 1 minute before retrying

# Global portfolio optimizer instance
portfolio_optimizer = PortfolioOptimizerAgent()
