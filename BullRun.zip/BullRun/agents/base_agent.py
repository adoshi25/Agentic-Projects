"""
Base Agent Class for Enhanced Trading System
"""
import asyncio
import json
from datetime import datetime
from typing import Dict, List, Optional, Any
from abc import ABC, abstractmethod
from dataclasses import dataclass
from config.settings import config
from data.enhanced_database import db
from data.enhanced_accounts import account_manager

@dataclass
class AgentMessage:
    """Standardized message format for agent communication"""
    sender: str
    recipient: str
    message_type: str  # trade_request, risk_alert, market_update, etc.
    content: Dict[str, Any]
    timestamp: datetime
    priority: str = "medium"  # low, medium, high, critical

class BaseAgent(ABC):
    """Base class for all trading agents"""
    
    def __init__(self, name: str, lastname: str, strategy: str, model_name: str = None):
        self.name = name
        self.lastname = lastname
        self.strategy = strategy
        self.model_name = model_name or config.PRIMARY_MODEL
        self.is_active = True
        self.message_queue: List[AgentMessage] = []
        self.performance_history: List[Dict] = []
        self.last_run_time: Optional[datetime] = None
        
    @abstractmethod
    async def run(self):
        """Main execution loop - must be implemented by subclasses"""
        pass
    
    @abstractmethod
    async def process_market_data(self, market_data: Dict[str, Any]) -> Dict[str, Any]:
        """Process incoming market data - must be implemented by subclasses"""
        pass
    
    @abstractmethod
    async def make_trading_decision(self, account_name: str) -> Dict[str, Any]:
        """Make trading decisions - must be implemented by subclasses"""
        pass
    
    def send_message(self, recipient: str, message_type: str, content: Dict[str, Any], priority: str = "medium"):
        """Send message to another agent"""
        message = AgentMessage(
            sender=self.name,
            recipient=recipient,
            message_type=message_type,
            content=content,
            timestamp=datetime.now(),
            priority=priority
        )
        
        # In a real system, this would route to the recipient's message queue
        # For now, we'll log it
        db.write_alert(
            self.name,
            "agent_message",
            f"Message to {recipient}: {message_type} - {json.dumps(content)}"
        )
    
    def receive_message(self, message: AgentMessage):
        """Receive message from another agent"""
        self.message_queue.append(message)
        
        # Process high priority messages immediately
        if message.priority in ["high", "critical"]:
            asyncio.create_task(self._process_priority_message(message))
    
    async def _process_priority_message(self, message: AgentMessage):
        """Process high priority messages immediately"""
        try:
            if message.message_type == "risk_alert":
                await self._handle_risk_alert(message)
            elif message.message_type == "market_crash":
                await self._handle_market_crash(message)
            elif message.message_type == "emergency_stop":
                await self._handle_emergency_stop(message)
        except Exception as e:
            db.write_alert(
                self.name,
                "error",
                f"Error processing priority message: {str(e)}",
                "high"
            )
    
    async def _handle_risk_alert(self, message: AgentMessage):
        """Handle risk alerts from risk manager"""
        # Default implementation - can be overridden by subclasses
        db.write_alert(
            self.name,
            "risk_response",
            f"Received risk alert: {message.content.get('message', 'Unknown risk')}"
        )
    
    async def _handle_market_crash(self, message: AgentMessage):
        """Handle market crash alerts"""
        # Default implementation - can be overridden by subclasses
        db.write_alert(
            self.name,
            "crash_response",
            "Market crash detected - implementing defensive measures"
        )
    
    async def _handle_emergency_stop(self, message: AgentMessage):
        """Handle emergency stop orders"""
        # Default implementation - can be overridden by subclasses
        self.is_active = False
        db.write_alert(
            self.name,
            "emergency_stop",
            "Emergency stop activated - halting all trading activities"
        )
    
    def log_performance(self, metric_name: str, value: float, period: str = "daily"):
        """Log performance metrics"""
        db.write_performance_metric(self.name, metric_name, value, period)
        
        # Store in local history
        self.performance_history.append({
            "metric_name": metric_name,
            "value": value,
            "period": period,
            "timestamp": datetime.now().isoformat()
        })
    
    def get_performance_summary(self, days: int = 30) -> Dict[str, Any]:
        """Get performance summary for the agent"""
        performance_data = db.get_performance_metrics(self.name, days=days)
        
        if not performance_data:
            return {"error": "No performance data available"}
        
        # Group by metric name
        metrics = {}
        for record in performance_data:
            metric_name = record["metric_name"]
            if metric_name not in metrics:
                metrics[metric_name] = []
            metrics[metric_name].append(record["metric_value"])
        
        # Calculate summary statistics
        summary = {}
        for metric_name, values in metrics.items():
            if values:
                summary[metric_name] = {
                    "current": values[0],
                    "average": sum(values) / len(values),
                    "min": min(values),
                    "max": max(values),
                    "count": len(values)
                }
        
        return summary
    
    async def execute_trade(self, account_name: str, symbol: str, quantity: int, 
                          action: str, rationale: str, **kwargs) -> Dict[str, Any]:
        """Execute a trade with risk management"""
        try:
            account = account_manager.get_account(account_name)
            
            # Check if agent is active
            if not self.is_active:
                return {"error": "Agent is not active"}
            
            # Execute the trade
            if action.lower() == "buy":
                result = account.buy_shares(
                    symbol=symbol,
                    quantity=quantity,
                    rationale=rationale,
                    agent_name=self.name,
                    **kwargs
                )
            elif action.lower() == "sell":
                result = account.sell_shares(
                    symbol=symbol,
                    quantity=quantity,
                    rationale=rationale,
                    agent_name=self.name
                )
            else:
                return {"error": f"Invalid action: {action}"}
            
            # Log the trade
            self.log_performance("trades_executed", 1)
            
            # Save account
            account.save()
            
            return {
                "success": True,
                "result": result,
                "account": account_name,
                "agent": self.name
            }
            
        except Exception as e:
            db.write_alert(
                self.name,
                "trade_error",
                f"Trade execution failed: {str(e)}",
                "high"
            )
            return {"error": str(e)}
    
    def get_account_summary(self, account_name: str) -> Dict[str, Any]:
        """Get account summary"""
        try:
            account = account_manager.get_account(account_name)
            return account.get_portfolio_summary()
        except Exception as e:
            return {"error": str(e)}
    
    def get_market_data(self, symbol: str) -> Optional[Dict[str, Any]]:
        """Get latest market data for a symbol"""
        try:
            price = db.get_latest_price(symbol)
            if price:
                return {
                    "symbol": symbol,
                    "price": price,
                    "timestamp": datetime.now().isoformat()
                }
            return None
        except Exception as e:
            db.write_alert(
                self.name,
                "data_error",
                f"Error getting market data for {symbol}: {str(e)}"
            )
            return None
    
    def get_sentiment_data(self, symbol: str) -> Optional[Dict[str, Any]]:
        """Get sentiment data for a symbol"""
        try:
            return db.get_aggregated_sentiment(symbol)
        except Exception as e:
            db.write_alert(
                self.name,
                "data_error",
                f"Error getting sentiment data for {symbol}: {str(e)}"
            )
            return None
    
    def get_technical_signals(self, symbol: str) -> List[Dict]:
        """Get technical signals for a symbol"""
        try:
            return db.get_technical_signals(symbol)
        except Exception as e:
            db.write_alert(
                self.name,
                "data_error",
                f"Error getting technical signals for {symbol}: {str(e)}"
            )
            return []
    
    def get_ml_predictions(self, symbol: str) -> List[Dict]:
        """Get ML predictions for a symbol"""
        try:
            return db.get_ml_predictions(symbol)
        except Exception as e:
            db.write_alert(
                self.name,
                "data_error",
                f"Error getting ML predictions for {symbol}: {str(e)}"
            )
            return []
    
    async def run_with_error_handling(self):
        """Run agent with comprehensive error handling"""
        try:
            self.last_run_time = datetime.now()
            await self.run()
        except Exception as e:
            db.write_alert(
                self.name,
                "execution_error",
                f"Agent execution error: {str(e)}",
                "high"
            )
            # Wait before retrying
            await asyncio.sleep(60)
    
    def __str__(self):
        return f"{self.name} {self.lastname} ({self.__class__.__name__})"
    
    def __repr__(self):
        return f"{self.__class__.__name__}(name='{self.name}', strategy='{self.strategy[:50]}...')"
