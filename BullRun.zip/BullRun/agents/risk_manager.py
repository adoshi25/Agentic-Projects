"""
Risk Manager Agent - Portfolio Risk Assessment and Position Sizing
"""
import asyncio
import json
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any, Tuple
import numpy as np
import pandas as pd
from dataclasses import dataclass
from config.settings import config, AGENT_CONFIGS
from data.enhanced_database import db, RiskMetrics
from data.enhanced_accounts import account_manager, EnhancedAccount, Position
from agents.base_agent import BaseAgent

@dataclass
class RiskAssessment:
    """Risk assessment results"""
    portfolio_id: str
    overall_risk_score: float  # 0-100
    var_95: float
    var_99: float
    max_drawdown: float
    sharpe_ratio: float
    beta: float
    concentration_risk: float
    correlation_risk: float
    liquidity_risk: float
    recommendations: List[str]
    alerts: List[str]
    timestamp: datetime

class RiskManagerAgent(BaseAgent):
    """Risk Manager Agent for portfolio risk assessment"""
    
    def __init__(self):
        super().__init__(
            name=AGENT_CONFIGS["risk_manager"]["name"],
            lastname=AGENT_CONFIGS["risk_manager"]["lastname"],
            strategy=AGENT_CONFIGS["risk_manager"]["strategy"],
            model_name=config.PRIMARY_MODEL
        )
        self.risk_thresholds = {
            "var_95": -0.05,  # 5% daily VaR
            "var_99": -0.08,  # 8% daily VaR
            "max_drawdown": -0.15,  # 15% max drawdown
            "concentration": 0.3,  # 30% max single position
            "correlation": 0.7,  # 70% max correlation
            "sharpe_min": 0.5  # Minimum Sharpe ratio
        }
    
    async def assess_portfolio_risk(self, account: EnhancedAccount) -> RiskAssessment:
        """Comprehensive portfolio risk assessment"""
        portfolio_value = account.calculate_portfolio_value()
        positions = account.get_positions()
        
        if not positions:
            return RiskAssessment(
                portfolio_id=account.name,
                overall_risk_score=0.0,
                var_95=0.0,
                var_99=0.0,
                max_drawdown=0.0,
                sharpe_ratio=0.0,
                beta=1.0,
                concentration_risk=0.0,
                correlation_risk=0.0,
                liquidity_risk=0.0,
                recommendations=[],
                alerts=[],
                timestamp=datetime.now()
            )
        
        # Calculate Value at Risk (VaR)
        var_95, var_99 = await self._calculate_var(positions, portfolio_value)
        
        # Calculate maximum drawdown
        max_drawdown = await self._calculate_max_drawdown(account)
        
        # Calculate Sharpe ratio
        sharpe_ratio = await self._calculate_sharpe_ratio(account)
        
        # Calculate concentration risk
        concentration_risk = self._calculate_concentration_risk(positions)
        
        # Calculate correlation risk
        correlation_risk = await self._calculate_correlation_risk(positions)
        
        # Calculate liquidity risk
        liquidity_risk = await self._calculate_liquidity_risk(positions)
        
        # Calculate beta
        beta = await self._calculate_portfolio_beta(positions)
        
        # Calculate overall risk score
        overall_risk_score = self._calculate_overall_risk_score(
            var_95, var_99, max_drawdown, concentration_risk, 
            correlation_risk, liquidity_risk, sharpe_ratio
        )
        
        # Generate recommendations and alerts
        recommendations = self._generate_recommendations(
            var_95, var_99, max_drawdown, concentration_risk, 
            correlation_risk, liquidity_risk, sharpe_ratio
        )
        
        alerts = self._generate_alerts(
            var_95, var_99, max_drawdown, concentration_risk, 
            correlation_risk, liquidity_risk, sharpe_ratio
        )
        
        risk_assessment = RiskAssessment(
            portfolio_id=account.name,
            overall_risk_score=overall_risk_score,
            var_95=var_95,
            var_99=var_99,
            max_drawdown=max_drawdown,
            sharpe_ratio=sharpe_ratio,
            beta=beta,
            concentration_risk=concentration_risk,
            correlation_risk=correlation_risk,
            liquidity_risk=liquidity_risk,
            recommendations=recommendations,
            alerts=alerts,
            timestamp=datetime.now()
        )
        
        # Store risk metrics in database
        risk_metrics = RiskMetrics(
            portfolio_id=account.name,
            var_95=var_95,
            var_99=var_99,
            sharpe_ratio=sharpe_ratio,
            max_drawdown=max_drawdown,
            beta=beta,
            correlation_matrix={},  # Would be populated with actual correlation data
            concentration_risk=concentration_risk,
            timestamp=datetime.now()
        )
        db.write_risk_metrics(risk_metrics)
        
        return risk_assessment
    
    async def _calculate_var(self, positions: Dict[str, Position], portfolio_value: float) -> Tuple[float, float]:
        """Calculate Value at Risk using historical simulation"""
        if not positions:
            return 0.0, 0.0
        
        # Get historical returns for each position
        returns_data = {}
        for symbol, position in positions.items():
            # This would typically fetch historical price data
            # For now, we'll use a simplified approach
            returns_data[symbol] = np.random.normal(0, 0.02, 252)  # 2% daily volatility
        
        # Calculate portfolio returns
        portfolio_returns = []
        for i in range(252):
            portfolio_return = 0
            for symbol, position in positions.items():
                weight = (position.quantity * position.current_price) / portfolio_value
                portfolio_return += weight * returns_data[symbol][i]
            portfolio_returns.append(portfolio_return)
        
        # Calculate VaR
        var_95 = np.percentile(portfolio_returns, 5)
        var_99 = np.percentile(portfolio_returns, 1)
        
        return var_95, var_99
    
    async def _calculate_max_drawdown(self, account: EnhancedAccount) -> float:
        """Calculate maximum drawdown from portfolio value time series"""
        if len(account.portfolio_value_time_series) < 2:
            return 0.0
        
        values = [point[1] for point in account.portfolio_value_time_series]
        peak = values[0]
        max_dd = 0.0
        
        for value in values:
            if value > peak:
                peak = value
            drawdown = (peak - value) / peak
            if drawdown > max_dd:
                max_dd = drawdown
        
        return -max_dd  # Return as negative value
    
    async def _calculate_sharpe_ratio(self, account: EnhancedAccount) -> float:
        """Calculate Sharpe ratio"""
        if len(account.portfolio_value_time_series) < 2:
            return 0.0
        
        values = [point[1] for point in account.portfolio_value_time_series]
        returns = np.diff(values) / values[:-1]
        
        if len(returns) == 0 or np.std(returns) == 0:
            return 0.0
        
        risk_free_rate = 0.02 / 252  # Daily risk-free rate
        excess_returns = returns - risk_free_rate
        sharpe_ratio = np.mean(excess_returns) / np.std(returns) * np.sqrt(252)
        
        return sharpe_ratio
    
    def _calculate_concentration_risk(self, positions: Dict[str, Position]) -> float:
        """Calculate concentration risk (Herfindahl index)"""
        if not positions:
            return 0.0
        
        weights = [pos.position_size_percent / 100 for pos in positions.values()]
        herfindahl_index = sum(w**2 for w in weights)
        
        return herfindahl_index
    
    async def _calculate_correlation_risk(self, positions: Dict[str, Position]) -> float:
        """Calculate correlation risk between positions"""
        if len(positions) < 2:
            return 0.0
        
        # This would typically use actual correlation data
        # For now, we'll use a simplified approach
        symbols = list(positions.keys())
        max_correlation = 0.0
        
        for i, symbol1 in enumerate(symbols):
            for symbol2 in symbols[i+1:]:
                # Simplified correlation calculation
                correlation = np.random.uniform(0.3, 0.8)  # Placeholder
                max_correlation = max(max_correlation, correlation)
        
        return max_correlation
    
    async def _calculate_liquidity_risk(self, positions: Dict[str, Position]) -> float:
        """Calculate liquidity risk based on position sizes and market caps"""
        if not positions:
            return 0.0
        
        # Simplified liquidity risk calculation
        # In practice, this would consider market cap, average daily volume, etc.
        total_liquidity_risk = 0.0
        
        for position in positions.values():
            # Larger positions = higher liquidity risk
            position_risk = min(position.position_size_percent / 10, 1.0)
            total_liquidity_risk += position_risk
        
        return total_liquidity_risk / len(positions)
    
    async def _calculate_portfolio_beta(self, positions: Dict[str, Position]) -> float:
        """Calculate portfolio beta"""
        if not positions:
            return 1.0
        
        # Simplified beta calculation
        # In practice, this would use actual beta data for each stock
        weighted_beta = 0.0
        total_weight = 0.0
        
        for position in positions.values():
            weight = position.position_size_percent / 100
            beta = np.random.uniform(0.5, 1.5)  # Placeholder beta
            weighted_beta += weight * beta
            total_weight += weight
        
        return weighted_beta / total_weight if total_weight > 0 else 1.0
    
    def _calculate_overall_risk_score(self, var_95: float, var_99: float, 
                                    max_drawdown: float, concentration_risk: float,
                                    correlation_risk: float, liquidity_risk: float,
                                    sharpe_ratio: float) -> float:
        """Calculate overall risk score (0-100, higher = riskier)"""
        risk_components = []
        
        # VaR risk (higher absolute VaR = higher risk)
        var_risk = min(abs(var_95) * 20, 25)  # Cap at 25 points
        risk_components.append(var_risk)
        
        # Drawdown risk
        drawdown_risk = min(abs(max_drawdown) * 100, 25)  # Cap at 25 points
        risk_components.append(drawdown_risk)
        
        # Concentration risk
        concentration_risk_score = concentration_risk * 20  # Cap at 20 points
        risk_components.append(concentration_risk_score)
        
        # Correlation risk
        correlation_risk_score = correlation_risk * 15  # Cap at 15 points
        risk_components.append(correlation_risk_score)
        
        # Liquidity risk
        liquidity_risk_score = liquidity_risk * 10  # Cap at 10 points
        risk_components.append(liquidity_risk_score)
        
        # Sharpe ratio penalty (lower Sharpe = higher risk)
        sharpe_penalty = max(0, (0.5 - sharpe_ratio) * 5)  # Cap at 5 points
        risk_components.append(sharpe_penalty)
        
        return min(sum(risk_components), 100.0)
    
    def _generate_recommendations(self, var_95: float, var_99: float,
                                max_drawdown: float, concentration_risk: float,
                                correlation_risk: float, liquidity_risk: float,
                                sharpe_ratio: float) -> List[str]:
        """Generate risk management recommendations"""
        recommendations = []
        
        if abs(var_95) > abs(self.risk_thresholds["var_95"]):
            recommendations.append(f"Consider reducing position sizes. VaR 95% is {var_95:.2%}, above threshold of {self.risk_thresholds['var_95']:.2%}")
        
        if abs(max_drawdown) > abs(self.risk_thresholds["max_drawdown"]):
            recommendations.append(f"Maximum drawdown of {max_drawdown:.2%} exceeds threshold of {self.risk_thresholds['max_drawdown']:.2%}. Consider diversification.")
        
        if concentration_risk > self.risk_thresholds["concentration"]:
            recommendations.append(f"Portfolio concentration risk of {concentration_risk:.2%} is high. Consider diversifying across more positions.")
        
        if correlation_risk > self.risk_thresholds["correlation"]:
            recommendations.append(f"High correlation between positions ({correlation_risk:.2%}). Consider adding uncorrelated assets.")
        
        if sharpe_ratio < self.risk_thresholds["sharpe_min"]:
            recommendations.append(f"Sharpe ratio of {sharpe_ratio:.2f} is below minimum threshold of {self.risk_thresholds['sharpe_min']:.2f}. Review strategy effectiveness.")
        
        if liquidity_risk > 0.5:
            recommendations.append("High liquidity risk detected. Consider reducing position sizes in less liquid assets.")
        
        if not recommendations:
            recommendations.append("Portfolio risk levels are within acceptable ranges.")
        
        return recommendations
    
    def _generate_alerts(self, var_95: float, var_99: float,
                        max_drawdown: float, concentration_risk: float,
                        correlation_risk: float, liquidity_risk: float,
                        sharpe_ratio: float) -> List[str]:
        """Generate risk alerts"""
        alerts = []
        
        if abs(var_95) > 0.08:  # 8% daily VaR
            alerts.append(f"CRITICAL: VaR 95% exceeds 8% threshold: {var_95:.2%}")
        
        if abs(max_drawdown) > 0.20:  # 20% drawdown
            alerts.append(f"CRITICAL: Maximum drawdown exceeds 20%: {max_drawdown:.2%}")
        
        if concentration_risk > 0.5:  # 50% concentration
            alerts.append(f"HIGH: Portfolio concentration risk exceeds 50%: {concentration_risk:.2%}")
        
        if correlation_risk > 0.8:  # 80% correlation
            alerts.append(f"HIGH: Position correlation exceeds 80%: {correlation_risk:.2%}")
        
        if sharpe_ratio < 0.0:  # Negative Sharpe
            alerts.append(f"WARNING: Negative Sharpe ratio: {sharpe_ratio:.2f}")
        
        return alerts
    
    async def recommend_position_sizing(self, symbol: str, account: EnhancedAccount, 
                                      suggested_quantity: int) -> Dict[str, Any]:
        """Recommend optimal position sizing based on risk parameters"""
        current_price = db.get_latest_price(symbol) or 0.0
        if current_price == 0:
            return {"error": f"Unable to get price for {symbol}"}
        
        portfolio_value = account.calculate_portfolio_value()
        suggested_value = suggested_quantity * current_price
        suggested_weight = suggested_value / portfolio_value
        
        # Risk-based position sizing
        max_position_value = portfolio_value * config.MAX_POSITION_SIZE
        max_quantity = int(max_position_value / current_price)
        
        # Kelly Criterion (simplified)
        # This would typically use expected return and variance
        kelly_fraction = 0.1  # Conservative 10% Kelly
        kelly_value = portfolio_value * kelly_fraction
        kelly_quantity = int(kelly_value / current_price)
        
        # Volatility-based sizing
        # Assume 2% daily volatility for simplicity
        daily_volatility = 0.02
        max_daily_loss = portfolio_value * 0.01  # 1% max daily loss
        volatility_quantity = int(max_daily_loss / (current_price * daily_volatility))
        
        # Final recommendation
        recommended_quantity = min(suggested_quantity, max_quantity, kelly_quantity, volatility_quantity)
        recommended_quantity = max(0, recommended_quantity)  # Ensure non-negative
        
        return {
            "symbol": symbol,
            "suggested_quantity": suggested_quantity,
            "recommended_quantity": recommended_quantity,
            "max_quantity": max_quantity,
            "kelly_quantity": kelly_quantity,
            "volatility_quantity": volatility_quantity,
            "position_weight": (recommended_quantity * current_price) / portfolio_value,
            "rationale": f"Risk-adjusted position sizing based on portfolio constraints and volatility"
        }
    
    async def run_risk_assessment(self, account_name: str) -> RiskAssessment:
        """Run comprehensive risk assessment for an account"""
        account = account_manager.get_account(account_name)
        risk_assessment = await self.assess_portfolio_risk(account)
        
        # Log the assessment
        db.write_alert(
            self.name,
            "risk_assessment",
            f"Risk assessment completed for {account_name}. Overall risk score: {risk_assessment.overall_risk_score:.1f}/100"
        )
        
        # Send alerts if any critical issues
        for alert in risk_assessment.alerts:
            db.write_alert(self.name, "risk_alert", alert, "high")
        
        return risk_assessment
    
    async def run(self):
        """Main execution loop for risk manager"""
        while True:
            try:
                # Get all accounts
                all_accounts = account_manager.get_all_accounts_summary()
                
                for account_name in all_accounts.keys():
                    # Run risk assessment
                    risk_assessment = await self.run_risk_assessment(account_name)
                    
                    # Log performance metrics
                    db.write_performance_metric(
                        self.name,
                        "risk_score",
                        risk_assessment.overall_risk_score
                    )
                    
                    # If critical alerts, take action
                    if risk_assessment.overall_risk_score > 80:
                        await self._handle_high_risk(account_name, risk_assessment)
                
                # Wait before next assessment
                await asyncio.sleep(config.RUN_EVERY_N_MINUTES * 60)
                
            except Exception as e:
                db.write_alert(self.name, "error", f"Risk manager error: {str(e)}", "high")
                await asyncio.sleep(60)  # Wait 1 minute before retrying
    
    async def _handle_high_risk(self, account_name: str, risk_assessment: RiskAssessment):
        """Handle high-risk situations"""
        account = account_manager.get_account(account_name)
        
        # Generate emergency recommendations
        emergency_actions = []
        
        if risk_assessment.concentration_risk > 0.5:
            emergency_actions.append("Consider immediate diversification")
        
        if abs(risk_assessment.var_95) > 0.08:
            emergency_actions.append("Consider reducing position sizes immediately")
        
        if abs(risk_assessment.max_drawdown) > 0.20:
            emergency_actions.append("Consider stop-loss orders on all positions")
        
        # Log emergency actions
        for action in emergency_actions:
            db.write_alert(
                self.name,
                "emergency_action",
                f"EMERGENCY: {action} for {account_name}",
                "critical"
            )
    
    async def process_market_data(self, market_data: Dict[str, Any]) -> Dict[str, Any]:
        """Process market data for risk assessment"""
        symbol = market_data.get("symbol")
        if not symbol:
            return {"error": "No symbol provided"}
        
        # Get all accounts and assess risk
        all_accounts = account_manager.get_all_accounts_summary()
        risk_assessments = {}
        
        for account_name in all_accounts.keys():
            account = account_manager.get_account(account_name)
            risk_assessment = await self.assess_portfolio_risk(account)
            risk_assessments[account_name] = {
                "risk_score": risk_assessment.overall_risk_score,
                "var_95": risk_assessment.var_95,
                "alerts": risk_assessment.alerts
            }
        
        return {
            "symbol": symbol,
            "risk_assessments": risk_assessments,
            "timestamp": datetime.now().isoformat()
        }
    
    async def make_trading_decision(self, account_name: str) -> Dict[str, Any]:
        """Make risk-based trading decisions"""
        account = account_manager.get_account(account_name)
        risk_assessment = await self.assess_portfolio_risk(account)
        
        # Generate risk-based recommendations
        recommendations = []
        
        if risk_assessment.overall_risk_score > 80:
            recommendations.append("CRITICAL: Reduce portfolio risk immediately")
        elif risk_assessment.overall_risk_score > 60:
            recommendations.append("HIGH: Consider reducing position sizes")
        elif risk_assessment.overall_risk_score < 30:
            recommendations.append("LOW: Portfolio risk is acceptable")
        
        return {
            "agent": self.name,
            "account": account_name,
            "risk_score": risk_assessment.overall_risk_score,
            "recommendations": recommendations,
            "alerts": risk_assessment.alerts,
            "timestamp": datetime.now().isoformat()
        }

# Global risk manager instance
risk_manager = RiskManagerAgent()
