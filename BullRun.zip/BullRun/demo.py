#!/usr/bin/env python3
"""
Enhanced Trading System Demo
"""
import asyncio
import sys
import os
from datetime import datetime
from pathlib import Path

# Add the current directory to Python path
sys.path.append(str(Path(__file__).parent))

async def demo_risk_manager():
    """Demo the Risk Manager agent"""
    print("🔍 Risk Manager Demo")
    print("-" * 40)
    
    try:
        from agents.risk_manager import risk_manager
        from data.enhanced_accounts import account_manager
        
        # Get an account
        account = account_manager.get_account("warren")
        
        # Run risk assessment
        print("Running portfolio risk assessment...")
        risk_assessment = await risk_manager.assess_portfolio_risk(account)
        
        print(f"Overall Risk Score: {risk_assessment.overall_risk_score:.1f}/100")
        print(f"VaR 95%: {risk_assessment.var_95:.2%}")
        print(f"VaR 99%: {risk_assessment.var_99:.2%}")
        print(f"Max Drawdown: {risk_assessment.max_drawdown:.2%}")
        print(f"Sharpe Ratio: {risk_assessment.sharpe_ratio:.2f}")
        
        if risk_assessment.recommendations:
            print("\nRecommendations:")
            for rec in risk_assessment.recommendations:
                print(f"• {rec}")
        
        if risk_assessment.alerts:
            print("\nAlerts:")
            for alert in risk_assessment.alerts:
                print(f"⚠️  {alert}")
        
        print("✅ Risk Manager demo completed\n")
        
    except Exception as e:
        print(f"❌ Risk Manager demo failed: {e}\n")

async def demo_sentiment_analyzer():
    """Demo the Sentiment Analyzer agent"""
    print("📊 Sentiment Analyzer Demo")
    print("-" * 40)
    
    try:
        from agents.sentiment_analyzer import sentiment_analyzer
        
        # Analyze sentiment for a popular stock
        symbol = "AAPL"
        print(f"Analyzing sentiment for {symbol}...")
        
        sentiment_result = await sentiment_analyzer.analyze_sentiment(symbol)
        
        print(f"Overall Sentiment: {sentiment_result.overall_sentiment:.2f}")
        print(f"Trend: {sentiment_result.trend}")
        print(f"Confidence: {sentiment_result.confidence:.2f}")
        print(f"Volume: {sentiment_result.volume} mentions")
        print(f"Momentum: {sentiment_result.momentum:.2f}")
        
        if sentiment_result.sources:
            print("\nSources:")
            for source, data in sentiment_result.sources.items():
                print(f"• {source}: {data.get('sentiment', 0):.2f} (confidence: {data.get('confidence', 0):.2f})")
        
        print("✅ Sentiment Analyzer demo completed\n")
        
    except Exception as e:
        print(f"❌ Sentiment Analyzer demo failed: {e}\n")

async def demo_technical_analyst():
    """Demo the Technical Analyst agent"""
    print("📈 Technical Analyst Demo")
    print("-" * 40)
    
    try:
        from agents.technical_analyst import technical_analyst
        
        # Analyze technical indicators
        symbol = "AAPL"
        print(f"Analyzing technical indicators for {symbol}...")
        
        technical_analysis = await technical_analyst.analyze_technical_indicators(symbol)
        
        if "indicators" in technical_analysis:
            print("Technical Indicators:")
            for indicator, value in technical_analysis["indicators"].items():
                if value is not None:
                    print(f"• {indicator}: {value:.2f}")
        
        if "signals" in technical_analysis:
            print(f"\nGenerated {len(technical_analysis['signals'])} signals:")
            for signal in technical_analysis["signals"][:3]:  # Show first 3
                print(f"• {signal['indicator']}: {signal['signal_type']} (strength: {signal['strength']:.2f})")
        
        # Recognize chart patterns
        print(f"\nRecognizing chart patterns for {symbol}...")
        patterns = await technical_analyst.recognize_chart_patterns(symbol)
        
        if patterns:
            print("Chart Patterns Found:")
            for pattern in patterns:
                print(f"• {pattern.pattern_name}: {pattern.pattern_type} (confidence: {pattern.confidence:.2f})")
        else:
            print("No significant chart patterns detected")
        
        print("✅ Technical Analyst demo completed\n")
        
    except Exception as e:
        print(f"❌ Technical Analyst demo failed: {e}\n")

async def demo_portfolio_optimizer():
    """Demo the Portfolio Optimizer agent"""
    print("🎯 Portfolio Optimizer Demo")
    print("-" * 40)
    
    try:
        from agents.portfolio_optimizer import portfolio_optimizer
        from data.enhanced_accounts import account_manager
        
        # Get an account
        account = account_manager.get_account("warren")
        
        # Run portfolio optimization
        print("Running portfolio optimization...")
        optimization_result = await portfolio_optimizer.optimize_portfolio(account)
        
        if "portfolio_metrics" in optimization_result:
            metrics = optimization_result["portfolio_metrics"]
            print("Portfolio Metrics:")
            print(f"• Expected Return: {metrics['expected_return']:.2%}")
            print(f"• Volatility: {metrics['volatility']:.2%}")
            print(f"• Sharpe Ratio: {metrics['sharpe_ratio']:.2f}")
            print(f"• Max Drawdown: {metrics['max_drawdown']:.2%}")
            print(f"• Diversification Ratio: {metrics['diversification_ratio']:.2f}")
        
        if "recommendations" in optimization_result:
            print(f"\nGenerated {len(optimization_result['recommendations'])} recommendations:")
            for rec in optimization_result["recommendations"][:3]:  # Show first 3
                print(f"• {rec['symbol']}: {rec['recommended_action']} {rec['quantity_change']} shares")
        
        print("✅ Portfolio Optimizer demo completed\n")
        
    except Exception as e:
        print(f"❌ Portfolio Optimizer demo failed: {e}\n")

async def demo_enhanced_trader():
    """Demo the Enhanced Trader agent"""
    print("🤖 Enhanced Trader Demo")
    print("-" * 40)
    
    try:
        from agents.enhanced_trader import EnhancedTrader
        from data.enhanced_accounts import account_manager
        
        # Create a demo trader
        trader = EnhancedTrader(
            name="Demo",
            lastname="Trader",
            strategy="Demo trading strategy for testing",
            risk_tolerance="medium",
            max_position_size=0.1,
            holding_period="medium_term"
        )
        
        # Get account summary
        account = account_manager.get_account("warren")
        summary = account.get_portfolio_summary()
        
        print("Account Summary:")
        print(f"• Portfolio Value: ${summary['portfolio_value']:,.2f}")
        print(f"• Cash Balance: ${summary['cash_balance']:,.2f}")
        print(f"• Total Positions: {summary['total_positions']}")
        print(f"• Unrealized P&L: ${summary['total_unrealized_pnl']:,.2f}")
        
        # Get trading summary
        trading_summary = trader.get_trading_summary()
        print(f"\nTrading Summary:")
        print(f"• Risk Tolerance: {trading_summary['risk_tolerance']}")
        print(f"• Max Position Size: {trading_summary['trading_params']['max_position_size']:.1%}")
        print(f"• Stop Loss: {trading_summary['trading_params']['stop_loss']:.1%}")
        print(f"• Take Profit: {trading_summary['trading_params']['take_profit']:.1%}")
        
        print("✅ Enhanced Trader demo completed\n")
        
    except Exception as e:
        print(f"❌ Enhanced Trader demo failed: {e}\n")

async def demo_database():
    """Demo the enhanced database"""
    print("💾 Enhanced Database Demo")
    print("-" * 40)
    
    try:
        from data.enhanced_database import db
        
        # Test database operations
        print("Testing database operations...")
        
        # Get latest price (simulated)
        price = db.get_latest_price("AAPL")
        print(f"Latest price for AAPL: ${price:.2f}" if price else "No price data available")
        
        # Get unacknowledged alerts
        alerts = db.get_unacknowledged_alerts()
        print(f"Unacknowledged alerts: {len(alerts)}")
        
        # Get performance metrics
        performance = db.get_performance_metrics("warren", days=7)
        print(f"Performance metrics for Warren: {len(performance)} records")
        
        print("✅ Database demo completed\n")
        
    except Exception as e:
        print(f"❌ Database demo failed: {e}\n")

async def main():
    """Main demo function"""
    print("🚀 Enhanced Multi-Agent Trading System Demo")
    print("=" * 60)
    print(f"Demo started at: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("=" * 60 + "\n")
    
    # Run all demos
    await demo_database()
    await demo_risk_manager()
    await demo_sentiment_analyzer()
    await demo_technical_analyst()
    await demo_portfolio_optimizer()
    await demo_enhanced_trader()
    
    print("🎉 Demo completed successfully!")
    print("\nTo start the full system:")
    print("1. Copy env_template.txt to .env and add your API keys")
    print("2. Run: python start_system.py")
    print("3. Open dashboard: streamlit run dashboard/trading_dashboard.py")

if __name__ == "__main__":
    asyncio.run(main())
