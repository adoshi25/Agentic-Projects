#!/usr/bin/env python3
"""
Simple Trading Dashboard - Just the important stuff
"""

import http.server
import socketserver
import json
import random
from datetime import datetime

class SimpleTradingHandler(http.server.SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        self.accounts = {
            'warren': {'name': 'Warren Buffett', 'balance': 100000, 'holdings': {'AAPL': 50, 'KO': 100}, 'pnl': 2500},
            'george': {'name': 'George Soros', 'balance': 95000, 'holdings': {'TSLA': 20, 'NVDA': 30}, 'pnl': -2000},
            'ray': {'name': 'Ray Dalio', 'balance': 102000, 'holdings': {'GLD': 200, 'SPY': 100}, 'pnl': 3000},
            'cathie': {'name': 'Cathie Wood', 'balance': 98000, 'holdings': {'ARKK': 150, 'TSLA': 40}, 'pnl': -1500}
        }
        self.recent_trades = [
            {'time': '06:47:15', 'agent': 'Warren', 'action': 'Bought 10 AAPL at $150.25'},
            {'time': '06:47:18', 'agent': 'George', 'action': 'Sold 5 TSLA at $245.80'},
            {'time': '06:47:22', 'agent': 'Ray', 'action': 'Bought 50 GLD at $185.50'},
            {'time': '06:47:25', 'agent': 'Cathie', 'action': 'Bought 20 ARKK at $45.20'},
        ]
        super().__init__(*args, **kwargs)
    
    def do_GET(self):
        if self.path == '/':
            self.send_response(200)
            self.send_header('Content-type', 'text/html')
            self.end_headers()
            self.wfile.write(self.get_html().encode())
        elif self.path == '/api/update':
            self.simulate_trade()
            self.send_response(200)
            self.send_header('Content-type', 'application/json')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            data = {
                'accounts': self.accounts,
                'recent_trades': self.recent_trades[-5:]
            }
            self.wfile.write(json.dumps(data).encode())
        else:
            super().do_GET()
    
    def simulate_trade(self):
        # Randomly pick an agent and make a trade
        agent_names = list(self.accounts.keys())
        agent = random.choice(agent_names)
        
        symbols = ['AAPL', 'TSLA', 'NVDA', 'KO', 'GLD', 'SPY', 'ARKK']
        symbol = random.choice(symbols)
        action = random.choice(['Bought', 'Sold'])
        quantity = random.randint(5, 50)
        price = random.uniform(50, 500)  # Random price
        
        # Add to recent trades
        self.recent_trades.append({
            'time': datetime.now().strftime('%H:%M:%S'),
            'agent': self.accounts[agent]['name'].split()[0],
            'action': f"{action} {quantity} {symbol} at ${price:.2f}"
        })
        
        # Keep only last 10 trades
        if len(self.recent_trades) > 10:
            self.recent_trades = self.recent_trades[-10:]
        
        # Update account balance (simplified)
        if action == 'Bought':
            self.accounts[agent]['balance'] -= quantity * price
            if symbol in self.accounts[agent]['holdings']:
                self.accounts[agent]['holdings'][symbol] += quantity
            else:
                self.accounts[agent]['holdings'][symbol] = quantity
        else:
            self.accounts[agent]['balance'] += quantity * price
            if symbol in self.accounts[agent]['holdings']:
                self.accounts[agent]['holdings'][symbol] = max(0, self.accounts[agent]['holdings'][symbol] - quantity)
        
        # Update P&L randomly
        for agent_id in self.accounts:
            change = random.uniform(-1000, 1000)
            self.accounts[agent_id]['pnl'] += change
    
    def get_html(self):
        return """
<!DOCTYPE html>
<html>
<head>
    <title>🚀 Trading System</title>
    <style>
        body { 
            font-family: Arial, sans-serif; 
            margin: 0; 
            padding: 20px; 
            background: #f0f2f5;
        }
        .container { 
            max-width: 1000px; 
            margin: 0 auto; 
            background: white; 
            padding: 30px; 
            border-radius: 10px; 
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        h1 { 
            text-align: center; 
            color: #2c3e50; 
            margin-bottom: 30px; 
        }
        .grid { 
            display: grid; 
            grid-template-columns: 2fr 1fr; 
            gap: 30px; 
        }
        .card { 
            background: #f8f9fa; 
            padding: 20px; 
            border-radius: 10px; 
            border-left: 5px solid #3498db;
        }
        .card h2 { 
            margin-top: 0; 
            color: #2c3e50; 
        }
        .account { 
            background: white; 
            padding: 20px; 
            margin: 15px 0; 
            border-radius: 8px; 
            border-left: 4px solid #e74c3c;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }
        .account.warren { border-left-color: #f39c12; }
        .account.george { border-left-color: #e74c3c; }
        .account.ray { border-left-color: #9b59b6; }
        .account.cathie { border-left-color: #1abc9c; }
        .positive { color: #27ae60; font-weight: bold; }
        .negative { color: #e74c3c; font-weight: bold; }
        .trade { 
            background: white; 
            padding: 15px; 
            margin: 10px 0; 
            border-radius: 5px; 
            border-left: 3px solid #3498db;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
        }
        .status { 
            background: #27ae60; 
            color: white; 
            padding: 15px; 
            border-radius: 10px; 
            text-align: center; 
            margin-bottom: 20px; 
            font-weight: bold;
        }
        .btn {
            background: #3498db;
            color: white;
            border: none;
            padding: 12px 24px;
            border-radius: 5px;
            cursor: pointer;
            margin: 10px 5px;
            font-size: 16px;
        }
        .btn:hover { background: #2980b9; }
        .holdings {
            font-size: 14px;
            color: #666;
            margin-top: 10px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Enhanced Multi-Agent Trading System</h1>
        
        <div class="status">
            LIVE TRADING ACTIVE | Last Update: <span id="time"></span>
        </div>
        
        <div style="text-align: center; margin-bottom: 20px;">
            <button class="btn" onclick="makeTrade()">Make Trade</button>
            <button class="btn" onclick="startAutoTrading()">Start Auto-Trading</button>
            <button class="btn" onclick="stopAutoTrading()">Stop Auto-Trading</button>
        </div>
        
        <div class="grid">
            <div class="card">
                <h2>Trading Accounts</h2>
                <div id="accounts"></div>
            </div>
            
            <div class="card">
                <h2>Recent Trades</h2>
                <div id="trades"></div>
            </div>
        </div>
    </div>

    <script>
        let autoTradingInterval;
        
        function updateTime() {
            document.getElementById('time').textContent = new Date().toLocaleTimeString();
        }
        
        function makeTrade() {
            fetch('/api/update')
                .then(response => response.json())
                .then(data => {
                    updateDisplay(data);
                })
                .catch(error => {
                    console.error('Error:', error);
                });
        }
        
        function updateDisplay(data) {
            // Update accounts
            const accountsDiv = document.getElementById('accounts');
            accountsDiv.innerHTML = '';
            
            for (const [id, account] of Object.entries(data.accounts)) {
                const pnlClass = account.pnl >= 0 ? 'positive' : 'negative';
                const holdingsText = Object.keys(account.holdings).length > 0 
                    ? Object.entries(account.holdings).map(([symbol, qty]) => `${qty} ${symbol}`).join(', ')
                    : 'No holdings';
                
                const accountDiv = document.createElement('div');
                accountDiv.className = `account ${id}`;
                accountDiv.innerHTML = `
                    <h3>${account.name}</h3>
                    <p><strong>Balance:</strong> $${account.balance.toLocaleString()}</p>
                    <p><strong>P&L:</strong> <span class="${pnlClass}">$${account.pnl.toLocaleString()}</span></p>
                    <div class="holdings"><strong>Holdings:</strong> ${holdingsText}</div>
                `;
                accountsDiv.appendChild(accountDiv);
            }
            
            // Update trades
            const tradesDiv = document.getElementById('trades');
            tradesDiv.innerHTML = '';
            
            data.recent_trades.reverse().forEach(trade => {
                const tradeDiv = document.createElement('div');
                tradeDiv.className = 'trade';
                tradeDiv.innerHTML = `
                    <strong>${trade.time}</strong> [${trade.agent}]: ${trade.action}
                `;
                tradesDiv.appendChild(tradeDiv);
            });
            
            updateTime();
        }
        
        function startAutoTrading() {
            if (autoTradingInterval) clearInterval(autoTradingInterval);
            autoTradingInterval = setInterval(makeTrade, 5000); // Every 5 seconds
            makeTrade(); // Immediate trade
        }
        
        function stopAutoTrading() {
            if (autoTradingInterval) {
                clearInterval(autoTradingInterval);
                autoTradingInterval = null;
            }
        }
        
        // Initial load
        makeTrade();
    </script>
</body>
</html>
        """

def start_simple_dashboard(port=8503):
    try:
        with socketserver.TCPServer(("", port), SimpleTradingHandler) as httpd:
            print(f"Simple Trading Dashboard")
            print(f"Dashboard available at: http://localhost:{port}")
            print(f"Click 'Make Trade' to see trading activity")
            print(f"Press Ctrl+C to stop")
            print("=" * 50)
            httpd.serve_forever()
    except KeyboardInterrupt:
        print("\nDashboard stopped")
    except OSError as e:
        if "Address already in use" in str(e):
            print(f"Port {port} is already in use. Try a different port.")
        else:
            print(f"Error starting dashboard: {e}")

if __name__ == "__main__":
    start_simple_dashboard()
