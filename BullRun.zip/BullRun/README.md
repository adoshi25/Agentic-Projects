# 🚀 Enhanced Multi-Agent Trading System

A sophisticated multi-agent trading system that combines the original 4-agent architecture with advanced AI agents for risk management, sentiment analysis, technical analysis, and portfolio optimization.

## 🌟 Features

### Core Trading Agents
- **Warren (Patience)**: Value investing with long-term focus
- **George (Bold)**: Growth investing with high-risk, high-reward approach  
- **Ray (Systematic)**: Quantitative systematic trading using algorithms
- **Cathie (Crypto)**: Innovation and disruption investing

### Advanced Support Agents
- **Risk Manager**: Portfolio risk assessment and position sizing
- **Sentiment Analyzer**: Social media and news sentiment analysis
- **Technical Analyst**: Chart patterns and technical indicators
- **Portfolio Optimizer**: Modern portfolio theory and optimization

### Enhanced Features
- 🔄 **Real-time Coordination**: Multi-agent decision making and communication
- 📊 **Advanced Analytics**: Comprehensive performance metrics and risk analysis
- 🎯 **Risk Management**: VaR, correlation analysis, and position sizing
- 📈 **Technical Analysis**: 10+ technical indicators and chart pattern recognition
- 🧠 **Sentiment Analysis**: Twitter, news, and Reddit sentiment tracking
- 🎛️ **Portfolio Optimization**: Mean-variance, Black-Litterman, and risk parity
- 📱 **Real-time Dashboard**: Streamlit-based monitoring interface
- 🚨 **Alert System**: Multi-level alerting with severity classification
- 💾 **Enhanced Database**: SQLite with Redis caching for performance
- 🔧 **Configurable**: Extensive configuration options via environment variables

## 🏗️ Architecture

```
Enhanced Trading System
├── Trading Floor (Coordinator)
│   ├── Original Trading Agents (4)
│   │   ├── Warren (Value)
│   │   ├── George (Growth) 
│   │   ├── Ray (Systematic)
│   │   └── Cathie (Innovation)
│   └── Support Agents (4)
│       ├── Risk Manager
│       ├── Sentiment Analyzer
│       ├── Technical Analyst
│       └── Portfolio Optimizer
├── Data Layer
│   ├── Enhanced Database (SQLite + Redis)
│   ├── Market Data Integration
│   └── Account Management
├── Dashboard
│   └── Real-time Monitoring Interface
└── Configuration
    └── Environment-based Settings
```

## 🚀 Quick Start

### Prerequisites
- Python 3.8+
- Redis (optional, for caching)
- API Keys (OpenAI, Polygon, Twitter, etc.)

### Installation

1. **Clone and Setup**
```bash
cd enhanced_trading_system
pip install -r requirements.txt
```

2. **Environment Configuration**
```bash
cp .env.example .env
# Edit .env with your API keys and configuration
```

3. **Initialize Database**
```bash
python -c "from data.enhanced_database import db; print('Database initialized')"
```

4. **Start the System**
```bash
# Start the trading floor
python enhanced_trading_floor.py

# In another terminal, start the dashboard
streamlit run dashboard/trading_dashboard.py
```

## ⚙️ Configuration

### Environment Variables

```bash
# API Keys
OPENAI_API_KEY=your_openai_key
POLYGON_API_KEY=your_polygon_key
TWITTER_API_KEY=your_twitter_key
TWITTER_API_SECRET=your_twitter_secret
TWITTER_ACCESS_TOKEN=your_access_token
TWITTER_ACCESS_SECRET=your_access_secret

# Trading Parameters
INITIAL_BALANCE=100000.0
MAX_POSITION_SIZE=0.1
STOP_LOSS_PERCENTAGE=0.05
TAKE_PROFIT_PERCENTAGE=0.15
MAX_PORTFOLIO_RISK=0.02

# System Configuration
RUN_EVERY_N_MINUTES=15
USE_MANY_MODELS=true
PRIMARY_MODEL=gpt-4o
DASHBOARD_PORT=8501

# Risk Management
VAR_CONFIDENCE_LEVEL=0.95
MAX_CORRELATION=0.7

# Database
DATABASE_URL=sqlite:///enhanced_trading.db
REDIS_URL=redis://localhost:6379
```

### Agent Configuration

Each agent can be configured in `config/settings.py`:

```python
AGENT_CONFIGS = {
    "warren": {
        "name": "Warren",
        "strategy": "Value investing with long-term focus...",
        "risk_tolerance": "low",
        "max_position_size": 0.15,
        "holding_period": "long_term"
    },
    # ... other agents
}
```

## 📊 Dashboard Features

The real-time dashboard provides:

- **System Overview**: Total portfolio value, active agents, system status
- **Portfolio Performance**: Charts and metrics for all accounts
- **Agent Status**: Performance tracking for each agent
- **Alert System**: Real-time alerts with severity levels
- **Account Details**: Individual account analysis and positions
- **Risk Analysis**: Risk metrics and violation tracking

Access the dashboard at: `http://localhost:8501`

## 🤖 Agent Capabilities

### Risk Manager
- Portfolio risk assessment using VaR and stress testing
- Position sizing recommendations
- Correlation and concentration risk analysis
- Real-time risk monitoring and alerts

### Sentiment Analyzer
- Twitter sentiment analysis using VADER and TextBlob
- News sentiment from multiple sources
- Reddit sentiment tracking
- Sentiment momentum and anomaly detection

### Technical Analyst
- 10+ technical indicators (RSI, MACD, Bollinger Bands, etc.)
- Chart pattern recognition (Head & Shoulders, Double Top/Bottom, etc.)
- Signal generation with confidence scoring
- Multi-timeframe analysis

### Portfolio Optimizer
- Mean-variance optimization (Markowitz)
- Black-Litterman model implementation
- Risk parity optimization
- Maximum Sharpe ratio optimization

## 🔧 Advanced Features

### Multi-Agent Coordination
- Real-time communication between agents
- Consensus-based decision making
- Risk-aware position sizing
- Emergency stop mechanisms

### Performance Analytics
- Sharpe ratio, Sortino ratio, Calmar ratio
- Maximum drawdown analysis
- Win rate and profit factor
- Risk-adjusted returns

### Alert System
- Multi-level severity (Critical, High, Medium, Low)
- Real-time notifications
- Alert acknowledgment system
- Historical alert tracking

### Database Features
- SQLite for persistent storage
- Redis caching for performance
- Historical data retention
- Performance metrics tracking

## 📈 Usage Examples

### Starting the System
```python
from enhanced_trading_floor import trading_floor
import asyncio

async def main():
    await trading_floor.start()

asyncio.run(main())
```

### Accessing Account Data
```python
from data.enhanced_accounts import account_manager

# Get account summary
account = account_manager.get_account("warren")
summary = account.get_portfolio_summary()
print(summary)
```

### Running Risk Assessment
```python
from agents.risk_manager import risk_manager

# Assess portfolio risk
risk_assessment = await risk_manager.assess_portfolio_risk(account)
print(f"Risk Score: {risk_assessment.overall_risk_score}")
```

### Analyzing Sentiment
```python
from agents.sentiment_analyzer import sentiment_analyzer

# Analyze sentiment for a symbol
sentiment = await sentiment_analyzer.analyze_sentiment("AAPL")
print(f"Sentiment: {sentiment.overall_sentiment}")
```

## 🛡️ Risk Management

The system includes comprehensive risk management:

- **Position Limits**: Maximum position size per asset
- **Portfolio Risk**: Overall portfolio risk limits
- **Stop Losses**: Automatic stop-loss orders
- **Correlation Limits**: Maximum correlation between positions
- **VaR Monitoring**: Value at Risk calculations
- **Emergency Stops**: System-wide emergency stop mechanisms

## 📝 Logging and Monitoring

- **Structured Logging**: All activities logged to database
- **Performance Tracking**: Agent and system performance metrics
- **Alert History**: Complete audit trail of all alerts
- **Trade History**: Detailed transaction logging
- **System Health**: Continuous monitoring of agent health

## 🔮 Future Enhancements

- **Machine Learning**: Price prediction models
- **Backtesting**: Strategy validation framework
- **Options Trading**: Options strategy implementation
- **Crypto Support**: Cryptocurrency trading capabilities
- **Advanced Analytics**: More sophisticated risk models
- **API Integration**: REST API for external access

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests if applicable
5. Submit a pull request

## 📄 License

This project is licensed under the MIT License - see the LICENSE file for details.

## ⚠️ Disclaimer

This is an educational and research project. Trading involves substantial risk of loss and is not suitable for all investors. Past performance is not indicative of future results. Use at your own risk.

## 📞 Support

For questions or support, please open an issue on GitHub or contact the development team.

---

**Happy Trading! 🚀📈**
