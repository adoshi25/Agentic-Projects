"""
Real-time Trading Dashboard for Enhanced Multi-Agent Trading System
"""
import streamlit as st
import pandas as pd
import plotly.graph_objects as go
import plotly.express as px
from plotly.subplots import make_subplots
import asyncio
import json
from datetime import datetime, timedelta
from typing import Dict, List, Any
import sys
import os

# Add the parent directory to the path to import our modules
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from config.settings import config, AGENT_CONFIGS
from data.enhanced_database import db
from data.enhanced_accounts import account_manager
from enhanced_trading_floor import trading_floor

# Page configuration
st.set_page_config(
    page_title="Enhanced Trading System Dashboard",
    page_icon="📈",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS
st.markdown("""
<style>
    .main-header {
        font-size: 2.5rem;
        font-weight: bold;
        color: #1f77b4;
        text-align: center;
        margin-bottom: 2rem;
    }
    .metric-card {
        background-color: #f0f2f6;
        padding: 1rem;
        border-radius: 0.5rem;
        border-left: 4px solid #1f77b4;
    }
    .alert-critical {
        background-color: #ffebee;
        border-left: 4px solid #f44336;
        padding: 0.5rem;
        border-radius: 0.25rem;
        margin: 0.5rem 0;
    }
    .alert-high {
        background-color: #fff3e0;
        border-left: 4px solid #ff9800;
        padding: 0.5rem;
        border-radius: 0.25rem;
        margin: 0.5rem 0;
    }
    .alert-medium {
        background-color: #e8f5e8;
        border-left: 4px solid #4caf50;
        padding: 0.5rem;
        border-radius: 0.25rem;
        margin: 0.5rem 0;
    }
</style>
""", unsafe_allow_html=True)

@st.cache_data(ttl=30)  # Cache for 30 seconds
def get_system_data():
    """Get system data with caching"""
    try:
        # Get system status
        system_status = trading_floor.get_system_status()
        
        # Get all accounts
        all_accounts = account_manager.get_all_accounts_summary()
        
        # Get agent performance
        agent_performance = trading_floor.get_agent_performance()
        
        # Get recent alerts
        recent_alerts = db.get_unacknowledged_alerts()
        
        return {
            "system_status": system_status,
            "accounts": all_accounts,
            "agent_performance": agent_performance,
            "recent_alerts": recent_alerts
        }
    except Exception as e:
        st.error(f"Error fetching system data: {e}")
        return None

def display_header():
    """Display dashboard header"""
    st.markdown('<h1 class="main-header">🚀 Enhanced Multi-Agent Trading System</h1>', unsafe_allow_html=True)
    
    # System status indicator
    data = get_system_data()
    if data:
        system_status = data["system_status"]
        if system_status["is_running"]:
            st.success("🟢 System Running")
        else:
            st.error("🔴 System Stopped")
        
        # Uptime
        if system_status["uptime"]:
            st.info(f"⏱️ Uptime: {system_status['uptime']}")

def display_system_overview():
    """Display system overview metrics"""
    st.header("📊 System Overview")
    
    data = get_system_data()
    if not data:
        return
    
    system_status = data["system_status"]
    accounts = data["accounts"]
    
    # Calculate total metrics
    total_portfolio_value = sum(account["portfolio_value"] for account in accounts.values())
    total_unrealized_pnl = sum(account["total_unrealized_pnl"] for account in accounts.values())
    total_positions = sum(account["total_positions"] for account in accounts.values())
    
    # Create metrics columns
    col1, col2, col3, col4, col5 = st.columns(5)
    
    with col1:
        st.metric(
            label="Total Portfolio Value",
            value=f"${total_portfolio_value:,.2f}",
            delta=f"${total_unrealized_pnl:,.2f}"
        )
    
    with col2:
        st.metric(
            label="Total Positions",
            value=total_positions,
            delta=None
        )
    
    with col3:
        st.metric(
            label="Active Agents",
            value=system_status["agents"]["active"],
            delta=f"/ {system_status['agents']['total']}"
        )
    
    with col4:
        st.metric(
            label="Trading Accounts",
            value=system_status["accounts"],
            delta=None
        )
    
    with col5:
        pnl_percent = (total_unrealized_pnl / total_portfolio_value * 100) if total_portfolio_value > 0 else 0
        st.metric(
            label="Total P&L %",
            value=f"{pnl_percent:.2f}%",
            delta=None
        )

def display_portfolio_performance():
    """Display portfolio performance charts"""
    st.header("📈 Portfolio Performance")
    
    data = get_system_data()
    if not data:
        return
    
    accounts = data["accounts"]
    
    # Create portfolio value chart
    fig = make_subplots(
        rows=2, cols=2,
        subplot_titles=("Portfolio Values", "Unrealized P&L", "Position Count", "Risk Scores"),
        specs=[[{"secondary_y": False}, {"secondary_y": False}],
               [{"secondary_y": False}, {"secondary_y": False}]]
    )
    
    # Portfolio values
    account_names = list(accounts.keys())
    portfolio_values = [accounts[name]["portfolio_value"] for name in account_names]
    unrealized_pnl = [accounts[name]["total_unrealized_pnl"] for name in account_names]
    position_counts = [accounts[name]["total_positions"] for name in account_names]
    
    fig.add_trace(
        go.Bar(x=account_names, y=portfolio_values, name="Portfolio Value", marker_color="blue"),
        row=1, col=1
    )
    
    fig.add_trace(
        go.Bar(x=account_names, y=unrealized_pnl, name="Unrealized P&L", marker_color="green"),
        row=1, col=2
    )
    
    fig.add_trace(
        go.Bar(x=account_names, y=position_counts, name="Position Count", marker_color="orange"),
        row=2, col=1
    )
    
    # Risk scores (simplified)
    risk_scores = [50] * len(account_names)  # Placeholder
    fig.add_trace(
        go.Bar(x=account_names, y=risk_scores, name="Risk Score", marker_color="red"),
        row=2, col=2
    )
    
    fig.update_layout(height=600, showlegend=False, title_text="Portfolio Performance Overview")
    st.plotly_chart(fig, use_container_width=True)

def display_agent_status():
    """Display agent status and performance"""
    st.header("🤖 Agent Status")
    
    data = get_system_data()
    if not data:
        return
    
    agent_performance = data["agent_performance"]
    
    # Create agent status table
    agent_data = []
    for agent_name, performance in agent_performance.items():
        if isinstance(performance, dict) and "error" not in performance:
            # Get basic metrics
            trades_executed = performance.get("trades_executed", {}).get("current", 0)
            decision_confidence = performance.get("decision_confidence", {}).get("current", 0)
            
            agent_data.append({
                "Agent": agent_name,
                "Trades Executed": trades_executed,
                "Avg Confidence": f"{decision_confidence:.2f}",
                "Status": "🟢 Active" if trades_executed > 0 else "🟡 Idle"
            })
        else:
            agent_data.append({
                "Agent": agent_name,
                "Trades Executed": "N/A",
                "Avg Confidence": "N/A",
                "Status": "🔴 Error"
            })
    
    if agent_data:
        df = pd.DataFrame(agent_data)
        st.dataframe(df, use_container_width=True)
    
    # Agent performance charts
    if agent_performance:
        st.subheader("Agent Performance Trends")
        
        # Create performance chart
        fig = go.Figure()
        
        for agent_name, performance in agent_performance.items():
            if isinstance(performance, dict) and "trades_executed" in performance:
                trades_data = performance["trades_executed"]
                if isinstance(trades_data, dict) and "current" in trades_data:
                    fig.add_trace(go.Bar(
                        name=agent_name,
                        x=[agent_name],
                        y=[trades_data["current"]]
                    ))
        
        fig.update_layout(title="Trades Executed by Agent", barmode="group")
        st.plotly_chart(fig, use_container_width=True)

def display_alerts():
    """Display system alerts"""
    st.header("🚨 System Alerts")
    
    data = get_system_data()
    if not data:
        return
    
    alerts = data["recent_alerts"]
    
    if not alerts:
        st.success("✅ No active alerts")
        return
    
    # Group alerts by severity
    critical_alerts = [a for a in alerts if a["severity"] == "critical"]
    high_alerts = [a for a in alerts if a["severity"] == "high"]
    medium_alerts = [a for a in alerts if a["severity"] == "medium"]
    low_alerts = [a for a in alerts if a["severity"] == "low"]
    
    # Display critical alerts
    if critical_alerts:
        st.subheader("🔴 Critical Alerts")
        for alert in critical_alerts:
            st.markdown(f"""
            <div class="alert-critical">
                <strong>{alert['agent_name']}</strong> - {alert['message']}<br>
                <small>Time: {alert['timestamp']}</small>
            </div>
            """, unsafe_allow_html=True)
    
    # Display high alerts
    if high_alerts:
        st.subheader("🟠 High Priority Alerts")
        for alert in high_alerts:
            st.markdown(f"""
            <div class="alert-high">
                <strong>{alert['agent_name']}</strong> - {alert['message']}<br>
                <small>Time: {alert['timestamp']}</small>
            </div>
            """, unsafe_allow_html=True)
    
    # Display medium alerts
    if medium_alerts:
        st.subheader("🟡 Medium Priority Alerts")
        for alert in medium_alerts:
            st.markdown(f"""
            <div class="alert-medium">
                <strong>{alert['agent_name']}</strong> - {alert['message']}<br>
                <small>Time: {alert['timestamp']}</small>
            </div>
            """, unsafe_allow_html=True)
    
    # Display low alerts
    if low_alerts:
        with st.expander("🟢 Low Priority Alerts"):
            for alert in low_alerts:
                st.text(f"{alert['agent_name']}: {alert['message']} ({alert['timestamp']})")

def display_account_details():
    """Display detailed account information"""
    st.header("💼 Account Details")
    
    data = get_system_data()
    if not data:
        return
    
    accounts = data["accounts"]
    
    # Account selector
    selected_account = st.selectbox("Select Account", list(accounts.keys()))
    
    if selected_account:
        account_data = accounts[selected_account]
        
        # Account overview
        col1, col2, col3 = st.columns(3)
        
        with col1:
            st.metric("Portfolio Value", f"${account_data['portfolio_value']:,.2f}")
        
        with col2:
            st.metric("Unrealized P&L", f"${account_data['total_unrealized_pnl']:,.2f}")
        
        with col3:
            st.metric("Total Positions", account_data["total_positions"])
        
        # Positions table
        st.subheader("Current Positions")
        positions = account_data.get("positions", {})
        
        if positions:
            position_data = []
            for symbol, position in positions.items():
                position_data.append({
                    "Symbol": symbol,
                    "Quantity": position["quantity"],
                    "Avg Cost": f"${position['avg_cost']:.2f}",
                    "Current Price": f"${position['current_price']:.2f}",
                    "Unrealized P&L": f"${position['unrealized_pnl']:.2f}",
                    "P&L %": f"{position['unrealized_pnl_percent']:.2f}%",
                    "Position Size %": f"{position['position_size_percent']:.2f}%"
                })
            
            df = pd.DataFrame(position_data)
            st.dataframe(df, use_container_width=True)
        else:
            st.info("No positions found")
        
        # Performance metrics
        st.subheader("Performance Metrics")
        performance_metrics = account_data.get("performance_metrics", {})
        
        if performance_metrics:
            col1, col2, col3, col4 = st.columns(4)
            
            with col1:
                st.metric("Total Return", f"{performance_metrics.get('total_return', 0):.2%}")
            
            with col2:
                st.metric("Sharpe Ratio", f"{performance_metrics.get('sharpe_ratio', 0):.2f}")
            
            with col3:
                st.metric("Max Drawdown", f"{performance_metrics.get('max_drawdown', 0):.2%}")
            
            with col4:
                st.metric("Win Rate", f"{performance_metrics.get('win_rate', 0):.2%}")

def display_risk_metrics():
    """Display risk metrics and analysis"""
    st.header("⚠️ Risk Analysis")
    
    data = get_system_data()
    if not data:
        return
    
    accounts = data["accounts"]
    
    # Risk overview
    risk_data = []
    for account_name, account_data in accounts.items():
        risk_violations = account_data.get("risk_violations", [])
        risk_data.append({
            "Account": account_name,
            "Risk Violations": len(risk_violations),
            "Portfolio Value": account_data["portfolio_value"],
            "Unrealized P&L": account_data["total_unrealized_pnl"]
        })
    
    if risk_data:
        df = pd.DataFrame(risk_data)
        st.dataframe(df, use_container_width=True)
        
        # Risk violations
        st.subheader("Risk Violations")
        for account_name, account_data in accounts.items():
            risk_violations = account_data.get("risk_violations", [])
            if risk_violations:
                st.warning(f"**{account_name}**: {len(risk_violations)} risk violations")
                for violation in risk_violations:
                    st.text(f"• {violation}")
            else:
                st.success(f"**{account_name}**: No risk violations")

def main():
    """Main dashboard function"""
    # Sidebar
    st.sidebar.title("🎛️ Dashboard Controls")
    
    # Auto-refresh toggle
    auto_refresh = st.sidebar.checkbox("Auto-refresh (30s)", value=True)
    
    if auto_refresh:
        # Auto-refresh every 30 seconds
        st.rerun()
    
    # Manual refresh button
    if st.sidebar.button("🔄 Refresh Now"):
        st.rerun()
    
    # System controls
    st.sidebar.subheader("System Controls")
    
    if st.sidebar.button("🟢 Start System"):
        st.info("System start functionality would be implemented here")
    
    if st.sidebar.button("🛑 Stop System"):
        st.warning("System stop functionality would be implemented here")
    
    # Main content
    display_header()
    display_system_overview()
    
    # Tabs for different views
    tab1, tab2, tab3, tab4, tab5 = st.tabs([
        "📈 Performance", "🤖 Agents", "🚨 Alerts", "💼 Accounts", "⚠️ Risk"
    ])
    
    with tab1:
        display_portfolio_performance()
    
    with tab2:
        display_agent_status()
    
    with tab3:
        display_alerts()
    
    with tab4:
        display_account_details()
    
    with tab5:
        display_risk_metrics()
    
    # Footer
    st.markdown("---")
    st.markdown(
        f"<div style='text-align: center; color: #666;'>"
        f"Enhanced Multi-Agent Trading System Dashboard | "
        f"Last updated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
        f"</div>",
        unsafe_allow_html=True
    )

if __name__ == "__main__":
    main()
