"""
Advanced Monitoring and Analytics
Comprehensive monitoring, logging, and analytics for the advanced agent system.
"""

import asyncio
import json
import logging
import time
from typing import Dict, List, Optional, Any, Union
from datetime import datetime, timedelta
from dataclasses import dataclass, asdict
from enum import Enum
import sqlite3
import threading
from collections import defaultdict, deque
import os
# psutil is optional for advanced monitoring
try:
    import psutil
except ImportError:
    psutil = None

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class MetricType(Enum):
    """Types of metrics to track"""
    COUNTER = "counter"
    GAUGE = "gauge"
    HISTOGRAM = "histogram"
    TIMER = "timer"

@dataclass
class Metric:
    """Represents a single metric"""
    name: str
    value: Union[int, float]
    metric_type: MetricType
    timestamp: datetime
    tags: Dict[str, str] = None
    metadata: Dict[str, Any] = None
    
    def __post_init__(self):
        if self.tags is None:
            self.tags = {}
        if self.metadata is None:
            self.metadata = {}

@dataclass
class PerformanceSnapshot:
    """System performance snapshot"""
    timestamp: datetime
    cpu_percent: float
    memory_percent: float
    memory_used_mb: float
    disk_usage_percent: float
    active_connections: int
    agent_count: int
    workflow_count: int

class MetricsCollector:
    """Collects and stores metrics"""
    
    def __init__(self, max_metrics: int = 10000):
        self.max_metrics = max_metrics
        self.metrics: deque = deque(maxlen=max_metrics)
        self.counters: Dict[str, float] = defaultdict(float)
        self.gauges: Dict[str, float] = {}
        self.histograms: Dict[str, List[float]] = defaultdict(list)
        self.timers: Dict[str, List[float]] = defaultdict(list)
        self.lock = threading.Lock()
        
        # Initialize database
        self._init_database()
    
    def _init_database(self):
        """Initialize metrics database"""
        try:
            conn = sqlite3.connect("metrics.db")
            cursor = conn.cursor()
            
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS metrics (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    name TEXT NOT NULL,
                    value REAL NOT NULL,
                    metric_type TEXT NOT NULL,
                    timestamp DATETIME NOT NULL,
                    tags TEXT,
                    metadata TEXT
                )
            """)
            
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS performance_snapshots (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp DATETIME NOT NULL,
                    cpu_percent REAL NOT NULL,
                    memory_percent REAL NOT NULL,
                    memory_used_mb REAL NOT NULL,
                    disk_usage_percent REAL NOT NULL,
                    active_connections INTEGER NOT NULL,
                    agent_count INTEGER NOT NULL,
                    workflow_count INTEGER NOT NULL
                )
            """)
            
            conn.commit()
            conn.close()
            
        except Exception as e:
            logger.error(f"Error initializing metrics database: {str(e)}")
    
    def record_metric(
        self,
        name: str,
        value: Union[int, float],
        metric_type: MetricType,
        tags: Dict[str, str] = None,
        metadata: Dict[str, Any] = None
    ):
        """Record a metric"""
        with self.lock:
            metric = Metric(
                name=name,
                value=value,
                metric_type=metric_type,
                timestamp=datetime.now(),
                tags=tags or {},
                metadata=metadata or {}
            )
            
            self.metrics.append(metric)
            
            # Update internal counters
            if metric_type == MetricType.COUNTER:
                self.counters[name] += value
            elif metric_type == MetricType.GAUGE:
                self.gauges[name] = value
            elif metric_type == MetricType.HISTOGRAM:
                self.histograms[name].append(value)
            elif metric_type == MetricType.TIMER:
                self.timers[name].append(value)
    
    def increment_counter(self, name: str, value: float = 1.0, tags: Dict[str, str] = None):
        """Increment a counter metric"""
        self.record_metric(name, value, MetricType.COUNTER, tags)
    
    def set_gauge(self, name: str, value: float, tags: Dict[str, str] = None):
        """Set a gauge metric"""
        self.record_metric(name, value, MetricType.GAUGE, tags)
    
    def record_histogram(self, name: str, value: float, tags: Dict[str, str] = None):
        """Record a histogram value"""
        self.record_metric(name, value, MetricType.HISTOGRAM, tags)
    
    def record_timer(self, name: str, duration: float, tags: Dict[str, str] = None):
        """Record a timer duration"""
        self.record_metric(name, duration, MetricType.TIMER, tags)
    
    def get_metrics_summary(self, time_window_minutes: int = 60) -> Dict[str, Any]:
        """Get metrics summary for a time window"""
        cutoff_time = datetime.now() - timedelta(minutes=time_window_minutes)
        
        with self.lock:
            recent_metrics = [m for m in self.metrics if m.timestamp >= cutoff_time]
            
            summary = {
                "time_window_minutes": time_window_minutes,
                "total_metrics": len(recent_metrics),
                "counters": dict(self.counters),
                "gauges": dict(self.gauges),
                "histograms": {
                    name: {
                        "count": len(values),
                        "min": min(values) if values else 0,
                        "max": max(values) if values else 0,
                        "avg": sum(values) / len(values) if values else 0
                    }
                    for name, values in self.histograms.items()
                },
                "timers": {
                    name: {
                        "count": len(values),
                        "min": min(values) if values else 0,
                        "max": max(values) if values else 0,
                        "avg": sum(values) / len(values) if values else 0
                    }
                    for name, values in self.timers.items()
                }
            }
            
            return summary
    
    def save_metrics_to_db(self):
        """Save metrics to database"""
        try:
            conn = sqlite3.connect("metrics.db")
            cursor = conn.cursor()
            
            with self.lock:
                metrics_to_save = list(self.metrics)
            
            for metric in metrics_to_save:
                cursor.execute("""
                    INSERT INTO metrics (name, value, metric_type, timestamp, tags, metadata)
                    VALUES (?, ?, ?, ?, ?, ?)
                """, (
                    metric.name,
                    metric.value,
                    metric.metric_type.value,
                    metric.timestamp,
                    json.dumps(metric.tags),
                    json.dumps(metric.metadata)
                ))
            
            conn.commit()
            conn.close()
            
        except Exception as e:
            logger.error(f"Error saving metrics to database: {str(e)}")

class PerformanceMonitor:
    """Monitors system performance"""
    
    def __init__(self, metrics_collector: MetricsCollector):
        self.metrics_collector = metrics_collector
        self.monitoring = False
        self.monitor_thread = None
    
    def start_monitoring(self, interval_seconds: int = 30):
        """Start performance monitoring"""
        if self.monitoring:
            return
        
        self.monitoring = True
        self.monitor_thread = threading.Thread(
            target=self._monitor_loop,
            args=(interval_seconds,),
            daemon=True
        )
        self.monitor_thread.start()
        logger.info("Performance monitoring started")
    
    def stop_monitoring(self):
        """Stop performance monitoring"""
        self.monitoring = False
        if self.monitor_thread:
            self.monitor_thread.join()
        logger.info("Performance monitoring stopped")
    
    def _monitor_loop(self, interval_seconds: int):
        """Main monitoring loop"""
        while self.monitoring:
            try:
                snapshot = self._take_performance_snapshot()
                self._record_performance_metrics(snapshot)
                self._save_snapshot_to_db(snapshot)
                
                time.sleep(interval_seconds)
                
            except Exception as e:
                logger.error(f"Error in monitoring loop: {str(e)}")
                time.sleep(interval_seconds)
    
    def _take_performance_snapshot(self) -> PerformanceSnapshot:
        """Take a performance snapshot"""
        if psutil is None:
            # Return default values if psutil is not available
            return PerformanceSnapshot(
                timestamp=datetime.now(),
                cpu_percent=0.0,
                memory_percent=0.0,
                memory_used_mb=0.0,
                disk_usage_percent=0.0,
                active_connections=0,
                agent_count=0,
                workflow_count=0
            )
        
        return PerformanceSnapshot(
            timestamp=datetime.now(),
            cpu_percent=psutil.cpu_percent(),
            memory_percent=psutil.virtual_memory().percent,
            memory_used_mb=psutil.virtual_memory().used / (1024 * 1024),
            disk_usage_percent=psutil.disk_usage('/').percent,
            active_connections=len(psutil.net_connections()),
            agent_count=0,  # Will be updated by agent system
            workflow_count=0  # Will be updated by workflow system
        )
    
    def _record_performance_metrics(self, snapshot: PerformanceSnapshot):
        """Record performance metrics"""
        self.metrics_collector.set_gauge("system.cpu_percent", snapshot.cpu_percent)
        self.metrics_collector.set_gauge("system.memory_percent", snapshot.memory_percent)
        self.metrics_collector.set_gauge("system.memory_used_mb", snapshot.memory_used_mb)
        self.metrics_collector.set_gauge("system.disk_usage_percent", snapshot.disk_usage_percent)
        self.metrics_collector.set_gauge("system.active_connections", snapshot.active_connections)
        self.metrics_collector.set_gauge("system.agent_count", snapshot.agent_count)
        self.metrics_collector.set_gauge("system.workflow_count", snapshot.workflow_count)
    
    def _save_snapshot_to_db(self, snapshot: PerformanceSnapshot):
        """Save performance snapshot to database"""
        try:
            conn = sqlite3.connect("metrics.db")
            cursor = conn.cursor()
            
            cursor.execute("""
                INSERT INTO performance_snapshots 
                (timestamp, cpu_percent, memory_percent, memory_used_mb, 
                 disk_usage_percent, active_connections, agent_count, workflow_count)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                snapshot.timestamp,
                snapshot.cpu_percent,
                snapshot.memory_percent,
                snapshot.memory_used_mb,
                snapshot.disk_usage_percent,
                snapshot.active_connections,
                snapshot.agent_count,
                snapshot.workflow_count
            ))
            
            conn.commit()
            conn.close()
            
        except Exception as e:
            logger.error(f"Error saving performance snapshot: {str(e)}")

class AgentMonitor:
    """Monitors agent performance and behavior"""
    
    def __init__(self, metrics_collector: MetricsCollector):
        self.metrics_collector = metrics_collector
        self.agent_stats: Dict[str, Dict[str, Any]] = defaultdict(lambda: {
            "tasks_completed": 0,
            "tasks_failed": 0,
            "total_execution_time": 0.0,
            "last_activity": None,
            "error_count": 0
        })
    
    def record_agent_task_start(self, agent_name: str, task_id: str):
        """Record when an agent starts a task"""
        self.metrics_collector.increment_counter("agent.task_started", tags={"agent": agent_name})
        self.agent_stats[agent_name]["last_activity"] = datetime.now()
    
    def record_agent_task_completion(
        self,
        agent_name: str,
        task_id: str,
        success: bool,
        execution_time: float,
        error: str = None
    ):
        """Record when an agent completes a task"""
        if success:
            self.metrics_collector.increment_counter("agent.task_completed", tags={"agent": agent_name})
            self.agent_stats[agent_name]["tasks_completed"] += 1
        else:
            self.metrics_collector.increment_counter("agent.task_failed", tags={"agent": agent_name})
            self.agent_stats[agent_name]["tasks_failed"] += 1
            self.agent_stats[agent_name]["error_count"] += 1
        
        self.metrics_collector.record_timer(
            "agent.task_duration",
            execution_time,
            tags={"agent": agent_name, "success": str(success)}
        )
        
        self.agent_stats[agent_name]["total_execution_time"] += execution_time
        self.agent_stats[agent_name]["last_activity"] = datetime.now()
    
    def get_agent_performance_summary(self, agent_name: str = None) -> Dict[str, Any]:
        """Get performance summary for agents"""
        if agent_name:
            if agent_name not in self.agent_stats:
                return {"error": f"Agent {agent_name} not found"}
            
            stats = self.agent_stats[agent_name]
            total_tasks = stats["tasks_completed"] + stats["tasks_failed"]
            
            return {
                "agent_name": agent_name,
                "total_tasks": total_tasks,
                "tasks_completed": stats["tasks_completed"],
                "tasks_failed": stats["tasks_failed"],
                "success_rate": stats["tasks_completed"] / total_tasks if total_tasks > 0 else 0,
                "average_execution_time": stats["total_execution_time"] / total_tasks if total_tasks > 0 else 0,
                "error_count": stats["error_count"],
                "last_activity": stats["last_activity"]
            }
        else:
            return {
                agent_name: self.get_agent_performance_summary(agent_name)
                for agent_name in self.agent_stats.keys()
            }

class WorkflowMonitor:
    """Monitors workflow execution"""
    
    def __init__(self, metrics_collector: MetricsCollector):
        self.metrics_collector = metrics_collector
        self.workflow_stats: Dict[str, Dict[str, Any]] = defaultdict(lambda: {
            "executions": 0,
            "successful_executions": 0,
            "failed_executions": 0,
            "total_execution_time": 0.0,
            "average_task_count": 0.0,
            "last_execution": None
        })
    
    def record_workflow_start(self, workflow_id: str, workflow_name: str, task_count: int):
        """Record when a workflow starts"""
        self.metrics_collector.increment_counter(
            "workflow.started",
            tags={"workflow_id": workflow_id, "workflow_name": workflow_name}
        )
        
        self.workflow_stats[workflow_id]["executions"] += 1
        self.workflow_stats[workflow_id]["last_execution"] = datetime.now()
        
        # Update average task count
        current_avg = self.workflow_stats[workflow_id]["average_task_count"]
        execution_count = self.workflow_stats[workflow_id]["executions"]
        new_avg = ((current_avg * (execution_count - 1)) + task_count) / execution_count
        self.workflow_stats[workflow_id]["average_task_count"] = new_avg
    
    def record_workflow_completion(
        self,
        workflow_id: str,
        workflow_name: str,
        success: bool,
        execution_time: float,
        completed_tasks: int,
        failed_tasks: int
    ):
        """Record when a workflow completes"""
        if success:
            self.metrics_collector.increment_counter(
                "workflow.completed",
                tags={"workflow_id": workflow_id, "workflow_name": workflow_name}
            )
            self.workflow_stats[workflow_id]["successful_executions"] += 1
        else:
            self.metrics_collector.increment_counter(
                "workflow.failed",
                tags={"workflow_id": workflow_id, "workflow_name": workflow_name}
            )
            self.workflow_stats[workflow_id]["failed_executions"] += 1
        
        self.metrics_collector.record_timer(
            "workflow.duration",
            execution_time,
            tags={"workflow_id": workflow_id, "success": str(success)}
        )
        
        self.metrics_collector.set_gauge(
            "workflow.completed_tasks",
            completed_tasks,
            tags={"workflow_id": workflow_id}
        )
        
        self.metrics_collector.set_gauge(
            "workflow.failed_tasks",
            failed_tasks,
            tags={"workflow_id": workflow_id}
        )
        
        self.workflow_stats[workflow_id]["total_execution_time"] += execution_time
    
    def get_workflow_performance_summary(self, workflow_id: str = None) -> Dict[str, Any]:
        """Get performance summary for workflows"""
        if workflow_id:
            if workflow_id not in self.workflow_stats:
                return {"error": f"Workflow {workflow_id} not found"}
            
            stats = self.workflow_stats[workflow_id]
            total_executions = stats["successful_executions"] + stats["failed_executions"]
            
            return {
                "workflow_id": workflow_id,
                "total_executions": total_executions,
                "successful_executions": stats["successful_executions"],
                "failed_executions": stats["failed_executions"],
                "success_rate": stats["successful_executions"] / total_executions if total_executions > 0 else 0,
                "average_execution_time": stats["total_execution_time"] / total_executions if total_executions > 0 else 0,
                "average_task_count": stats["average_task_count"],
                "last_execution": stats["last_execution"]
            }
        else:
            return {
                workflow_id: self.get_workflow_performance_summary(workflow_id)
                for workflow_id in self.workflow_stats.keys()
            }

class MonitoringDashboard:
    """Provides monitoring dashboard functionality"""
    
    def __init__(self):
        self.metrics_collector = MetricsCollector()
        self.performance_monitor = PerformanceMonitor(self.metrics_collector)
        self.agent_monitor = AgentMonitor(self.metrics_collector)
        self.workflow_monitor = WorkflowMonitor(self.metrics_collector)
        
        # Start monitoring
        self.performance_monitor.start_monitoring()
    
    def get_system_overview(self) -> Dict[str, Any]:
        """Get system overview"""
        metrics_summary = self.metrics_collector.get_metrics_summary()
        agent_summary = self.agent_monitor.get_agent_performance_summary()
        workflow_summary = self.workflow_monitor.get_workflow_performance_summary()
        
        return {
            "timestamp": datetime.now().isoformat(),
            "system_metrics": metrics_summary,
            "agent_performance": agent_summary,
            "workflow_performance": workflow_summary,
            "monitoring_status": {
                "performance_monitoring": self.performance_monitor.monitoring,
                "metrics_collected": len(self.metrics_collector.metrics)
            }
        }
    
    def get_health_status(self) -> Dict[str, Any]:
        """Get system health status"""
        try:
            # Get current performance snapshot
            snapshot = self.performance_monitor._take_performance_snapshot()
            
            # Determine health status
            health_issues = []
            
            if snapshot.cpu_percent > 80:
                health_issues.append("High CPU usage")
            
            if snapshot.memory_percent > 85:
                health_issues.append("High memory usage")
            
            if snapshot.disk_usage_percent > 90:
                health_issues.append("High disk usage")
            
            health_status = "healthy" if not health_issues else "warning" if len(health_issues) < 3 else "critical"
            
            return {
                "status": health_status,
                "issues": health_issues,
                "performance": asdict(snapshot),
                "timestamp": datetime.now().isoformat()
            }
            
        except Exception as e:
            logger.error(f"Error getting health status: {str(e)}")
            return {
                "status": "error",
                "error": str(e),
                "timestamp": datetime.now().isoformat()
            }
    
    def stop_monitoring(self):
        """Stop all monitoring"""
        self.performance_monitor.stop_monitoring()
        self.metrics_collector.save_metrics_to_db()

# Global monitoring instance
monitoring_dashboard = MonitoringDashboard()
