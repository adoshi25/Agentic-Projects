#!/usr/bin/env python3
"""
Advanced AI Agents System Test Script
Quick test to verify the system is working correctly.
"""

import asyncio
import sys
import os
from pathlib import Path

# Add current directory to path
sys.path.append(str(Path(__file__).parent))

def test_imports():
    """Test that all modules can be imported"""
    print("🧪 Testing imports...")
    
    try:
        from agents.advanced_agents import (
            AdvancedAgent, ResearchAgent, AnalysisAgent, 
            CreativeAgent, TechnicalAgent, CoordinationAgent, create_agent
        )
        print("✅ Agent imports successful")
        
        from tools.advanced_tools import get_all_tools
        print("✅ Tool imports successful")
        
        from workflows.workflow_orchestrator import WorkflowBuilder, orchestrator
        print("✅ Workflow imports successful")
        
        from utils.monitoring import monitoring_dashboard
        print("✅ Monitoring imports successful")
        
        from integrations.external_services import get_external_service_tools
        print("✅ Integration imports successful")
        
        return True
        
    except ImportError as e:
        print(f"❌ Import failed: {e}")
        return False

def test_agent_creation():
    """Test agent creation"""
    print("\n🤖 Testing agent creation...")
    
    try:
        from agents.advanced_agents import create_agent
        
        # Test creating different types of agents
        research_agent = create_agent("research")
        print("✅ Research agent created")
        
        analysis_agent = create_agent("analysis")
        print("✅ Analysis agent created")
        
        creative_agent = create_agent("creative")
        print("✅ Creative agent created")
        
        technical_agent = create_agent("technical")
        print("✅ Technical agent created")
        
        coordination_agent = create_agent("coordination")
        print("✅ Coordination agent created")
        
        return True
        
    except Exception as e:
        print(f"❌ Agent creation failed: {e}")
        return False

def test_tools():
    """Test tool functionality"""
    print("\n🔧 Testing tools...")
    
    try:
        from tools.advanced_tools import get_all_tools
        
        tools = get_all_tools()
        print(f"✅ Found {len(tools)} tools")
        
        # Test a simple tool
        from tools.advanced_tools import validate_input
        
        result = validate_input("test input", "text")
        if result.get("is_valid"):
            print("✅ Input validation tool working")
        else:
            print("❌ Input validation tool failed")
            return False
        
        return True
        
    except Exception as e:
        print(f"❌ Tool test failed: {e}")
        return False

def test_workflow_builder():
    """Test workflow builder"""
    print("\n🔄 Testing workflow builder...")
    
    try:
        from workflows.workflow_orchestrator import WorkflowBuilder
        from agents.advanced_agents import create_agent
        
        # Create a simple workflow
        research_agent = create_agent("research")
        
        workflow = (WorkflowBuilder()
                   .set_name("Test Workflow")
                   .set_description("A simple test workflow")
                   .add_task(
                       task_id="test_task",
                       name="Test Task",
                       description="A simple test task",
                       agent=research_agent
                   )
                   .build())
        
        print("✅ Workflow builder working")
        print(f"✅ Created workflow: {workflow.name}")
        print(f"✅ Workflow has {len(workflow.tasks)} tasks")
        
        return True
        
    except Exception as e:
        print(f"❌ Workflow builder test failed: {e}")
        return False

def test_monitoring():
    """Test monitoring system"""
    print("\n📊 Testing monitoring system...")
    
    try:
        from utils.monitoring import monitoring_dashboard
        
        # Test getting system overview
        overview = monitoring_dashboard.get_system_overview()
        print("✅ System overview retrieved")
        
        # Test health status
        health = monitoring_dashboard.get_health_status()
        print(f"✅ Health status: {health['status']}")
        
        return True
        
    except Exception as e:
        print(f"❌ Monitoring test failed: {e}")
        return False

def test_configuration():
    """Test configuration system"""
    print("\n⚙️ Testing configuration...")
    
    try:
        from config.settings import system_config, AGENT_CONFIGS
        
        print(f"✅ System config loaded")
        print(f"✅ Found {len(AGENT_CONFIGS)} agent configurations")
        
        # Check if OpenAI API key is configured
        if hasattr(system_config, 'openai_api_key') and system_config.openai_api_key:
            print("✅ OpenAI API key configured")
        else:
            print("⚠️  OpenAI API key not configured (set OPENAI_API_KEY in .env)")
        
        return True
        
    except Exception as e:
        print(f"❌ Configuration test failed: {e}")
        return False

async def test_async_functionality():
    """Test async functionality"""
    print("\n⚡ Testing async functionality...")
    
    try:
        from agents.advanced_agents import create_agent
        from agents.advanced_agents import TaskContext, TaskPriority
        
        # Create an agent
        research_agent = create_agent("research")
        
        # Create a simple task context
        context = TaskContext(
            task_id="test_task_001",
            priority=TaskPriority.MEDIUM,
            metadata={"test": True}
        )
        
        # Test task execution (this will fail without API key, but should not crash)
        try:
            result = await research_agent.execute_task(
                "Test task for system verification",
                context
            )
            print("✅ Async task execution working")
        except Exception as e:
            if "API key" in str(e) or "authentication" in str(e).lower():
                print("⚠️  Async functionality working (API key needed for full test)")
            else:
                print(f"❌ Async task execution failed: {e}")
                return False
        
        return True
        
    except Exception as e:
        print(f"❌ Async functionality test failed: {e}")
        return False

def main():
    """Run all tests"""
    print("🚀 ADVANCED AI AGENTS SYSTEM - SYSTEM TEST")
    print("=" * 50)
    
    tests = [
        ("Import Test", test_imports),
        ("Agent Creation Test", test_agent_creation),
        ("Tools Test", test_tools),
        ("Workflow Builder Test", test_workflow_builder),
        ("Monitoring Test", test_monitoring),
        ("Configuration Test", test_configuration),
    ]
    
    passed = 0
    total = len(tests)
    
    for test_name, test_func in tests:
        print(f"\n{test_name}:")
        if test_func():
            passed += 1
        else:
            print(f"❌ {test_name} failed")
    
    # Test async functionality
    print(f"\nAsync Functionality Test:")
    try:
        if asyncio.run(test_async_functionality()):
            passed += 1
        else:
            print("❌ Async Functionality Test failed")
    except Exception as e:
        print(f"❌ Async Functionality Test failed: {e}")
    
    total += 1
    
    # Summary
    print("\n" + "=" * 50)
    print(f"📊 TEST SUMMARY: {passed}/{total} tests passed")
    
    if passed == total:
        print("🎉 ALL TESTS PASSED! System is ready to use.")
        print("\nNext steps:")
        print("1. Set up your API keys in .env file")
        print("2. Run: python demos/advanced_demo.py")
        print("3. Explore the system capabilities")
    else:
        print("⚠️  Some tests failed. Please check the errors above.")
        print("Make sure you've run: python setup.py")
    
    return passed == total

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)
