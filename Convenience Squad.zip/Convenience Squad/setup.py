#!/usr/bin/env python3
"""
Advanced AI Agents System Setup Script
Helps users set up the advanced agent system with proper configuration.
"""

import os
import sys
import subprocess
import shutil
from pathlib import Path

def print_banner():
    """Print setup banner"""
    print("=" * 60)
    print("🚀 ADVANCED AI AGENTS SYSTEM SETUP")
    print("=" * 60)
    print("Setting up enhanced agent capabilities beyond basic OpenAI Agents SDK")
    print("=" * 60)

def check_python_version():
    """Check if Python version is compatible"""
    if sys.version_info < (3, 8):
        print("❌ Python 3.8 or higher is required")
        print(f"Current version: {sys.version}")
        return False
    print(f"✅ Python version: {sys.version.split()[0]}")
    return True

def install_dependencies():
    """Install required dependencies"""
    print("\n📦 Installing dependencies...")
    try:
        subprocess.check_call([sys.executable, "-m", "pip", "install", "-r", "requirements.txt"])
        print("✅ Dependencies installed successfully")
        return True
    except subprocess.CalledProcessError as e:
        print(f"❌ Failed to install dependencies: {e}")
        return False

def setup_environment():
    """Set up environment configuration"""
    print("\n🔧 Setting up environment configuration...")
    
    env_file = Path(".env")
    env_example = Path("env_example.txt")
    
    if env_file.exists():
        print("✅ .env file already exists")
        return True
    
    if not env_example.exists():
        print("❌ env_example.txt not found")
        return False
    
    # Copy example to .env
    shutil.copy(env_example, env_file)
    print("✅ Created .env file from template")
    
    print("\n⚠️  IMPORTANT: Please edit .env file with your actual API keys")
    print("   Required: OPENAI_API_KEY")
    print("   Optional: Other API keys for enhanced functionality")
    
    return True

def create_directories():
    """Create necessary directories"""
    print("\n📁 Creating directories...")
    
    directories = [
        "logs",
        "data",
        "output",
        "temp"
    ]
    
    for directory in directories:
        Path(directory).mkdir(exist_ok=True)
        print(f"✅ Created directory: {directory}")

def initialize_database():
    """Initialize the database"""
    print("\n🗄️  Initializing database...")
    try:
        # Import and initialize database
        sys.path.append(str(Path.cwd()))
        from tools.advanced_tools import init_database
        init_database()
        print("✅ Database initialized successfully")
        return True
    except Exception as e:
        print(f"❌ Failed to initialize database: {e}")
        return False

def run_basic_test():
    """Run a basic test to verify setup"""
    print("\n🧪 Running basic test...")
    try:
        # Test basic imports
        sys.path.append(str(Path.cwd()))
        from config.settings import system_config
        from agents.advanced_agents import create_agent
        from tools.advanced_tools import get_all_tools
        
        print("✅ All imports successful")
        
        # Test agent creation
        agent = create_agent("research")
        print("✅ Agent creation successful")
        
        # Test tools
        tools = get_all_tools()
        print(f"✅ Found {len(tools)} tools")
        
        return True
    except Exception as e:
        print(f"❌ Basic test failed: {e}")
        return False

def print_next_steps():
    """Print next steps for the user"""
    print("\n" + "=" * 60)
    print("🎉 SETUP COMPLETED SUCCESSFULLY!")
    print("=" * 60)
    print("\nNext steps:")
    print("1. Edit .env file with your API keys")
    print("2. Run the demo: python demos/advanced_demo.py")
    print("3. Explore the code in the agents/, tools/, and workflows/ directories")
    print("4. Check out FEATURES.md for detailed feature overview")
    print("\nKey files to explore:")
    print("- demos/advanced_demo.py - Comprehensive demonstration")
    print("- agents/advanced_agents.py - Enhanced agent implementations")
    print("- tools/advanced_tools.py - Advanced tool functions")
    print("- workflows/workflow_orchestrator.py - Workflow management")
    print("- utils/monitoring.py - Monitoring and analytics")
    print("\nFor help, check the README.md file")

def main():
    """Main setup function"""
    print_banner()
    
    # Check Python version
    if not check_python_version():
        sys.exit(1)
    
    # Install dependencies
    if not install_dependencies():
        print("\n❌ Setup failed at dependency installation")
        sys.exit(1)
    
    # Setup environment
    if not setup_environment():
        print("\n❌ Setup failed at environment configuration")
        sys.exit(1)
    
    # Create directories
    create_directories()
    
    # Initialize database
    if not initialize_database():
        print("\n❌ Setup failed at database initialization")
        sys.exit(1)
    
    # Run basic test
    if not run_basic_test():
        print("\n❌ Setup failed at basic test")
        sys.exit(1)
    
    # Print next steps
    print_next_steps()

if __name__ == "__main__":
    main()
