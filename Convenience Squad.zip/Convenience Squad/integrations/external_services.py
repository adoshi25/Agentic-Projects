"""
External Service Integrations
Advanced integrations with external services and APIs for enhanced agent capabilities.
"""

import asyncio
import json
import logging
import os
from typing import Dict, List, Optional, Any, Union
from datetime import datetime, timedelta
import aiohttp
import requests
from dataclasses import dataclass

# Import function_tool from tools module
from tools.advanced_tools import function_tool
import os

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

@dataclass
class ServiceConfig:
    """Configuration for external services"""
    name: str
    base_url: str
    api_key: Optional[str] = None
    timeout: int = 30
    rate_limit: int = 100  # requests per minute
    headers: Dict[str, str] = None
    
    def __post_init__(self):
        if self.headers is None:
            self.headers = {}

# Service configurations
SERVICE_CONFIGS = {
    "github": ServiceConfig(
        name="GitHub API",
        base_url="https://api.github.com",
        api_key=os.getenv("GITHUB_TOKEN"),
        headers={"Accept": "application/vnd.github.v3+json"}
    ),
    "slack": ServiceConfig(
        name="Slack API",
        base_url="https://slack.com/api",
        api_key=os.getenv("SLACK_BOT_TOKEN")
    ),
    "sendgrid": ServiceConfig(
        name="SendGrid API",
        base_url="https://api.sendgrid.com/v3",
        api_key=os.getenv("SENDGRID_API_KEY")
    )
}

# GitHub Integration
@function_tool
async def github_search_repositories(
    query: str,
    language: str = None,
    sort: str = "stars",
    order: str = "desc",
    per_page: int = 10
) -> Dict[str, Any]:
    """Search GitHub repositories"""
    try:
        config = SERVICE_CONFIGS["github"]
        if not config.api_key:
            return {"status": "error", "message": "GitHub API key not configured"}
        
        params = {
            "q": query,
            "sort": sort,
            "order": order,
            "per_page": per_page
        }
        
        if language:
            params["q"] += f" language:{language}"
        
        headers = {
            **config.headers,
            "Authorization": f"token {config.api_key}"
        }
        
        async with aiohttp.ClientSession() as session:
            async with session.get(
                f"{config.base_url}/search/repositories",
                params=params,
                headers=headers,
                timeout=config.timeout
            ) as response:
                if response.status == 200:
                    data = await response.json()
                    return {
                        "status": "success",
                        "total_count": data.get("total_count", 0),
                        "repositories": [
                            {
                                "name": repo["name"],
                                "full_name": repo["full_name"],
                                "description": repo.get("description", ""),
                                "stars": repo["stargazers_count"],
                                "language": repo.get("language", ""),
                                "url": repo["html_url"],
                                "updated_at": repo["updated_at"]
                            }
                            for repo in data.get("items", [])
                        ]
                    }
                else:
                    return {
                        "status": "error",
                        "message": f"GitHub API error: {response.status}"
                    }
    except Exception as e:
        logger.error(f"Error searching GitHub repositories: {str(e)}")
        return {"status": "error", "message": str(e)}

@function_tool
async def github_get_repository_info(owner: str, repo: str) -> Dict[str, Any]:
    """Get detailed information about a GitHub repository"""
    try:
        config = SERVICE_CONFIGS["github"]
        if not config.api_key:
            return {"status": "error", "message": "GitHub API key not configured"}
        
        headers = {
            **config.headers,
            "Authorization": f"token {config.api_key}"
        }
        
        async with aiohttp.ClientSession() as session:
            async with session.get(
                f"{config.base_url}/repos/{owner}/{repo}",
                headers=headers,
                timeout=config.timeout
            ) as response:
                if response.status == 200:
                    data = await response.json()
                    return {
                        "status": "success",
                        "repository": {
                            "name": data["name"],
                            "full_name": data["full_name"],
                            "description": data.get("description", ""),
                            "stars": data["stargazers_count"],
                            "forks": data["forks_count"],
                            "watchers": data["watchers_count"],
                            "language": data.get("language", ""),
                            "size": data["size"],
                            "created_at": data["created_at"],
                            "updated_at": data["updated_at"],
                            "pushed_at": data["pushed_at"],
                            "topics": data.get("topics", []),
                            "license": data.get("license", {}).get("name", ""),
                            "url": data["html_url"]
                        }
                    }
                else:
                    return {
                        "status": "error",
                        "message": f"GitHub API error: {response.status}"
                    }
    except Exception as e:
        logger.error(f"Error getting repository info: {str(e)}")
        return {"status": "error", "message": str(e)}

# Slack Integration
@function_tool
async def slack_send_message(
    channel: str,
    message: str,
    thread_ts: str = None
) -> Dict[str, Any]:
    """Send a message to a Slack channel"""
    try:
        config = SERVICE_CONFIGS["slack"]
        if not config.api_key:
            return {"status": "error", "message": "Slack API key not configured"}
        
        payload = {
            "channel": channel,
            "text": message
        }
        
        if thread_ts:
            payload["thread_ts"] = thread_ts
        
        headers = {
            "Authorization": f"Bearer {config.api_key}",
            "Content-Type": "application/json"
        }
        
        async with aiohttp.ClientSession() as session:
            async with session.post(
                f"{config.base_url}/chat.postMessage",
                json=payload,
                headers=headers,
                timeout=config.timeout
            ) as response:
                data = await response.json()
                
                if data.get("ok"):
                    return {
                        "status": "success",
                        "message": "Message sent successfully",
                        "ts": data.get("ts"),
                        "channel": data.get("channel")
                    }
                else:
                    return {
                        "status": "error",
                        "message": f"Slack API error: {data.get('error', 'Unknown error')}"
                    }
    except Exception as e:
        logger.error(f"Error sending Slack message: {str(e)}")
        return {"status": "error", "message": str(e)}

@function_tool
async def slack_get_channel_history(
    channel: str,
    limit: int = 10,
    oldest: str = None
) -> Dict[str, Any]:
    """Get message history from a Slack channel"""
    try:
        config = SERVICE_CONFIGS["slack"]
        if not config.api_key:
            return {"status": "error", "message": "Slack API key not configured"}
        
        params = {
            "channel": channel,
            "limit": limit
        }
        
        if oldest:
            params["oldest"] = oldest
        
        headers = {
            "Authorization": f"Bearer {config.api_key}"
        }
        
        async with aiohttp.ClientSession() as session:
            async with session.get(
                f"{config.base_url}/conversations.history",
                params=params,
                headers=headers,
                timeout=config.timeout
            ) as response:
                data = await response.json()
                
                if data.get("ok"):
                    messages = data.get("messages", [])
                    return {
                        "status": "success",
                        "messages": [
                            {
                                "text": msg.get("text", ""),
                                "user": msg.get("user", ""),
                                "ts": msg.get("ts", ""),
                                "type": msg.get("type", "")
                            }
                            for msg in messages
                        ],
                        "has_more": data.get("has_more", False)
                    }
                else:
                    return {
                        "status": "error",
                        "message": f"Slack API error: {data.get('error', 'Unknown error')}"
                    }
    except Exception as e:
        logger.error(f"Error getting Slack history: {str(e)}")
        return {"status": "error", "message": str(e)}

# SendGrid Integration
@function_tool
async def sendgrid_send_email(
    to_email: str,
    subject: str,
    content: str,
    from_email: str = None,
    content_type: str = "text/plain"
) -> Dict[str, Any]:
    """Send an email using SendGrid"""
    try:
        config = SERVICE_CONFIGS["sendgrid"]
        if not config.api_key:
            return {"status": "error", "message": "SendGrid API key not configured"}
        
        if not from_email:
            from_email = "noreply@example.com"  # Default sender
        
        payload = {
            "personalizations": [
                {
                    "to": [{"email": to_email}],
                    "subject": subject
                }
            ],
            "from": {"email": from_email},
            "content": [
                {
                    "type": content_type,
                    "value": content
                }
            ]
        }
        
        headers = {
            "Authorization": f"Bearer {config.api_key}",
            "Content-Type": "application/json"
        }
        
        async with aiohttp.ClientSession() as session:
            async with session.post(
                f"{config.base_url}/mail/send",
                json=payload,
                headers=headers,
                timeout=config.timeout
            ) as response:
                if response.status == 202:
                    return {
                        "status": "success",
                        "message": "Email sent successfully",
                        "status_code": response.status
                    }
                else:
                    error_text = await response.text()
                    return {
                        "status": "error",
                        "message": f"SendGrid API error: {response.status} - {error_text}"
                    }
    except Exception as e:
        logger.error(f"Error sending email: {str(e)}")
        return {"status": "error", "message": str(e)}

# Weather API Integration (using OpenWeatherMap as example)
@function_tool
async def get_weather_info(
    city: str,
    country_code: str = None,
    api_key: str = None
) -> Dict[str, Any]:
    """Get weather information for a city"""
    try:
        if not api_key:
            api_key = os.getenv("OPENWEATHER_API_KEY")
            if not api_key:
                return {"status": "error", "message": "OpenWeather API key not configured"}
        
        location = f"{city},{country_code}" if country_code else city
        
        params = {
            "q": location,
            "appid": api_key,
            "units": "metric"
        }
        
        async with aiohttp.ClientSession() as session:
            async with session.get(
                "https://api.openweathermap.org/data/2.5/weather",
                params=params,
                timeout=30
            ) as response:
                if response.status == 200:
                    data = await response.json()
                    return {
                        "status": "success",
                        "weather": {
                            "city": data["name"],
                            "country": data["sys"]["country"],
                            "temperature": data["main"]["temp"],
                            "feels_like": data["main"]["feels_like"],
                            "humidity": data["main"]["humidity"],
                            "pressure": data["main"]["pressure"],
                            "description": data["weather"][0]["description"],
                            "wind_speed": data["wind"]["speed"],
                            "visibility": data.get("visibility", 0)
                        }
                    }
                else:
                    return {
                        "status": "error",
                        "message": f"Weather API error: {response.status}"
                    }
    except Exception as e:
        logger.error(f"Error getting weather info: {str(e)}")
        return {"status": "error", "message": str(e)}

# News API Integration
@function_tool
async def get_latest_news(
    query: str = None,
    category: str = None,
    country: str = "us",
    api_key: str = None
) -> Dict[str, Any]:
    """Get latest news articles"""
    try:
        if not api_key:
            api_key = os.getenv("NEWS_API_KEY")
            if not api_key:
                return {"status": "error", "message": "News API key not configured"}
        
        if query:
            url = "https://newsapi.org/v2/everything"
            params = {
                "q": query,
                "apiKey": api_key,
                "sortBy": "publishedAt",
                "pageSize": 10
            }
        else:
            url = "https://newsapi.org/v2/top-headlines"
            params = {
                "country": country,
                "apiKey": api_key,
                "pageSize": 10
            }
            
            if category:
                params["category"] = category
        
        async with aiohttp.ClientSession() as session:
            async with session.get(
                url,
                params=params,
                timeout=30
            ) as response:
                if response.status == 200:
                    data = await response.json()
                    return {
                        "status": "success",
                        "total_results": data.get("totalResults", 0),
                        "articles": [
                            {
                                "title": article["title"],
                                "description": article.get("description", ""),
                                "url": article["url"],
                                "published_at": article["publishedAt"],
                                "source": article["source"]["name"]
                            }
                            for article in data.get("articles", [])
                        ]
                    }
                else:
                    return {
                        "status": "error",
                        "message": f"News API error: {response.status}"
                    }
    except Exception as e:
        logger.error(f"Error getting news: {str(e)}")
        return {"status": "error", "message": str(e)}

# Database Integration (using SQLite as example)
@function_tool
def execute_sql_query(
    query: str,
    database_path: str = None
) -> Dict[str, Any]:
    """Execute SQL queries on a database"""
    try:
        import sqlite3
        
        if not database_path:
            database_path = system_config.database_url.replace("sqlite:///", "")
        
        conn = sqlite3.connect(database_path)
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        
        # Execute query
        cursor.execute(query)
        
        # Handle different types of queries
        if query.strip().upper().startswith("SELECT"):
            results = cursor.fetchall()
            return {
                "status": "success",
                "query_type": "SELECT",
                "results": [dict(row) for row in results],
                "row_count": len(results)
            }
        else:
            conn.commit()
            return {
                "status": "success",
                "query_type": "MODIFY",
                "message": "Query executed successfully"
            }
    except Exception as e:
        logger.error(f"Error executing SQL query: {str(e)}")
        return {"status": "error", "message": str(e)}

# File System Integration
@function_tool
def manage_files(
    operation: str,
    file_path: str,
    content: str = None,
    encoding: str = "utf-8"
) -> Dict[str, Any]:
    """Manage files on the file system"""
    try:
        import os
        from pathlib import Path
        
        path = Path(file_path)
        
        if operation == "read":
            if not path.exists():
                return {"status": "error", "message": "File does not exist"}
            
            with open(path, "r", encoding=encoding) as f:
                content = f.read()
            
            return {
                "status": "success",
                "operation": "read",
                "content": content,
                "file_size": path.stat().st_size
            }
        
        elif operation == "write":
            # Create directory if it doesn't exist
            path.parent.mkdir(parents=True, exist_ok=True)
            
            with open(path, "w", encoding=encoding) as f:
                f.write(content)
            
            return {
                "status": "success",
                "operation": "write",
                "file_path": str(path),
                "file_size": path.stat().st_size
            }
        
        elif operation == "delete":
            if not path.exists():
                return {"status": "error", "message": "File does not exist"}
            
            path.unlink()
            return {
                "status": "success",
                "operation": "delete",
                "file_path": str(path)
            }
        
        elif operation == "list":
            if not path.exists():
                return {"status": "error", "message": "Path does not exist"}
            
            if path.is_dir():
                files = [f.name for f in path.iterdir()]
                return {
                    "status": "success",
                    "operation": "list",
                    "path": str(path),
                    "files": files,
                    "file_count": len(files)
                }
            else:
                return {
                    "status": "error",
                    "message": "Path is not a directory"
                }
        
        else:
            return {
                "status": "error",
                "message": f"Unknown operation: {operation}"
            }
    
    except Exception as e:
        logger.error(f"Error managing files: {str(e)}")
        return {"status": "error", "message": str(e)}

# Get all external service tools
def get_external_service_tools() -> List:
    """Get all external service integration tools"""
    return [
        github_search_repositories,
        github_get_repository_info,
        slack_send_message,
        slack_get_channel_history,
        sendgrid_send_email,
        get_weather_info,
        get_latest_news,
        execute_sql_query,
        manage_files
    ]
