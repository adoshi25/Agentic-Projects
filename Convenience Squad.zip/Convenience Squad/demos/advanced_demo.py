"""
Advanced Agent System Demo
Comprehensive demonstration of enhanced agent capabilities beyond basic OpenAI Agents SDK.
"""

import asyncio
import json
import logging
from typing import Dict, List, Any
from datetime import datetime
import os
import sys

# Add parent directory to path for imports
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from dotenv import load_dotenv
# Import mock classes from agents module
from agents.advanced_agents import trace, Runner

# Import will be handled dynamically to avoid circular imports

# Load environment variables
load_dotenv()

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class AdvancedAgentDemo:
    """Demonstration of advanced agent capabilities"""
    
    def __init__(self):
        self.agents = {}
        # Import tools dynamically
        from tools.advanced_tools import get_all_tools
        self.tools = get_all_tools()
        self.setup_agents()
    
    def setup_agents(self):
        """Initialize specialized agents with tools"""
        try:
            # Import agents dynamically
            from agents.advanced_agents import (
                ResearchAgent, AnalysisAgent, CreativeAgent, 
                TechnicalAgent, CoordinationAgent
            )
            
            # Research Agent with advanced tools
            self.agents['research'] = ResearchAgent(
                tools=self.tools[:8],  # Memory, data processing, file tools
                memory_enabled=True,
                context_aware=True
            )
            
            # Analysis Agent with analytical tools
            self.agents['analysis'] = AnalysisAgent(
                tools=self.tools[8:12],  # Web scraping, API, statistical tools
                memory_enabled=True,
                context_aware=True
            )
            
            # Creative Agent with content tools
            self.agents['creative'] = CreativeAgent(
                tools=self.tools[12:14],  # Visualization and validation tools
                memory_enabled=True,
                context_aware=True
            )
            
            # Technical Agent with implementation tools
            self.agents['technical'] = TechnicalAgent(
                tools=self.tools[14:],  # Logging, metrics, security tools
                memory_enabled=True,
                context_aware=True
            )
            
            # Coordination Agent for workflow management
            self.agents['coordination'] = CoordinationAgent(
                tools=self.tools,
                memory_enabled=True,
                context_aware=True
            )
            
            logger.info("All agents initialized successfully")
            
        except Exception as e:
            logger.error(f"Error setting up agents: {str(e)}")
            raise
    
    async def demo_individual_agents(self):
        """Demonstrate individual agent capabilities"""
        print("\n" + "="*60)
        print("INDIVIDUAL AGENT DEMONSTRATIONS")
        print("="*60)
        
        # Research Agent Demo
        print("\n🔍 Research Agent Demo")
        print("-" * 30)
        
        from agents.advanced_agents import TaskContext, TaskPriority
        
        research_context = TaskContext(
            task_id="research_demo_001",
            priority=TaskPriority.HIGH,
            metadata={"demo_type": "research", "topic": "AI Agent Frameworks"}
        )
        
        research_result = await self.agents['research'].conduct_research(
            query="Latest developments in AI agent frameworks for 2024-2025",
            sources=["academic papers", "industry reports", "open source projects"],
            depth="comprehensive"
        )
        
        print(f"Research Status: {'✅ Success' if research_result['success'] else '❌ Failed'}")
        if research_result['success']:
            print(f"Execution Time: {research_result['execution_time']:.2f} seconds")
            print(f"Result Preview: {research_result['result'][:200]}...")
        
        # Analysis Agent Demo
        print("\n📊 Analysis Agent Demo")
        print("-" * 30)
        
        sample_data = {
            "sales": [100, 120, 95, 140, 160, 180, 200],
            "marketing": [80, 90, 85, 110, 130, 150, 170],
            "support": [60, 70, 65, 80, 90, 100, 110]
        }
        
        analysis_context = TaskContext(
            task_id="analysis_demo_001",
            priority=TaskPriority.MEDIUM,
            metadata={"demo_type": "analysis", "data_type": "time_series"}
        )
        
        analysis_result = await self.agents['analysis'].analyze_data(
            data=sample_data,
            analysis_type="comprehensive"
        )
        
        print(f"Analysis Status: {'✅ Success' if analysis_result['success'] else '❌ Failed'}")
        if analysis_result['success']:
            print(f"Execution Time: {analysis_result['execution_time']:.2f} seconds")
            print(f"Result Preview: {analysis_result['result'][:200]}...")
        
        # Creative Agent Demo
        print("\n🎨 Creative Agent Demo")
        print("-" * 30)
        
        creative_context = TaskContext(
            task_id="creative_demo_001",
            priority=TaskPriority.MEDIUM,
            metadata={"demo_type": "creative", "content_type": "blog_post"}
        )
        
        creative_result = await self.agents['creative'].create_content(
            content_type="blog post",
            topic="The Future of AI Agents in Business Automation",
            style="professional",
            length="medium"
        )
        
        print(f"Creative Status: {'✅ Success' if creative_result['success'] else '❌ Failed'}")
        if creative_result['success']:
            print(f"Execution Time: {creative_result['execution_time']:.2f} seconds")
            print(f"Result Preview: {creative_result['result'][:200]}...")
        
        # Technical Agent Demo
        print("\n⚙️ Technical Agent Demo")
        print("-" * 30)
        
        technical_context = TaskContext(
            task_id="technical_demo_001",
            priority=TaskPriority.HIGH,
            metadata={"demo_type": "technical", "complexity": "medium"}
        )
        
        technical_result = await self.agents['technical'].implement_solution(
            requirements="Create a REST API for managing user profiles with authentication",
            technology_stack=["Python", "FastAPI", "SQLAlchemy", "JWT"],
            complexity="medium"
        )
        
        print(f"Technical Status: {'✅ Success' if technical_result['success'] else '❌ Failed'}")
        if technical_result['success']:
            print(f"Execution Time: {technical_result['execution_time']:.2f} seconds")
            print(f"Result Preview: {technical_result['result'][:200]}...")
    
    async def demo_workflow_orchestration(self):
        """Demonstrate complex workflow orchestration"""
        print("\n" + "="*60)
        print("WORKFLOW ORCHESTRATION DEMONSTRATION")
        print("="*60)
        
        # Import workflow components
        from workflows.workflow_orchestrator import WorkflowBuilder, orchestrator
        from agents.advanced_agents import TaskPriority
        
        # Create a complex workflow using the builder
        workflow = (WorkflowBuilder()
                   .set_name("Content Creation and Analysis Workflow")
                   .set_description("A comprehensive workflow that researches a topic, creates content, and analyzes performance")
                   .add_task(
                       task_id="research_task",
                       name="Research Topic",
                       description="Research the latest trends in AI agent frameworks",
                       agent=self.agents['research'],
                       priority=TaskPriority.HIGH,
                       timeout=300
                   )
                   .add_task(
                       task_id="content_creation",
                       name="Create Content",
                       description="Create a comprehensive blog post based on research findings",
                       agent=self.agents['creative'],
                       dependencies=["research_task"],
                       priority=TaskPriority.MEDIUM,
                       timeout=600
                   )
                   .add_task(
                       task_id="technical_analysis",
                       name="Technical Analysis",
                       description="Analyze the technical implementation aspects of the frameworks",
                       agent=self.agents['technical'],
                       dependencies=["research_task"],
                       priority=TaskPriority.MEDIUM,
                       timeout=400
                   )
                   .add_task(
                       task_id="performance_analysis",
                       name="Performance Analysis",
                       description="Analyze the performance metrics and benchmarks",
                       agent=self.agents['analysis'],
                       dependencies=["content_creation", "technical_analysis"],
                       priority=TaskPriority.LOW,
                       timeout=300
                   )
                   .set_global_timeout(1800)  # 30 minutes
                   .set_max_concurrent_tasks(2)
                   .build())
        
        print(f"\n🚀 Executing Workflow: {workflow.name}")
        print(f"Total Tasks: {len(workflow.tasks)}")
        print(f"Max Concurrent Tasks: {workflow.max_concurrent_tasks}")
        print(f"Global Timeout: {workflow.global_timeout} seconds")
        
        # Execute the workflow
        workflow_context = {
            "demo_type": "workflow_orchestration",
            "timestamp": datetime.now().isoformat(),
            "user": "demo_user"
        }
        
        with trace("Advanced Workflow Execution"):
            result = await orchestrator.execute_workflow(workflow, workflow_context)
        
        print(f"\nWorkflow Execution Status: {'✅ Success' if result['status'] == 'success' else '❌ Failed'}")
        print(f"Execution Time: {result.get('execution_time', 0):.2f} seconds")
        print(f"Completed Tasks: {result.get('completed_tasks', 0)}")
        print(f"Failed Tasks: {result.get('failed_tasks', 0)}")
        
        if result.get('errors'):
            print(f"Errors: {result['errors']}")
    
    async def demo_agent_performance_monitoring(self):
        """Demonstrate agent performance monitoring"""
        print("\n" + "="*60)
        print("AGENT PERFORMANCE MONITORING")
        print("="*60)
        
        # Get performance summaries for all agents
        for agent_name, agent in self.agents.items():
            print(f"\n📈 {agent_name.title()} Agent Performance:")
            print("-" * 40)
            
            summary = agent.get_performance_summary()
            metrics = summary['metrics']
            
            print(f"Tasks Completed: {metrics['tasks_completed']}")
            print(f"Success Rate: {metrics['success_rate']:.2%}")
            print(f"Average Response Time: {metrics['average_response_time']:.2f} seconds")
            print(f"Last Activity: {metrics['last_activity']}")
            
            if summary['recent_tasks']:
                print(f"Recent Tasks: {len(summary['recent_tasks'])}")
                for task in summary['recent_tasks'][-2:]:  # Show last 2 tasks
                    status = "✅" if task['success'] else "❌"
                    print(f"  {status} {task['task'][:50]}... ({task['execution_time']:.2f}s)")
        
        # Get orchestrator status
        print(f"\n🎛️ Orchestrator Status:")
        print("-" * 40)
        from workflows.workflow_orchestrator import orchestrator
        status = orchestrator.get_status()
        print(f"Active Workflows: {status['active_workflows']}")
        print(f"Max Concurrent Workflows: {status['max_concurrent_workflows']}")
        
        metrics = status['performance_metrics']
        print(f"Total Workflows: {metrics['total_workflows']}")
        print(f"Successful Workflows: {metrics['successful_workflows']}")
        print(f"Failed Workflows: {metrics['failed_workflows']}")
        print(f"Average Execution Time: {metrics['average_execution_time']:.2f} seconds")
    
    async def demo_advanced_features(self):
        """Demonstrate advanced features beyond basic agents"""
        print("\n" + "="*60)
        print("ADVANCED FEATURES DEMONSTRATION")
        print("="*60)
        
        # Memory Management Demo
        print("\n🧠 Memory Management Demo")
        print("-" * 30)
        
        # Store some memory
        from tools.advanced_tools import store_memory, retrieve_memory
        
        session_id = "demo_session_001"
        memory_result = store_memory(
            agent_name="research",
            session_id=session_id,
            content="User prefers detailed technical analysis with code examples",
            metadata='{"preference": "technical", "style": "detailed"}'
        )
        
        print(f"Memory Storage: {'✅ Success' if memory_result['status'] == 'success' else '❌ Failed'}")
        
        # Retrieve memory
        retrieval_result = retrieve_memory(
            agent_name="research",
            session_id=session_id,
            limit=5
        )
        
        print(f"Memory Retrieval: {'✅ Success' if retrieval_result['status'] == 'success' else '❌ Failed'}")
        if retrieval_result['status'] == 'success':
            print(f"Retrieved Memories: {len(retrieval_result['memories'])}")
        
        # Input Validation Demo
        print("\n🔒 Input Validation Demo")
        print("-" * 30)
        
        from tools.advanced_tools import validate_input
        
        test_inputs = [
            "This is a normal text input",
            "<script>alert('xss')</script>",
            "user@example.com",
            "invalid-email"
        ]
        
        for test_input in test_inputs:
            validation_result = validate_input(
                test_input,
                "text" if "@" not in test_input else "email"
            )
            status = "✅ Valid" if validation_result['is_valid'] else "❌ Invalid"
            print(f"{status}: {test_input[:30]}...")
            if validation_result['issues']:
                print(f"  Issues: {validation_result['issues']}")
        
        # Performance Metrics Demo
        print("\n📊 Performance Metrics Demo")
        print("-" * 30)
        
        from tools.advanced_tools import get_performance_metrics
        
        metrics_result = get_performance_metrics(days=1)
        print(f"Metrics Retrieval: {'✅ Success' if metrics_result['status'] == 'success' else '❌ Failed'}")
        if metrics_result['status'] == 'success':
            print(f"Metrics Found: {len(metrics_result['metrics'])}")
    
    async def run_complete_demo(self):
        """Run the complete demonstration"""
        print("🚀 ADVANCED AI AGENTS SYSTEM DEMONSTRATION")
        print("=" * 60)
        print("This demo showcases enhanced capabilities beyond basic OpenAI Agents SDK")
        print("=" * 60)
        
        try:
            # Individual agent demonstrations
            await self.demo_individual_agents()
            
            # Workflow orchestration demonstration
            await self.demo_workflow_orchestration()
            
            # Performance monitoring demonstration
            await self.demo_agent_performance_monitoring()
            
            # Advanced features demonstration
            await self.demo_advanced_features()
            
            print("\n" + "="*60)
            print("🎉 DEMONSTRATION COMPLETED SUCCESSFULLY!")
            print("="*60)
            print("\nKey Enhancements Demonstrated:")
            print("✅ Advanced agent specialization and capabilities")
            print("✅ Sophisticated workflow orchestration")
            print("✅ Memory management and context awareness")
            print("✅ Performance monitoring and analytics")
            print("✅ Input validation and security features")
            print("✅ Multi-modal data processing capabilities")
            print("✅ Error handling and retry mechanisms")
            print("✅ Concurrent task execution")
            print("✅ Comprehensive logging and metrics")
            
        except Exception as e:
            logger.error(f"Demo failed: {str(e)}")
            print(f"\n❌ Demo failed with error: {str(e)}")
            raise

async def main():
    """Main demo execution"""
    try:
        # Check if required environment variables are set
        if not os.getenv('OPENAI_API_KEY'):
            print("❌ OPENAI_API_KEY environment variable not set")
            print("Please set your OpenAI API key in the .env file")
            return
        
        # Create and run demo
        demo = AdvancedAgentDemo()
        await demo.run_complete_demo()
        
    except KeyboardInterrupt:
        print("\n\n⏹️ Demo interrupted by user")
    except Exception as e:
        print(f"\n❌ Demo failed: {str(e)}")
        logger.exception("Demo execution failed")

if __name__ == "__main__":
    asyncio.run(main())
