"""
Advanced Workflow Orchestrator
Manages complex multi-agent workflows with sophisticated coordination and monitoring.
"""

import asyncio
import json
import logging
from typing import Dict, List, Optional, Any, Union, Callable
from datetime import datetime, timedelta
from dataclasses import dataclass, field
from enum import Enum
import uuid

# Mock enums for demo purposes
class TaskPriority(Enum):
    LOW = 1
    MEDIUM = 2
    HIGH = 3
    CRITICAL = 4

# Import mock classes from agents module
from agents.advanced_agents import Agent, Runner, trace
from pydantic import BaseModel, Field

# Import will be handled dynamically to avoid circular imports
from tools.advanced_tools import log_task_execution

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class WorkflowStatus(Enum):
    """Workflow execution status"""
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"
    PAUSED = "paused"

class TaskStatus(Enum):
    """Individual task status"""
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    SKIPPED = "skipped"

@dataclass
class WorkflowTask:
    """Represents a task within a workflow"""
    task_id: str
    name: str
    description: str
    agent: Any  # Will be AdvancedAgent when imported
    input_data: Any = None
    dependencies: List[str] = field(default_factory=list)
    priority: TaskPriority = TaskPriority.MEDIUM
    timeout: int = 300
    retry_count: int = 0
    max_retries: int = 3
    status: TaskStatus = TaskStatus.PENDING
    result: Any = None
    error: str = None
    start_time: Optional[datetime] = None
    end_time: Optional[datetime] = None
    metadata: Dict[str, Any] = field(default_factory=dict)

@dataclass
class WorkflowDefinition:
    """Defines a complete workflow"""
    workflow_id: str
    name: str
    description: str
    tasks: List[WorkflowTask]
    global_timeout: int = 1800  # 30 minutes
    max_concurrent_tasks: int = 5
    retry_policy: Dict[str, Any] = field(default_factory=dict)
    metadata: Dict[str, Any] = field(default_factory=dict)

class WorkflowOrchestrator:
    """Orchestrates complex multi-agent workflows"""
    
    def __init__(self, max_concurrent_workflows: int = 3):
        self.max_concurrent_workflows = max_concurrent_workflows
        self.active_workflows: Dict[str, 'WorkflowExecution'] = {}
        self.workflow_history: List[Dict[str, Any]] = []
        self.performance_metrics = {
            "total_workflows": 0,
            "successful_workflows": 0,
            "failed_workflows": 0,
            "average_execution_time": 0.0
        }
    
    async def execute_workflow(
        self,
        workflow_def: WorkflowDefinition,
        context: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """Execute a complete workflow"""
        execution_id = str(uuid.uuid4())
        
        # Check if we can start a new workflow
        if len(self.active_workflows) >= self.max_concurrent_workflows:
            return {
                "status": "error",
                "message": "Maximum concurrent workflows reached",
                "execution_id": execution_id
            }
        
        # Create workflow execution
        execution = WorkflowExecution(
            execution_id=execution_id,
            workflow_def=workflow_def,
            context=context or {}
        )
        
        self.active_workflows[execution_id] = execution
        
        try:
            # Execute the workflow
            result = await execution.run()
            
            # Update metrics
            self._update_metrics(execution)
            
            # Move to history
            self.workflow_history.append(execution.get_summary())
            del self.active_workflows[execution_id]
            
            return result
            
        except Exception as e:
            logger.error(f"Workflow execution failed: {str(e)}")
            
            # Update metrics
            self._update_metrics(execution)
            
            # Move to history
            self.workflow_history.append(execution.get_summary())
            del self.active_workflows[execution_id]
            
            return {
                "status": "error",
                "message": str(e),
                "execution_id": execution_id
            }
    
    def _update_metrics(self, execution: 'WorkflowExecution'):
        """Update performance metrics"""
        self.performance_metrics["total_workflows"] += 1
        
        if execution.status == WorkflowStatus.COMPLETED:
            self.performance_metrics["successful_workflows"] += 1
        else:
            self.performance_metrics["failed_workflows"] += 1
        
        # Update average execution time
        if execution.end_time and execution.start_time:
            execution_time = (execution.end_time - execution.start_time).total_seconds()
            total_workflows = self.performance_metrics["total_workflows"]
            current_avg = self.performance_metrics["average_execution_time"]
            new_avg = ((current_avg * (total_workflows - 1)) + execution_time) / total_workflows
            self.performance_metrics["average_execution_time"] = new_avg
    
    def get_status(self) -> Dict[str, Any]:
        """Get orchestrator status"""
        return {
            "active_workflows": len(self.active_workflows),
            "max_concurrent_workflows": self.max_concurrent_workflows,
            "performance_metrics": self.performance_metrics,
            "recent_workflows": self.workflow_history[-5:] if self.workflow_history else []
        }

class WorkflowExecution:
    """Manages the execution of a single workflow"""
    
    def __init__(
        self,
        execution_id: str,
        workflow_def: WorkflowDefinition,
        context: Dict[str, Any]
    ):
        self.execution_id = execution_id
        self.workflow_def = workflow_def
        self.context = context
        self.status = WorkflowStatus.PENDING
        self.start_time: Optional[datetime] = None
        self.end_time: Optional[datetime] = None
        self.tasks: Dict[str, WorkflowTask] = {
            task.task_id: task for task in workflow_def.tasks
        }
        self.completed_tasks: List[str] = []
        self.failed_tasks: List[str] = []
        self.results: Dict[str, Any] = {}
        self.errors: List[str] = []
    
    async def run(self) -> Dict[str, Any]:
        """Execute the workflow"""
        self.status = WorkflowStatus.RUNNING
        self.start_time = datetime.now()
        
        try:
            # Execute tasks in dependency order
            await self._execute_tasks()
            
            # Check if all tasks completed successfully
            if len(self.failed_tasks) == 0:
                self.status = WorkflowStatus.COMPLETED
            else:
                self.status = WorkflowStatus.FAILED
            
            self.end_time = datetime.now()
            
            return {
                "status": "success" if self.status == WorkflowStatus.COMPLETED else "failed",
                "execution_id": self.execution_id,
                "workflow_name": self.workflow_def.name,
                "execution_time": (self.end_time - self.start_time).total_seconds(),
                "completed_tasks": len(self.completed_tasks),
                "failed_tasks": len(self.failed_tasks),
                "results": self.results,
                "errors": self.errors
            }
            
        except Exception as e:
            self.status = WorkflowStatus.FAILED
            self.end_time = datetime.now()
            self.errors.append(str(e))
            
            return {
                "status": "error",
                "execution_id": self.execution_id,
                "workflow_name": self.workflow_def.name,
                "error": str(e),
                "execution_time": (self.end_time - self.start_time).total_seconds()
            }
    
    async def _execute_tasks(self):
        """Execute tasks in the correct order based on dependencies"""
        # Create a copy of tasks to track remaining tasks
        remaining_tasks = set(self.tasks.keys())
        completed_tasks = set()
        
        while remaining_tasks:
            # Find tasks that can be executed (dependencies satisfied)
            ready_tasks = []
            for task_id in remaining_tasks:
                task = self.tasks[task_id]
                if all(dep in completed_tasks for dep in task.dependencies):
                    ready_tasks.append(task)
            
            if not ready_tasks:
                # No tasks can be executed - check for circular dependencies
                raise Exception("Circular dependency detected or no executable tasks found")
            
            # Execute ready tasks concurrently (up to max_concurrent_tasks)
            semaphore = asyncio.Semaphore(self.workflow_def.max_concurrent_tasks)
            tasks_to_execute = ready_tasks[:self.workflow_def.max_concurrent_tasks]
            
            execution_tasks = [
                self._execute_single_task(task, semaphore)
                for task in tasks_to_execute
            ]
            
            results = await asyncio.gather(*execution_tasks, return_exceptions=True)
            
            # Process results
            for i, result in enumerate(results):
                task = tasks_to_execute[i]
                
                if isinstance(result, Exception):
                    task.status = TaskStatus.FAILED
                    task.error = str(result)
                    self.failed_tasks.append(task.task_id)
                    self.errors.append(f"Task {task.name} failed: {str(result)}")
                else:
                    task.status = TaskStatus.COMPLETED
                    task.result = result
                    self.completed_tasks.append(task.task_id)
                    self.results[task.task_id] = result
                
                # Remove from remaining tasks
                remaining_tasks.remove(task.task_id)
                completed_tasks.add(task.task_id)
    
    async def _execute_single_task(
        self,
        task: WorkflowTask,
        semaphore: asyncio.Semaphore
    ) -> Any:
        """Execute a single task with retry logic"""
        async with semaphore:
            task.status = TaskStatus.RUNNING
            task.start_time = datetime.now()
            
            # Log task start
            await log_task_execution(
                task_id=task.task_id,
                agent_name=task.agent.name,
                task_description=task.description,
                status="running"
            )
            
            for attempt in range(task.max_retries + 1):
                try:
                    # Create task context
                    context = TaskContext(
                        task_id=task.task_id,
                        priority=task.priority,
                        metadata={
                            **task.metadata,
                            "workflow_id": self.workflow_def.workflow_id,
                            "execution_id": self.execution_id,
                            "attempt": attempt + 1
                        }
                    )
                    
                    # Execute the task
                    result = await asyncio.wait_for(
                        task.agent.execute_task(task.description, context, input_data=task.input_data),
                        timeout=task.timeout
                    )
                    
                    task.end_time = datetime.now()
                    execution_time = (task.end_time - task.start_time).total_seconds()
                    
                    # Log successful completion
                    await log_task_execution(
                        task_id=task.task_id,
                        agent_name=task.agent.name,
                        task_description=task.description,
                        status="completed",
                        result=json.dumps(result),
                        execution_time=execution_time
                    )
                    
                    return result
                    
                except asyncio.TimeoutError:
                    error_msg = f"Task {task.name} timed out after {task.timeout} seconds"
                    if attempt < task.max_retries:
                        logger.warning(f"{error_msg}, retrying... (attempt {attempt + 1})")
                        await asyncio.sleep(2 ** attempt)  # Exponential backoff
                        continue
                    else:
                        raise Exception(error_msg)
                        
                except Exception as e:
                    if attempt < task.max_retries:
                        logger.warning(f"Task {task.name} failed, retrying... (attempt {attempt + 1}): {str(e)}")
                        await asyncio.sleep(2 ** attempt)  # Exponential backoff
                        continue
                    else:
                        raise e
            
            # If we get here, all retries failed
            task.end_time = datetime.now()
            execution_time = (task.end_time - task.start_time).total_seconds()
            
            # Log failure
            await log_task_execution(
                task_id=task.task_id,
                agent_name=task.agent.name,
                task_description=task.description,
                status="failed",
                result=task.error,
                execution_time=execution_time
            )
            
            raise Exception(f"Task {task.name} failed after {task.max_retries} retries")
    
    def get_summary(self) -> Dict[str, Any]:
        """Get workflow execution summary"""
        return {
            "execution_id": self.execution_id,
            "workflow_name": self.workflow_def.name,
            "status": self.status.value,
            "start_time": self.start_time.isoformat() if self.start_time else None,
            "end_time": self.end_time.isoformat() if self.end_time else None,
            "execution_time": (
                (self.end_time - self.start_time).total_seconds()
                if self.start_time and self.end_time else None
            ),
            "total_tasks": len(self.tasks),
            "completed_tasks": len(self.completed_tasks),
            "failed_tasks": len(self.failed_tasks),
            "errors": self.errors
        }

# Workflow Builder for creating workflows programmatically
class WorkflowBuilder:
    """Builder pattern for creating workflows"""
    
    def __init__(self, workflow_id: str = None):
        self.workflow_id = workflow_id or str(uuid.uuid4())
        self.name = ""
        self.description = ""
        self.tasks: List[WorkflowTask] = []
        self.global_timeout = 1800
        self.max_concurrent_tasks = 5
        self.retry_policy = {}
        self.metadata = {}
    
    def set_name(self, name: str) -> 'WorkflowBuilder':
        """Set workflow name"""
        self.name = name
        return self
    
    def set_description(self, description: str) -> 'WorkflowBuilder':
        """Set workflow description"""
        self.description = description
        return self
    
    def add_task(
        self,
        task_id: str,
        name: str,
        description: str,
        agent: Any,
        dependencies: List[str] = None,
        priority: TaskPriority = TaskPriority.MEDIUM,
        timeout: int = 300,
        max_retries: int = 3,
        input_data: Any = None,
        metadata: Dict[str, Any] = None
    ) -> 'WorkflowBuilder':
        """Add a task to the workflow"""
        task = WorkflowTask(
            task_id=task_id,
            name=name,
            description=description,
            agent=agent,
            dependencies=dependencies or [],
            priority=priority,
            timeout=timeout,
            max_retries=max_retries,
            input_data=input_data,
            metadata=metadata or {}
        )
        self.tasks.append(task)
        return self
    
    def set_global_timeout(self, timeout: int) -> 'WorkflowBuilder':
        """Set global workflow timeout"""
        self.global_timeout = timeout
        return self
    
    def set_max_concurrent_tasks(self, max_tasks: int) -> 'WorkflowBuilder':
        """Set maximum concurrent tasks"""
        self.max_concurrent_tasks = max_tasks
        return self
    
    def set_retry_policy(self, policy: Dict[str, Any]) -> 'WorkflowBuilder':
        """Set retry policy"""
        self.retry_policy = policy
        return self
    
    def set_metadata(self, metadata: Dict[str, Any]) -> 'WorkflowBuilder':
        """Set workflow metadata"""
        self.metadata = metadata
        return self
    
    def build(self) -> WorkflowDefinition:
        """Build the workflow definition"""
        return WorkflowDefinition(
            workflow_id=self.workflow_id,
            name=self.name,
            description=self.description,
            tasks=self.tasks,
            global_timeout=self.global_timeout,
            max_concurrent_tasks=self.max_concurrent_tasks,
            retry_policy=self.retry_policy,
            metadata=self.metadata
        )

# Global orchestrator instance
orchestrator = WorkflowOrchestrator()
