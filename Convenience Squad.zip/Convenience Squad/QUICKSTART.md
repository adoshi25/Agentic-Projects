# Quick Start Guide - Advanced AI Agents System

## 🚀 Get Started in 5 Minutes

This guide will help you quickly set up and run the advanced agent system that extends beyond basic OpenAI Agents SDK functionality.

## Prerequisites

- Python 3.8 or higher
- OpenAI API key
- (Optional) Other API keys for enhanced features

## Step 1: Setup

```bash
# Navigate to the advanced agents directory
cd 7_advanced_agents

# Run the setup script
python setup.py
```

The setup script will:
- Install all required dependencies
- Create necessary directories
- Set up environment configuration
- Initialize the database
- Run basic tests

## Step 2: Configure API Keys

Edit the `.env` file with your API keys:

```bash
# Required
OPENAI_API_KEY=your_openai_api_key_here

# Optional (for enhanced features)
SENDGRID_API_KEY=your_sendgrid_key
SLACK_BOT_TOKEN=your_slack_token
GITHUB_TOKEN=your_github_token
```

## Step 3: Run the Demo

```bash
python demos/advanced_demo.py
```

This will demonstrate:
- ✅ Individual agent capabilities
- ✅ Complex workflow orchestration
- ✅ Performance monitoring
- ✅ Advanced features

## Step 4: Explore the System

### Key Components

1. **Agents** (`agents/advanced_agents.py`)
   - Research Agent: Advanced research capabilities
   - Analysis Agent: Data analysis and insights
   - Creative Agent: Content creation
   - Technical Agent: Implementation and coding
   - Coordination Agent: Workflow management

2. **Tools** (`tools/advanced_tools.py`)
   - Memory management
   - Data processing
   - File operations
   - Web scraping
   - Security validation

3. **Workflows** (`workflows/workflow_orchestrator.py`)
   - Complex multi-agent workflows
   - Parallel execution
   - Error handling and retry logic

4. **Monitoring** (`utils/monitoring.py`)
   - Performance metrics
   - System health monitoring
   - Agent analytics

## Example Usage

### Create a Research Agent

```python
from agents.advanced_agents import ResearchAgent

# Create a research agent
research_agent = ResearchAgent()

# Conduct research
result = await research_agent.conduct_research(
    query="Latest AI agent frameworks",
    sources=["academic papers", "industry reports"],
    depth="comprehensive"
)
```

### Create a Workflow

```python
from workflows.workflow_orchestrator import WorkflowBuilder

# Build a workflow
workflow = (WorkflowBuilder()
    .set_name("Content Creation Workflow")
    .add_task("research", "Research topic", research_agent)
    .add_task("create", "Create content", creative_agent, dependencies=["research"])
    .build())

# Execute workflow
result = await orchestrator.execute_workflow(workflow)
```

## Key Features Demonstrated

### Beyond Basic Week 2 Functionality

| Feature | Week 2 | Advanced System |
|---------|--------|-----------------|
| Agents | 3 basic | 5+ specialized |
| Tools | 3-4 basic | 16+ advanced |
| Memory | None | Persistent |
| Workflows | Simple | Complex orchestration |
| Monitoring | Basic | Comprehensive |
| Security | Basic | Multi-layer |

## Troubleshooting

### Common Issues

1. **Import Errors**
   ```bash
   # Make sure you're in the right directory
   cd 7_advanced_agents
   python setup.py
   ```

2. **API Key Issues**
   ```bash
   # Check your .env file
   cat .env
   # Make sure OPENAI_API_KEY is set
   ```

3. **Dependency Issues**
   ```bash
   # Reinstall dependencies
   pip install -r requirements.txt
   ```

### Getting Help

- Check the `README.md` for detailed documentation
- Review `FEATURES.md` for feature overview
- Look at `demos/advanced_demo.py` for examples
- Check the code comments for implementation details

## Next Steps

1. **Customize Agents**: Modify agent instructions and capabilities
2. **Add Tools**: Create custom tools for your use case
3. **Build Workflows**: Design complex multi-agent workflows
4. **Monitor Performance**: Use the monitoring dashboard
5. **Integrate Services**: Connect external APIs and services

## Advanced Features

### Memory Management
```python
from tools.advanced_tools import store_memory, retrieve_memory

# Store information
await store_memory("agent_name", "session_id", "important information")

# Retrieve information
memories = await retrieve_memory("agent_name", "session_id")
```

### Performance Monitoring
```python
from utils.monitoring import monitoring_dashboard

# Get system overview
overview = monitoring_dashboard.get_system_overview()

# Check health status
health = monitoring_dashboard.get_health_status()
```

### External Integrations
```python
from integrations.external_services import github_search_repositories

# Search GitHub repositories
repos = await github_search_repositories("AI agents", language="Python")
```

## 🎉 You're Ready!

You now have a fully functional advanced agent system that goes far beyond basic OpenAI Agents SDK functionality. Explore the code, customize the agents, and build amazing AI-powered applications!

For more detailed information, check out the full documentation in `README.md` and `FEATURES.md`.
