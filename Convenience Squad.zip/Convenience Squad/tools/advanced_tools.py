"""
Advanced Tool Functions
Enhanced tools that provide sophisticated functionality beyond basic OpenAI Agents SDK tools.
"""

import asyncio
import json
import logging
import os
import sqlite3
import hashlib
import requests
import aiohttp
from typing import Dict, List, Optional, Any, Union
from datetime import datetime, timedelta
from dataclasses import dataclass
from pathlib import Path
import pandas as pd
import numpy as np
from PIL import Image
# Advanced image/audio processing imports (optional)
# import cv2
# import pytesseract
# from pydub import AudioSegment
# import whisper
import PyPDF2
from docx import Document
import openpyxl
from bs4 import BeautifulSoup

# Simple function tool decorator for demo purposes
def function_tool(func):
    """Simple function tool decorator"""
    func._is_tool = True
    return func
# Configuration will be handled dynamically
import os

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Database connection
def get_db_connection():
    """Get database connection"""
    db_path = os.getenv("DATABASE_URL", "sqlite:///./agents.db").replace("sqlite:///", "")
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    return conn

# Initialize database tables
def init_database():
    """Initialize database tables"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS agent_memory (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            agent_name TEXT NOT NULL,
            session_id TEXT NOT NULL,
            content TEXT NOT NULL,
            metadata TEXT,
            timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    """)
    
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS task_history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            task_id TEXT UNIQUE NOT NULL,
            agent_name TEXT NOT NULL,
            task_description TEXT NOT NULL,
            status TEXT NOT NULL,
            result TEXT,
            execution_time REAL,
            timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    """)
    
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS performance_metrics (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            agent_name TEXT NOT NULL,
            metric_name TEXT NOT NULL,
            metric_value REAL NOT NULL,
            timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    """)
    
    conn.commit()
    conn.close()

# Initialize database on import
init_database()

# Memory Management Tools
@function_tool
def store_memory(agent_name: str, session_id: str, content: str, metadata: str = None) -> Dict[str, str]:
    """Store information in agent memory for future reference"""
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        cursor.execute("""
            INSERT INTO agent_memory (agent_name, session_id, content, metadata)
            VALUES (?, ?, ?, ?)
        """, (agent_name, session_id, content, metadata))
        
        conn.commit()
        conn.close()
        
        return {"status": "success", "message": "Memory stored successfully"}
    except Exception as e:
        logger.error(f"Error storing memory: {str(e)}")
        return {"status": "error", "message": str(e)}

@function_tool
def retrieve_memory(agent_name: str, session_id: str, limit: int = 10) -> Dict[str, Any]:
    """Retrieve stored memory for an agent session"""
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        cursor.execute("""
            SELECT content, metadata, timestamp
            FROM agent_memory
            WHERE agent_name = ? AND session_id = ?
            ORDER BY timestamp DESC
            LIMIT ?
        """, (agent_name, session_id, limit))
        
        memories = cursor.fetchall()
        conn.close()
        
        return {
            "status": "success",
            "memories": [dict(memory) for memory in memories]
        }
    except Exception as e:
        logger.error(f"Error retrieving memory: {str(e)}")
        return {"status": "error", "message": str(e)}

# Data Processing Tools
@function_tool
def process_csv_data(file_path: str, operations: List[str]) -> Dict[str, Any]:
    """Process CSV data with various operations"""
    try:
        df = pd.read_csv(file_path)
        results = {"original_shape": df.shape}
        
        for operation in operations:
            if operation == "describe":
                results["description"] = df.describe().to_dict()
            elif operation == "info":
                results["info"] = {
                    "columns": df.columns.tolist(),
                    "dtypes": df.dtypes.to_dict(),
                    "null_counts": df.isnull().sum().to_dict()
                }
            elif operation == "head":
                results["head"] = df.head().to_dict()
            elif operation == "correlation":
                numeric_df = df.select_dtypes(include=[np.number])
                results["correlation"] = numeric_df.corr().to_dict()
        
        return {"status": "success", "results": results}
    except Exception as e:
        logger.error(f"Error processing CSV: {str(e)}")
        return {"status": "error", "message": str(e)}

@function_tool
def analyze_text_sentiment(text: str) -> Dict[str, Any]:
    """Analyze sentiment of text using simple heuristics"""
    try:
        positive_words = ["good", "great", "excellent", "amazing", "wonderful", "fantastic", "love", "like"]
        negative_words = ["bad", "terrible", "awful", "hate", "dislike", "horrible", "worst", "disappointed"]
        
        text_lower = text.lower()
        positive_count = sum(1 for word in positive_words if word in text_lower)
        negative_count = sum(1 for word in negative_words if word in text_lower)
        
        if positive_count > negative_count:
            sentiment = "positive"
            score = positive_count / (positive_count + negative_count + 1)
        elif negative_count > positive_count:
            sentiment = "negative"
            score = negative_count / (positive_count + negative_count + 1)
        else:
            sentiment = "neutral"
            score = 0.5
        
        return {
            "status": "success",
            "sentiment": sentiment,
            "score": score,
            "positive_words_found": positive_count,
            "negative_words_found": negative_count
        }
    except Exception as e:
        logger.error(f"Error analyzing sentiment: {str(e)}")
        return {"status": "error", "message": str(e)}

# File Processing Tools
@function_tool
def extract_text_from_pdf(file_path: str) -> Dict[str, Any]:
    """Extract text content from PDF files"""
    try:
        with open(file_path, 'rb') as file:
            pdf_reader = PyPDF2.PdfReader(file)
            text = ""
            
            for page_num in range(len(pdf_reader.pages)):
                page = pdf_reader.pages[page_num]
                text += page.extract_text() + "\n"
        
        return {
            "status": "success",
            "text": text,
            "page_count": len(pdf_reader.pages),
            "character_count": len(text)
        }
    except Exception as e:
        logger.error(f"Error extracting PDF text: {str(e)}")
        return {"status": "error", "message": str(e)}

@function_tool
def extract_text_from_docx(file_path: str) -> Dict[str, Any]:
    """Extract text content from Word documents"""
    try:
        doc = Document(file_path)
        text = ""
        
        for paragraph in doc.paragraphs:
            text += paragraph.text + "\n"
        
        return {
            "status": "success",
            "text": text,
            "paragraph_count": len(doc.paragraphs),
            "character_count": len(text)
        }
    except Exception as e:
        logger.error(f"Error extracting DOCX text: {str(e)}")
        return {"status": "error", "message": str(e)}

@function_tool
def extract_text_from_image(image_path: str) -> Dict[str, Any]:
    """Extract text from images using OCR (requires pytesseract)"""
    try:
        # Check if pytesseract is available
        try:
            import pytesseract
        except ImportError:
            return {
                "status": "error", 
                "message": "pytesseract not installed. Install with: pip install pytesseract"
            }
        
        image = Image.open(image_path)
        text = pytesseract.image_to_string(image)
        
        return {
            "status": "success",
            "text": text,
            "character_count": len(text),
            "image_size": image.size
        }
    except Exception as e:
        logger.error(f"Error extracting text from image: {str(e)}")
        return {"status": "error", "message": str(e)}

@function_tool
def transcribe_audio(audio_path: str) -> Dict[str, Any]:
    """Transcribe audio files to text (requires whisper)"""
    try:
        # Check if whisper is available
        try:
            import whisper
        except ImportError:
            return {
                "status": "error", 
                "message": "whisper not installed. Install with: pip install openai-whisper"
            }
        
        model = whisper.load_model("base")
        result = model.transcribe(audio_path)
        
        return {
            "status": "success",
            "text": result["text"],
            "language": result.get("language", "unknown"),
            "duration": result.get("duration", 0)
        }
    except Exception as e:
        logger.error(f"Error transcribing audio: {str(e)}")
        return {"status": "error", "message": str(e)}

# Web Scraping and API Tools
@function_tool
def scrape_webpage(url: str, selectors: Dict[str, str] = None) -> Dict[str, Any]:
    """Scrape content from web pages"""
    try:
        response = requests.get(url, timeout=10)
        response.raise_for_status()
        
        soup = BeautifulSoup(response.content, 'html.parser')
        
        if selectors:
            extracted_data = {}
            for key, selector in selectors.items():
                elements = soup.select(selector)
                extracted_data[key] = [elem.get_text().strip() for elem in elements]
        else:
            # Extract basic content
            extracted_data = {
                "title": soup.title.string if soup.title else "",
                "headings": [h.get_text().strip() for h in soup.find_all(['h1', 'h2', 'h3'])],
                "paragraphs": [p.get_text().strip() for p in soup.find_all('p')],
                "links": [a.get('href') for a in soup.find_all('a', href=True)]
            }
        
        return {
            "status": "success",
            "url": url,
            "extracted_data": extracted_data,
            "content_length": len(response.content)
        }
    except Exception as e:
        logger.error(f"Error scraping webpage: {str(e)}")
        return {"status": "error", "message": str(e)}

@function_tool
async def make_api_request(
    url: str,
    method: str = "GET",
    headers: Dict[str, str] = None,
    data: Dict[str, Any] = None,
    timeout: int = 30
) -> Dict[str, Any]:
    """Make HTTP API requests"""
    try:
        async with aiohttp.ClientSession() as session:
            async with session.request(
                method=method,
                url=url,
                headers=headers,
                json=data,
                timeout=timeout
            ) as response:
                response_data = await response.json() if response.content_type == 'application/json' else await response.text()
                
                return {
                    "status": "success",
                    "status_code": response.status,
                    "data": response_data,
                    "headers": dict(response.headers)
                }
    except Exception as e:
        logger.error(f"Error making API request: {str(e)}")
        return {"status": "error", "message": str(e)}

# Data Analysis Tools
@function_tool
def perform_statistical_analysis(data: List[float], analysis_type: str = "descriptive") -> Dict[str, Any]:
    """Perform statistical analysis on numerical data"""
    try:
        data_array = np.array(data)
        results = {}
        
        if analysis_type == "descriptive":
            results = {
                "mean": float(np.mean(data_array)),
                "median": float(np.median(data_array)),
                "std": float(np.std(data_array)),
                "min": float(np.min(data_array)),
                "max": float(np.max(data_array)),
                "count": len(data_array)
            }
        elif analysis_type == "distribution":
            results = {
                "mean": float(np.mean(data_array)),
                "std": float(np.std(data_array)),
                "skewness": float(pd.Series(data_array).skew()),
                "kurtosis": float(pd.Series(data_array).kurtosis())
            }
        
        return {"status": "success", "analysis_type": analysis_type, "results": results}
    except Exception as e:
        logger.error(f"Error performing statistical analysis: {str(e)}")
        return {"status": "error", "message": str(e)}

@function_tool
def generate_data_visualization(
    data: Dict[str, List[float]],
    chart_type: str = "line",
    title: str = "Data Visualization"
) -> Dict[str, Any]:
    """Generate data visualizations"""
    try:
        import matplotlib.pyplot as plt
        
        fig, ax = plt.subplots(figsize=(10, 6))
        
        if chart_type == "line":
            for label, values in data.items():
                ax.plot(values, label=label)
        elif chart_type == "bar":
            labels = list(data.keys())
            values = [np.mean(vals) for vals in data.values()]
            ax.bar(labels, values)
        elif chart_type == "scatter":
            if len(data) >= 2:
                x_key, y_key = list(data.keys())[:2]
                ax.scatter(data[x_key], data[y_key])
        
        ax.set_title(title)
        ax.legend()
        
        # Save plot
        plot_path = f"/tmp/plot_{datetime.now().strftime('%Y%m%d_%H%M%S')}.png"
        plt.savefig(plot_path)
        plt.close()
        
        return {
            "status": "success",
            "chart_type": chart_type,
            "plot_path": plot_path,
            "data_points": sum(len(vals) for vals in data.values())
        }
    except Exception as e:
        logger.error(f"Error generating visualization: {str(e)}")
        return {"status": "error", "message": str(e)}

# Workflow Management Tools
@function_tool
def log_task_execution(
    task_id: str,
    agent_name: str,
    task_description: str,
    status: str,
    result: str = None,
    execution_time: float = None
) -> Dict[str, str]:
    """Log task execution for monitoring and analytics"""
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        cursor.execute("""
            INSERT OR REPLACE INTO task_history 
            (task_id, agent_name, task_description, status, result, execution_time)
            VALUES (?, ?, ?, ?, ?, ?)
        """, (task_id, agent_name, task_description, status, result, execution_time))
        
        conn.commit()
        conn.close()
        
        return {"status": "success", "message": "Task logged successfully"}
    except Exception as e:
        logger.error(f"Error logging task: {str(e)}")
        return {"status": "error", "message": str(e)}

@function_tool
def get_performance_metrics(agent_name: str = None, days: int = 7) -> Dict[str, Any]:
    """Get performance metrics for agents"""
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        if agent_name:
            cursor.execute("""
                SELECT status, COUNT(*) as count, AVG(execution_time) as avg_time
                FROM task_history
                WHERE agent_name = ? AND timestamp >= datetime('now', '-{} days')
                GROUP BY status
            """.format(days), (agent_name,))
        else:
            cursor.execute("""
                SELECT agent_name, status, COUNT(*) as count, AVG(execution_time) as avg_time
                FROM task_history
                WHERE timestamp >= datetime('now', '-{} days')
                GROUP BY agent_name, status
            """.format(days))
        
        metrics = cursor.fetchall()
        conn.close()
        
        return {
            "status": "success",
            "metrics": [dict(metric) for metric in metrics],
            "period_days": days
        }
    except Exception as e:
        logger.error(f"Error getting performance metrics: {str(e)}")
        return {"status": "error", "message": str(e)}

# Security and Validation Tools
@function_tool
def validate_input(input_data: str, validation_type: str = "text") -> Dict[str, Any]:
    """Validate input data for security and format"""
    try:
        validation_results = {
            "is_valid": True,
            "issues": [],
            "sanitized_input": input_data
        }
        
        if validation_type == "text":
            # Check for potential injection attacks
            dangerous_patterns = ["<script", "javascript:", "data:", "vbscript:"]
            for pattern in dangerous_patterns:
                if pattern.lower() in input_data.lower():
                    validation_results["issues"].append(f"Potentially dangerous pattern found: {pattern}")
                    validation_results["is_valid"] = False
            
            # Check length
            if len(input_data) > 10000:
                validation_results["issues"].append("Input too long")
                validation_results["is_valid"] = False
            
            # Sanitize HTML
            soup = BeautifulSoup(input_data, 'html.parser')
            validation_results["sanitized_input"] = soup.get_text()
        
        elif validation_type == "email":
            import re
            email_pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
            if not re.match(email_pattern, input_data):
                validation_results["issues"].append("Invalid email format")
                validation_results["is_valid"] = False
        
        return validation_results
    except Exception as e:
        logger.error(f"Error validating input: {str(e)}")
        return {"status": "error", "message": str(e)}

@function_tool
def encrypt_sensitive_data(data: str, key: str = None) -> Dict[str, str]:
    """Encrypt sensitive data"""
    try:
        if not key:
            key = os.getenv("SECRET_KEY", "default_secret_key")
        
        # Simple encryption using hashlib (for demo purposes)
        # In production, use proper encryption libraries
        encrypted_data = hashlib.sha256((data + key).encode()).hexdigest()
        
        return {
            "status": "success",
            "encrypted_data": encrypted_data,
            "algorithm": "SHA256"
        }
    except Exception as e:
        logger.error(f"Error encrypting data: {str(e)}")
        return {"status": "error", "message": str(e)}

# Get all available tools
def get_all_tools() -> List:
    """Get all available advanced tools"""
    return [
        store_memory,
        retrieve_memory,
        process_csv_data,
        analyze_text_sentiment,
        extract_text_from_pdf,
        extract_text_from_docx,
        extract_text_from_image,
        transcribe_audio,
        scrape_webpage,
        make_api_request,
        perform_statistical_analysis,
        generate_data_visualization,
        log_task_execution,
        get_performance_metrics,
        validate_input,
        encrypt_sensitive_data
    ]
