"""
Advanced Agent System Configuration
Provides centralized configuration management for the enhanced agent system.
"""

import os
from typing import Dict, List, Optional
from pydantic import Field
try:
    from pydantic_settings import BaseSettings
except ImportError:
    # Fallback for older pydantic versions
    from pydantic import BaseSettings
from dotenv import load_dotenv

load_dotenv()

class AgentConfig(BaseSettings):
    """Configuration for individual agents"""
    name: str
    instructions: str
    model: str = "gpt-4o-mini"
    temperature: float = 0.7
    max_tokens: Optional[int] = None
    timeout: int = 30
    
class SystemConfig(BaseSettings):
    """System-wide configuration"""
    
    # API Keys
    openai_api_key: str = Field(..., env="OPENAI_API_KEY")
    google_api_key: Optional[str] = Field(None, env="GOOGLE_API_KEY")
    deepseek_api_key: Optional[str] = Field(None, env="DEEPSEEK_API_KEY")
    groq_api_key: Optional[str] = Field(None, env="GROQ_API_KEY")
    
    # External Services
    sendgrid_api_key: Optional[str] = Field(None, env="SENDGRID_API_KEY")
    slack_bot_token: Optional[str] = Field(None, env="SLACK_BOT_TOKEN")
    github_token: Optional[str] = Field(None, env="GITHUB_TOKEN")
    
    # Database
    database_url: str = Field("sqlite:///./agents.db", env="DATABASE_URL")
    redis_url: str = Field("redis://localhost:6379", env="REDIS_URL")
    
    # Monitoring
    enable_monitoring: bool = Field(True, env="ENABLE_MONITORING")
    sentry_dsn: Optional[str] = Field(None, env="SENTRY_DSN")
    prometheus_port: int = Field(8000, env="PROMETHEUS_PORT")
    
    # Security
    secret_key: str = Field(..., env="SECRET_KEY")
    enable_encryption: bool = Field(True, env="ENABLE_ENCRYPTION")
    
    # Performance
    max_concurrent_agents: int = Field(10, env="MAX_CONCURRENT_AGENTS")
    request_timeout: int = Field(60, env="REQUEST_TIMEOUT")
    retry_attempts: int = Field(3, env="RETRY_ATTEMPTS")
    
    class Config:
        env_file = ".env"
        case_sensitive = False
        extra = "ignore"  # Ignore extra fields

class WorkflowConfig(BaseSettings):
    """Configuration for workflow orchestration"""
    
    # Workflow Settings
    max_workflow_depth: int = Field(10, env="MAX_WORKFLOW_DEPTH")
    workflow_timeout: int = Field(300, env="WORKFLOW_TIMEOUT")
    enable_parallel_execution: bool = Field(True, env="ENABLE_PARALLEL_EXECUTION")
    
    # Error Handling
    max_retries: int = Field(3, env="MAX_RETRIES")
    retry_delay: int = Field(5, env="RETRY_DELAY")
    enable_circuit_breaker: bool = Field(True, env="ENABLE_CIRCUIT_BREAKER")
    
    class Config:
        env_file = ".env"
        extra = "ignore"  # Ignore extra fields

# Global configuration instances
system_config = SystemConfig()
workflow_config = WorkflowConfig()

# Predefined agent configurations
AGENT_CONFIGS = {
    "research_agent": AgentConfig(
        name="Advanced Research Agent",
        instructions="""You are an advanced research agent with access to multiple data sources.
        You excel at synthesizing information from various sources, identifying patterns,
        and providing comprehensive analysis. You can handle complex queries and provide
        detailed, well-structured responses with proper citations and references.""",
        model="gpt-4o",
        temperature=0.3
    ),
    
    "analysis_agent": AgentConfig(
        name="Data Analysis Agent", 
        instructions="""You are a specialized data analysis agent. You can process structured
        and unstructured data, perform statistical analysis, create visualizations,
        and provide actionable insights. You excel at identifying trends, anomalies,
        and patterns in data.""",
        model="gpt-4o",
        temperature=0.2
    ),
    
    "creative_agent": AgentConfig(
        name="Creative Content Agent",
        instructions="""You are a creative content generation agent. You can create engaging
        written content, generate ideas, write marketing copy, and produce creative
        materials across various formats and styles.""",
        model="gpt-4o",
        temperature=0.8
    ),
    
    "technical_agent": AgentConfig(
        name="Technical Implementation Agent",
        instructions="""You are a technical implementation agent. You can write code,
        debug issues, design system architectures, and provide technical solutions.
        You excel at translating requirements into working implementations.""",
        model="gpt-4o",
        temperature=0.1
    ),
    
    "coordination_agent": AgentConfig(
        name="Workflow Coordination Agent",
        instructions="""You are a workflow coordination agent responsible for orchestrating
        complex multi-agent workflows. You can break down tasks, assign work to
        appropriate agents, monitor progress, and ensure quality outcomes.""",
        model="gpt-4o",
        temperature=0.4
    )
}

# Model configurations for different providers
MODEL_CONFIGS = {
    "openai": {
        "gpt-4o": {"max_tokens": 4096, "temperature": 0.7},
        "gpt-4o-mini": {"max_tokens": 16384, "temperature": 0.7},
        "gpt-3.5-turbo": {"max_tokens": 4096, "temperature": 0.7}
    },
    "google": {
        "gemini-2.0-flash": {"max_tokens": 8192, "temperature": 0.7},
        "gemini-pro": {"max_tokens": 2048, "temperature": 0.7}
    },
    "deepseek": {
        "deepseek-chat": {"max_tokens": 4096, "temperature": 0.7}
    },
    "groq": {
        "llama-3.3-70b-versatile": {"max_tokens": 8192, "temperature": 0.7},
        "mixtral-8x7b-32768": {"max_tokens": 32768, "temperature": 0.7}
    }
}

def get_agent_config(agent_name: str) -> AgentConfig:
    """Get configuration for a specific agent"""
    return AGENT_CONFIGS.get(agent_name, AgentConfig(name=agent_name, instructions=""))

def get_model_config(provider: str, model: str) -> Dict:
    """Get configuration for a specific model"""
    return MODEL_CONFIGS.get(provider, {}).get(model, {})
